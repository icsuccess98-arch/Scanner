#!/bin/bash
# Quick deployment script for 730 Sports to Cloud Run

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== 730 Sports Cloud Run Deployment ===${NC}"

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo -e "${RED}Error: gcloud CLI not found. Install from: https://cloud.google.com/sdk/docs/install${NC}"
    exit 1
fi

# Configuration
PROJECT_ID=${1:-$(gcloud config get-value project)}
SERVICE_NAME="730sports"
REGION="us-central1"
MEMORY="2Gi"
CPU="2"
TIMEOUT="300"
MAX_INSTANCES="10"

echo -e "${YELLOW}Project ID: ${PROJECT_ID}${NC}"
echo -e "${YELLOW}Service: ${SERVICE_NAME}${NC}"
echo -e "${YELLOW}Region: ${REGION}${NC}"

# Confirm deployment
read -p "Deploy to Cloud Run? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Deployment cancelled${NC}"
    exit 1
fi

# Make scripts executable
chmod +x startup.sh startup_quick.sh

# Deploy to Cloud Run
echo -e "${GREEN}Deploying to Cloud Run...${NC}"
gcloud run deploy ${SERVICE_NAME} \
  --source . \
  --platform managed \
  --region ${REGION} \
  --memory ${MEMORY} \
  --cpu ${CPU} \
  --timeout ${TIMEOUT} \
  --min-instances 0 \
  --max-instances ${MAX_INSTANCES} \
  --allow-unauthenticated \
  --port 8080 \
  --startup-cpu-boost \
  --execution-environment gen2 \
  --project ${PROJECT_ID}

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Deployment successful!${NC}"
    
    # Get service URL
    SERVICE_URL=$(gcloud run services describe ${SERVICE_NAME} \
      --platform managed \
      --region ${REGION} \
      --format 'value(status.url)' \
      --project ${PROJECT_ID})
    
    echo -e "${GREEN}Service URL: ${SERVICE_URL}${NC}"
    
    # Test health endpoint
    echo -e "${YELLOW}Testing health endpoint...${NC}"
    sleep 5  # Wait for deployment to stabilize
    
    if curl -s "${SERVICE_URL}/health" | grep -q "healthy"; then
        echo -e "${GREEN}✓ Health check passed!${NC}"
    else
        echo -e "${RED}✗ Health check failed${NC}"
        echo -e "${YELLOW}Check logs: gcloud run services logs read ${SERVICE_NAME} --limit 50${NC}"
    fi
    
    # Show useful commands
    echo -e "\n${GREEN}=== Useful Commands ===${NC}"
    echo -e "View logs:     ${YELLOW}gcloud run services logs tail ${SERVICE_NAME}${NC}"
    echo -e "View metrics:  ${YELLOW}gcloud run services describe ${SERVICE_NAME} --region ${REGION}${NC}"
    echo -e "Delete service: ${YELLOW}gcloud run services delete ${SERVICE_NAME} --region ${REGION}${NC}"
    
else
    echo -e "${RED}✗ Deployment failed${NC}"
    echo -e "${YELLOW}Check logs: gcloud run services logs read ${SERVICE_NAME} --limit 50${NC}"
    exit 1
fi
