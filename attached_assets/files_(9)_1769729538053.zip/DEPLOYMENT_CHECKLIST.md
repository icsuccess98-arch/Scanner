# 730 Sports - Deployment Checklist

## Pre-Deployment ✅

- [ ] Review `README.md` for quick start
- [ ] Review `CHANGELOG.md` to understand changes
- [ ] Set DATABASE_URL environment variable
- [ ] Set SESSION_SECRET environment variable
- [ ] Choose startup method (full vs quick)
- [ ] Verify gcloud CLI is installed and configured

## Deployment Steps ✅

### Option A: Automated (Recommended)

- [ ] Make scripts executable: `chmod +x deploy.sh startup.sh startup_quick.sh`
- [ ] Run deployment: `./deploy.sh`
- [ ] Wait for deployment to complete (~2-3 minutes)
- [ ] Test health endpoint (script does this automatically)

### Option B: Manual

- [ ] Make scripts executable: `chmod +x startup.sh startup_quick.sh`
- [ ] Deploy: `gcloud run deploy 730sports --source . --region us-central1`
- [ ] Set environment variables in Cloud Console
- [ ] Test health endpoint manually

## Post-Deployment Verification ✅

- [ ] Health check passes: `curl https://YOUR-URL/health`
- [ ] Dashboard loads: Open `https://YOUR-URL/` in browser
- [ ] Check logs: `gcloud run services logs tail 730sports`
- [ ] Verify no error messages in logs
- [ ] Test fetch odds functionality
- [ ] Check database connection (should see games loaded)

## Monitoring Setup ✅

- [ ] Set up Cloud Monitoring uptime check
- [ ] Create alert for service downtime
- [ ] Create alert for high error rate
- [ ] Set up log-based metrics (optional)
- [ ] Add service to monitoring dashboard

## Performance Validation ✅

- [ ] Health endpoint responds <100ms
- [ ] Dashboard loads <5s (first load)
- [ ] Dashboard loads <2s (cached)
- [ ] WagerTalk scraping works (if using full startup)
- [ ] No memory/CPU issues in monitoring

## Troubleshooting (If Needed) ✅

If deployment fails, check:

1. **Logs first:**
   ```bash
   gcloud run services logs read 730sports --limit 100
   ```

2. **Common issues:**
   - Health check timeout → See DEPLOYMENT_GUIDE.md
   - Playwright errors → Verify startup.sh is used
   - Database errors → Check DATABASE_URL format
   - Port binding → Should see "Listening at: http://0.0.0.0:8080"

3. **Test locally:**
   ```bash
   docker build -t 730sports .
   docker run -p 8080:8080 -e DATABASE_URL="..." 730sports
   curl http://localhost:8080/health
   ```

4. **Rollback if needed:**
   ```bash
   # Revert to previous code
   cp sports_app_backup.py sports_app.py
   gcloud run deploy 730sports --source .
   ```

## Documentation Reference

- **Quick Start:** `README.md`
- **Full Deployment:** `DEPLOYMENT_GUIDE.md`
- **Monitoring:** `MONITORING.md`
- **Changes Made:** `CHANGELOG.md`

## Support Contacts

- Cloud Run Docs: https://cloud.google.com/run/docs
- Playwright Docs: https://playwright.dev/python/
- Flask Docs: https://flask.palletsprojects.com/

## Success Criteria ✅

Your deployment is successful when:

✅ Health endpoint returns 200 status  
✅ Dashboard loads without errors  
✅ No 5xx errors in logs  
✅ Games load successfully  
✅ WagerTalk scraping works (if enabled)  
✅ Service stays healthy for 24+ hours  

---

**Ready to Deploy?** Run `./deploy.sh` and follow the prompts!
