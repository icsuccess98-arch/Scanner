#!/bin/bash
# Startup script for Cloud Run deployment
# Installs Playwright browsers and starts gunicorn

echo "=== 730 Sports Deployment Startup ==="
echo "Installing Playwright browsers..."

# Install Playwright browser binaries (chromium only for efficiency)
python -m playwright install --with-deps chromium

# Check if installation was successful
if [ $? -eq 0 ]; then
    echo "✓ Playwright browsers installed successfully"
else
    echo "✗ Playwright installation failed, but continuing (app will use fallback)"
fi

echo "Starting gunicorn server..."

# Start gunicorn with proper settings for Cloud Run
# - workers=1: Cloud Run auto-scales horizontally, so single worker per instance
# - threads=4: Handle concurrent requests within worker
# - timeout=300: 5 min timeout for long-running scraping operations
# - bind=0.0.0.0:$PORT: Cloud Run injects PORT env var
# - worker-class=gthread: Threading for async operations
# - preload: Load app before forking workers (faster startup)

exec gunicorn sports_app:app \
  --bind 0.0.0.0:${PORT:-8080} \
  --workers 1 \
  --threads 4 \
  --timeout 300 \
  --worker-class gthread \
  --preload \
  --access-logfile - \
  --error-logfile - \
  --log-level info
