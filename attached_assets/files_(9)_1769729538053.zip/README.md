# 730 Sports - Fixed for Cloud Run Deployment

## What Was Fixed

✅ **Health check detection** - Now properly detects Google Cloud health probes  
✅ **Fast response path** - `/` route returns immediately for health checks  
✅ **Background cleanup** - Database operations moved to background threads  
✅ **Playwright support** - VM deployment with browser automation  
✅ **Multiple startup options** - Choose between fast boot or full Playwright

## Quickest Deployment (5 minutes)

```bash
# 1. Make scripts executable
chmod +x startup.sh deploy.sh

# 2. Deploy (interactive script)
./deploy.sh

# 3. Test
curl https://730sports-YOURURL.run.app/health
```

That's it! ✨

## Manual Deployment

```bash
gcloud run deploy 730sports \
  --source . \
  --region us-central1 \
  --memory 2Gi \
  --cpu 2 \
  --timeout 300 \
  --allow-unauthenticated \
  --startup-cpu-boost
```

## Environment Variables Required

Set these in Cloud Run:

```bash
DATABASE_URL=postgresql://user:pass@host:port/database
SESSION_SECRET=your-secret-key-here
```

## Files in This Package

### Core Application
- `sports_app.py` - **FIXED** main Flask app with health check improvements
- `sports_app_backup.py` - Original file (for rollback if needed)
- `automated_loading_system.py` - Auto-loading and elimination filters
- `wagertalk_scraper.py` - WagerTalk scraping with Playwright
- `parallel_fetcher.py` - Parallel data fetching
- `app_config.py` - Configuration settings
- `requirements.txt` - Python dependencies

### Deployment Files
- `Dockerfile` - Container with Playwright support
- `startup.sh` - **NEW** Full startup with Playwright installation
- `startup_quick.sh` - **NEW** Fast startup (Playwright on-demand)
- `deploy.sh` - **NEW** Automated deployment script
- `service.yaml` - **NEW** Cloud Run service configuration
- `.dockerignore` - Docker build optimization

### Documentation
- `DEPLOYMENT_GUIDE.md` - **COMPREHENSIVE** deployment instructions
- `MONITORING.md` - **COMPREHENSIVE** monitoring and troubleshooting
- `README.md` - This file (quick start)

## Health Check Endpoints

1. **`/health`** - Dedicated health check (use this for monitoring)
2. **`/`** - Main dashboard (auto-detects health probes)

Both respond with 200 immediately for health check user agents.

## What Changed in sports_app.py

**Health Check Detection (Line ~7241):**
```python
health_check_indicators = [
    'googlehc',    # Google Cloud Run health checks
    'health',      # Generic monitoring
    'check',       # Uptime checks
    ...
]
```

**Background Cleanup (Line ~7254):**
```python
# Old: Blocking cleanup
old_games = Game.query.filter(...).all()  # BLOCKED REQUEST
db.session.delete(...)

# New: Non-blocking cleanup
cleanup_thread = threading.Thread(target=cleanup_old_games)
cleanup_thread.start()  # RETURNS IMMEDIATELY
```

**Enhanced /health Endpoint (Line ~199):**
```python
@app.route('/health', methods=['GET', 'HEAD'])
def health_check():
    if request.method == 'HEAD':
        return '', 200
    return jsonify({"status": "healthy"}), 200
```

## Startup Options

### Option 1: Full Playwright (Recommended)
- Uses `startup.sh`
- Installs browsers at startup (~40s)
- WagerTalk works immediately
- Larger image (~1.2GB)

### Option 2: Quick Start
- Uses `startup_quick.sh`
- No browser installation (~10s startup)
- Playwright installs on first use
- Smaller image

To switch: Edit `Dockerfile` line 66:
```dockerfile
CMD ["./startup.sh"]      # Full
CMD ["./startup_quick.sh"] # Quick
```

## Testing Locally

```bash
# Build Docker image
docker build -t 730sports .

# Run locally
docker run -p 8080:8080 \
  -e DATABASE_URL="postgresql://..." \
  -e SESSION_SECRET="test-secret" \
  730sports

# Test health
curl http://localhost:8080/health
```

## Common Issues

### "Health check failed"
- Check logs: `gcloud run services logs read 730sports --limit 50`
- Verify port: Should see "Listening at: http://0.0.0.0:8080"
- Test locally first

### "Playwright not working"
- Ensure using `startup.sh` (not `startup_quick.sh`)
- Check Dockerfile has browser dependencies
- View install logs: `gcloud run services logs read 730sports | grep -i playwright`

### "Database connection error"
- Verify DATABASE_URL format: `postgresql://` (not `postgres://`)
- Check secret is set: `gcloud run services describe 730sports`
- Test connection: `psql $DATABASE_URL -c "SELECT 1;"`

## Monitoring

```bash
# Real-time logs
gcloud run services logs tail 730sports

# Check service status
gcloud run services describe 730sports --region us-central1

# Test endpoints
URL=$(gcloud run services describe 730sports --region us-central1 --format 'value(status.url)')
curl $URL/health
```

See `MONITORING.md` for comprehensive troubleshooting guide.

## Support

If deployment still fails:

1. Check full logs:
   ```bash
   gcloud run services logs read 730sports --limit 100
   ```

2. Compare with working local Docker:
   ```bash
   docker build -t 730sports . && docker run -p 8080:8080 730sports
   ```

3. Review `DEPLOYMENT_GUIDE.md` for detailed troubleshooting

## Rollback

Original file saved as `sports_app_backup.py`:

```bash
cp sports_app_backup.py sports_app.py
gcloud run deploy 730sports --source .
```
