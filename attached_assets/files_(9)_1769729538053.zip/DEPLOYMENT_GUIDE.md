# 730 Sports Deployment Guide - Health Check Fixes

## Problem Diagnosis

Your deployment was failing because:

1. **Slow Root Route (`/`)**: The dashboard route was doing expensive operations:
   - Database queries for old game cleanup
   - Logo lookups for all games
   - Hit rate calculations
   - All happening BEFORE returning any response

2. **Missing Health Check Detection**: Cloud Run health checks weren't being detected properly
   - Google uses user-agent: `GoogleHC/1.0`
   - Your app only checked for generic "health" or "check" keywords

3. **Synchronous Cleanup Blocking**: Old game cleanup was blocking the request thread

## Fixes Applied

### 1. Enhanced Health Check Detection (sports_app.py)

```python
# Now detects multiple health check patterns:
health_check_indicators = [
    'googlehc',           # Google Health Check  
    'health',             # Generic health checks
    'check',              # Uptime monitoring
    'kube-probe',         # Kubernetes probes
    'ping',               # Ping checks
    'monitoring',         # Monitoring services
]
```

### 2. Background Cleanup (Non-Blocking)

Moved database cleanup to background thread:
```python
def cleanup_old_games():
    # Runs in background thread with its own app context
    
cleanup_thread = threading.Thread(target=cleanup_old_games, daemon=True)
cleanup_thread.start()
# Dashboard continues immediately without waiting
```

### 3. HEAD Request Support

Added HEAD method support (common for health checks):
```python
@app.route('/health', methods=['GET', 'HEAD'])
def health_check():
    if request.method == 'HEAD':
        return '', 200
    return jsonify({"status": "healthy"}), 200
```

## Deployment Options

### Option A: Full Playwright Support (Recommended for Production)

Use `Dockerfile` and `startup.sh`:

**Pros:**
- Playwright browsers pre-installed
- WagerTalk scraping works immediately
- Slightly longer startup (~40 seconds)

**Cons:**
- Larger Docker image (~1.2GB)
- Slower initial deployment

**Deploy:**
```bash
# Make startup script executable
chmod +x startup.sh

# Deploy to Cloud Run
gcloud run deploy 730sports \
  --source . \
  --region us-central1 \
  --memory 2Gi \
  --cpu 2 \
  --timeout 300 \
  --min-instances 0 \
  --max-instances 10 \
  --allow-unauthenticated \
  --port 8080 \
  --startup-cpu-boost
```

### Option B: Quick Startup (Playwright On-Demand)

Use `startup_quick.sh`:

**Pros:**
- Faster startup (~10 seconds)
- Smaller image
- Health checks pass immediately

**Cons:**
- First WagerTalk request will be slower (installs browser)
- Playwright installation might fail at runtime

**Deploy:**
```bash
# Update Dockerfile CMD to use quick startup
# CMD ["./startup_quick.sh"]

chmod +x startup_quick.sh
gcloud run deploy 730sports --source . ...
```

## Cloud Run Configuration

### Required Environment Variables

```bash
DATABASE_URL=postgresql://user:pass@host/db
SESSION_SECRET=your-secret-key-here
```

### Recommended Settings

```yaml
# service.yaml
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: 730sports
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/minScale: '0'
        autoscaling.knative.dev/maxScale: '10'
        run.googleapis.com/startup-cpu-boost: 'true'
    spec:
      containerConcurrency: 80
      timeoutSeconds: 300
      containers:
      - image: gcr.io/YOUR-PROJECT/730sports
        ports:
        - containerPort: 8080
        resources:
          limits:
            memory: 2Gi
            cpu: '2'
        startupProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 3
          failureThreshold: 10
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8080
          periodSeconds: 5
```

## Health Check Endpoints

Your app now has TWO health check endpoints:

1. **`/health`** - Dedicated health check
   - No database queries
   - Returns immediately
   - Supports GET and HEAD
   - Use this for monitoring

2. **`/`** - Main dashboard
   - Now detects health checks via User-Agent
   - Returns 200 immediately for health probes
   - Full dashboard for real users

## Testing Health Checks Locally

```bash
# Test dedicated health endpoint
curl http://localhost:8080/health

# Test root with health check user agent
curl -H "User-Agent: GoogleHC/1.0" http://localhost:8080/

# Test HEAD request
curl -I http://localhost:8080/health
```

## Troubleshooting

### "Still failing health checks"

1. Check Cloud Run logs:
```bash
gcloud run services logs read 730sports --limit 50
```

2. Verify port binding:
```bash
# In logs, look for:
# "Listening at: http://0.0.0.0:8080"
```

3. Test locally with same settings:
```bash
PORT=8080 gunicorn sports_app:app \
  --bind 0.0.0.0:8080 \
  --workers 1 \
  --threads 4 \
  --timeout 300
```

### "Playwright not working"

1. Check browser installation:
```bash
python -m playwright install --with-deps chromium
```

2. Verify in container:
```bash
# SSH into Cloud Run container (if enabled)
playwright --version
```

3. Use fallback startup script if needed

### "Database connection errors"

1. Verify DATABASE_URL format:
```
postgresql://username:password@host:port/database
```

2. Check connection pool settings in sports_app.py:
```python
"pool_size": 5,
"max_overflow": 10,
"connect_timeout": 10
```

## What Changed in sports_app.py

**Line ~7241-7270**: Enhanced root route with better health check detection
**Line ~199-207**: Enhanced /health endpoint with HEAD support
**Line ~7254-7273**: Moved cleanup to background thread (non-blocking)

## Next Steps

1. **Deploy with fixes:**
   ```bash
   chmod +x startup.sh
   gcloud run deploy 730sports --source .
   ```

2. **Monitor startup:**
   ```bash
   gcloud run services logs tail 730sports
   ```

3. **Verify health:**
   ```bash
   curl https://730sports-HASH-uc.a.run.app/health
   ```

4. **Test WagerTalk (after startup):**
   - Visit dashboard
   - Click "Fetch Odds" 
   - Check logs for Playwright activity

## Performance Tips

1. **Keep min-instances at 0** - Saves costs, health checks will wake it
2. **Use startup-cpu-boost** - Faster cold starts
3. **Set timeout to 300** - Allows scraping operations to complete
4. **Use 2Gi memory** - Playwright needs RAM for browser

## Files Modified

- ✅ `sports_app.py` - Enhanced health checks, background cleanup
- ✅ `startup.sh` - NEW - Installs Playwright browsers
- ✅ `startup_quick.sh` - NEW - Quick startup option
- ✅ `Dockerfile` - NEW - Container with Playwright support

## Roll Back (If Needed)

The original `sports_app.py` is backed up as `sports_app_backup.py`.

To revert:
```bash
cp sports_app_backup.py sports_app.py
```
