# 730 Sports Monitoring & Troubleshooting

## Quick Health Checks

### 1. Service Status
```bash
# Check if service is running
gcloud run services describe 730sports --region us-central1

# Get service URL
gcloud run services describe 730sports \
  --region us-central1 \
  --format 'value(status.url)'
```

### 2. Health Endpoint
```bash
# Get service URL
URL=$(gcloud run services describe 730sports --region us-central1 --format 'value(status.url)')

# Test health endpoint
curl $URL/health

# Test with health check user agent
curl -H "User-Agent: GoogleHC/1.0" $URL/

# Test HEAD request
curl -I $URL/health
```

### 3. Real-Time Logs
```bash
# Tail logs (live)
gcloud run services logs tail 730sports

# Last 50 log entries
gcloud run services logs read 730sports --limit 50

# Filter for errors
gcloud run services logs read 730sports --limit 100 | grep ERROR

# Filter for health checks
gcloud run services logs read 730sports --limit 100 | grep health
```

## Common Issues & Fixes

### Issue: "Service Not Responding to Health Checks"

**Symptoms:**
- Deployment shows "Unhealthy"
- Logs show timeout errors
- Service never becomes available

**Diagnosis:**
```bash
# Check startup probe failures
gcloud run services logs read 730sports --limit 100 | grep "startupProbe"

# Check if port is binding correctly
gcloud run services logs read 730sports --limit 100 | grep "Listening"
```

**Fix:**
1. Verify PORT environment variable:
```bash
gcloud run services update 730sports --update-env-vars PORT=8080
```

2. Check startup.sh is executable:
```bash
# Redeploy with explicit chmod
chmod +x startup.sh && gcloud run deploy 730sports --source .
```

3. Increase startup probe timeout in service.yaml:
```yaml
startupProbe:
  failureThreshold: 30  # Increase from 20
```

### Issue: "Container Failed to Start"

**Symptoms:**
- Logs show "Container failed to start"
- Application crashes immediately

**Diagnosis:**
```bash
# Check for Python errors
gcloud run services logs read 730sports --limit 100 | grep -A 5 "Error"

# Check for missing dependencies
gcloud run services logs read 730sports --limit 100 | grep "ModuleNotFoundError"
```

**Fix:**
1. Verify all dependencies in requirements.txt
2. Check DATABASE_URL is set:
```bash
gcloud run services describe 730sports --format="value(spec.template.spec.containers[0].env)"
```

3. Test locally first:
```bash
docker build -t 730sports .
docker run -p 8080:8080 -e DATABASE_URL="postgresql://..." 730sports
```

### Issue: "Playwright Not Working"

**Symptoms:**
- WagerTalk scraping fails
- Logs show "Playwright not available"

**Diagnosis:**
```bash
# Check for Playwright installation logs
gcloud run services logs read 730sports --limit 200 | grep -i playwright
```

**Fix:**
1. Ensure startup.sh runs Playwright install:
```bash
# In startup.sh, verify:
python -m playwright install --with-deps chromium
```

2. Check Dockerfile has browser dependencies:
```bash
# Verify these packages in Dockerfile:
libatk-bridge2.0-0
libcups2
libgbm1
libgtk-3-0
```

3. Try manual installation in running container:
```bash
# If Cloud Run allows SSH access:
python -m playwright install chromium
```

### Issue: "Database Connection Errors"

**Symptoms:**
- "Connection refused"
- "Too many connections"
- "Password authentication failed"

**Diagnosis:**
```bash
# Check database connection errors
gcloud run services logs read 730sports --limit 100 | grep -i "database\|psycopg2"
```

**Fix:**
1. Verify DATABASE_URL format:
```bash
# Should be: postgresql://user:pass@host:port/database
# NOT: postgres:// (old format)
```

2. Check connection pool settings in sports_app.py:
```python
"pool_size": 5,        # Reduce if hitting connection limits
"max_overflow": 10,    # Reduce if hitting connection limits
"pool_pre_ping": True, # Keep enabled
```

3. Test connection locally:
```bash
python -c "from sqlalchemy import create_engine; engine = create_engine('$DATABASE_URL'); conn = engine.connect(); print('Success')"
```

### Issue: "Slow Response Times"

**Symptoms:**
- Dashboard takes >5 seconds to load
- Timeouts on complex operations

**Diagnosis:**
```bash
# Check slow query logs
gcloud run services logs read 730sports --limit 100 | grep "duration"

# Monitor CPU and memory
gcloud monitoring timeseries list \
  --filter='resource.type="cloud_run_revision" AND metric.type="run.googleapis.com/container/cpu/utilizations"'
```

**Fix:**
1. Increase resources:
```bash
gcloud run services update 730sports \
  --memory 4Gi \
  --cpu 4
```

2. Check cache settings are working:
```bash
# In logs, look for:
# "Dashboard cache hit" vs "Dashboard cache miss"
```

3. Enable request timeout monitoring:
```python
# In sports_app.py, add timing decorator
@app.before_request
def log_request():
    g.start_time = time.time()

@app.after_request
def log_response(response):
    duration = time.time() - g.start_time
    logger.info(f"Request took {duration:.2f}s")
    return response
```

## Performance Monitoring

### Real-Time Metrics
```bash
# CPU usage
gcloud monitoring timeseries list \
  --filter='metric.type="run.googleapis.com/container/cpu/utilizations"' \
  --format="table(resource.labels.service_name, metric.type, points[].value.doubleValue)"

# Memory usage
gcloud monitoring timeseries list \
  --filter='metric.type="run.googleapis.com/container/memory/utilizations"' \
  --format="table(resource.labels.service_name, metric.type, points[].value.doubleValue)"

# Request count
gcloud monitoring timeseries list \
  --filter='metric.type="run.googleapis.com/request_count"' \
  --format="table(resource.labels.service_name, metric.type, points[].value.int64Value)"
```

### Response Times
```bash
# Average response time
gcloud monitoring timeseries list \
  --filter='metric.type="run.googleapis.com/request_latencies"' \
  --format="table(metric.type, points[].value.distributionValue.mean)"
```

### Error Rates
```bash
# 5xx errors
gcloud run services logs read 730sports --limit 100 | grep " 5[0-9][0-9] "

# 4xx errors
gcloud run services logs read 730sports --limit 100 | grep " 4[0-9][0-9] "
```

## Debugging Commands

### Access Container (if SSH enabled)
```bash
# NOT AVAILABLE BY DEFAULT on Cloud Run
# But you can test locally:
docker build -t 730sports .
docker run -it --entrypoint /bin/bash 730sports
```

### Test Endpoints
```bash
URL=$(gcloud run services describe 730sports --region us-central1 --format 'value(status.url)')

# Health check
curl $URL/health

# Dashboard (should return HTML)
curl $URL/

# Fetch odds (may be slow)
curl -X POST $URL/fetch_odds

# Manual game load
curl -X POST $URL/manual_game_load
```

### Database Queries
```bash
# Connect to database
psql $DATABASE_URL

# Check games in database
psql $DATABASE_URL -c "SELECT COUNT(*) FROM game WHERE date = CURRENT_DATE;"

# Check recent picks
psql $DATABASE_URL -c "SELECT * FROM pick ORDER BY created_at DESC LIMIT 10;"
```

## Alerts Setup

### Create Uptime Check
```bash
gcloud monitoring uptime-check-configs create \
  --display-name="730Sports Health Check" \
  --checked-resource-type=cloud_run_revision \
  --monitored-resource=cloud_run_revision \
  --path=/health \
  --period=60
```

### Create Alert Policy
```bash
# Alert on health check failures
gcloud alpha monitoring policies create \
  --notification-channels=CHANNEL_ID \
  --display-name="730Sports Down Alert" \
  --condition-display-name="Health Check Failed" \
  --condition-threshold-value=1 \
  --condition-threshold-duration=60s
```

## Useful Dashboards

### Cloud Console URLs
- **Cloud Run Dashboard**: https://console.cloud.google.com/run
- **Logs Explorer**: https://console.cloud.google.com/logs
- **Monitoring**: https://console.cloud.google.com/monitoring
- **Error Reporting**: https://console.cloud.google.com/errors

### Custom Monitoring Query
```sql
-- Find slow requests (>2s)
resource.type="cloud_run_revision"
jsonPayload.message=~"Request took [2-9]\.[0-9]+s"

-- Find health check failures
resource.type="cloud_run_revision"
httpRequest.status>=500
httpRequest.requestUrl=~"/health"

-- Find WagerTalk errors
resource.type="cloud_run_revision"
jsonPayload.message=~"WagerTalk.*error"
```

## Emergency Rollback

### Revert to Previous Revision
```bash
# List revisions
gcloud run revisions list --service 730sports --region us-central1

# Roll back to specific revision
gcloud run services update-traffic 730sports \
  --to-revisions=730sports-00042-abc=100 \
  --region us-central1
```

### Quick Disable
```bash
# Set min-instances to 0 to stop serving traffic
gcloud run services update 730sports \
  --min-instances 0 \
  --region us-central1

# Or delete completely
gcloud run services delete 730sports --region us-central1
```
