#!/bin/bash
# Lightweight startup - skips Playwright installation for faster boot
# Playwright will install on first use if needed

echo "=== 730 Sports Quick Startup ==="
echo "Starting server immediately (Playwright on-demand)..."

# Start gunicorn with optimized settings for Cloud Run health checks
exec gunicorn sports_app:app \
  --bind 0.0.0.0:${PORT:-8080} \
  --workers 1 \
  --threads 4 \
  --timeout 300 \
  --worker-class gthread \
  --access-logfile - \
  --error-logfile - \
  --log-level info \
  --worker-tmp-dir /dev/shm
