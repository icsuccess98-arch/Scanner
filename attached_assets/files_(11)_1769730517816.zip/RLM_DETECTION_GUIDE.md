# Reverse Line Movement (RLM) Detection - Complete Guide

## What is Reverse Line Movement?

**Definition:** When the betting line moves in the OPPOSITE direction of where the public money is going.

### Normal Line Movement (No RLM)
```
Opening Line: Chiefs -7
Public Betting: 75% on Chiefs
Line Movement: Chiefs -7 → -7.5 → -8
Result: Line moves WITH public money ✅ Normal
```

### Reverse Line Movement (RLM Alert!)
```
Opening Line: Chiefs -7
Public Betting: 75% on Chiefs
Line Movement: Chiefs -7 → -6.5 → -6
Result: Line moves AGAINST public money 🚨 RLM!
```

## Why Does RLM Happen?

1. **Sharp Money:** Professional bettors place large bets on the other side
2. **Sportsbook Adjustment:** Books respect sharp action more than public volume
3. **Liability Management:** Books want balanced action on both sides

### The Logic:
- If 75% of bets are on Chiefs -7
- But the line moves to Chiefs -6 (easier to cover)
- Sharp money must be hammering Colts +7
- Books respect sharp money more than public volume

## Critical RLM Detection Rules

### Rule 1: Public Percentage Threshold
**Minimum:** 60% on one side (some use 65% or 70%)
```python
# Public must be heavily on one side
if public_pct >= 60:  # or 65, 70 depending on strictness
    # Check for reverse movement
```

### Rule 2: Line Movement Direction
**Must move OPPOSITE to public money**
```python
# If public is on favorite (-)
if public_pct >= 60 and public_side == 'favorite':
    # Line should get bigger (more negative)
    # If it gets smaller (less negative), that's RLM
    if opening_line < current_line:  # Example: -7 to -6
        rlm_detected = True

# If public is on underdog (+)
if public_pct >= 60 and public_side == 'underdog':
    # Line should get smaller (less positive)
    # If it gets bigger (more positive), that's RLM
    if opening_line > current_line:  # Example: +7 to +8
        rlm_detected = True
```

### Rule 3: Minimum Movement Threshold
**Line must move meaningfully** (usually 0.5 points minimum)
```python
movement = abs(current_line - opening_line)
if movement >= 0.5:  # At least half point
    # Significant enough to matter
```

## RLM Detection Algorithm (CORRECT LOGIC)

```python
def detect_reverse_line_movement(
    opening_line: float,      # Example: -7.0 (negative = favorite)
    current_line: float,      # Example: -6.0
    public_pct: float,        # Example: 75 (percent on favorite)
    public_side: str,         # 'favorite' or 'underdog'
    min_public_pct: float = 65,
    min_movement: float = 0.5
) -> dict:
    """
    Detect reverse line movement with correct logic.
    
    Returns:
        {
            'rlm_detected': bool,
            'movement': float,
            'direction': str,
            'severity': str,
            'explanation': str
        }
    """
    
    # Calculate line movement
    movement = current_line - opening_line
    movement_abs = abs(movement)
    
    # Check if movement is significant
    if movement_abs < min_movement:
        return {
            'rlm_detected': False,
            'movement': movement,
            'direction': 'none',
            'severity': 'none',
            'explanation': f'Line movement too small: {movement_abs} points'
        }
    
    # Check if public betting is lopsided enough
    if public_pct < min_public_pct:
        return {
            'rlm_detected': False,
            'movement': movement,
            'direction': 'with_public' if is_with_public else 'against_public',
            'severity': 'none',
            'explanation': f'Public betting not lopsided enough: {public_pct}%'
        }
    
    # Determine if movement is reverse
    rlm_detected = False
    
    if public_side == 'favorite':
        # Public is on the favorite (negative spread)
        # Normal: Line should move more negative (e.g., -7 to -8)
        # RLM: Line moves less negative (e.g., -7 to -6)
        
        if movement > 0:  # Line became less negative
            rlm_detected = True
            explanation = f"Public {public_pct}% on favorite, but line moved from {opening_line} to {current_line} (easier to cover)"
        else:
            explanation = f"Line moved with public: {opening_line} to {current_line}"
    
    elif public_side == 'underdog':
        # Public is on the underdog (positive spread)
        # Normal: Line should move less positive (e.g., +7 to +6)
        # RLM: Line moves more positive (e.g., +7 to +8)
        
        if movement > 0:  # Line became more positive
            rlm_detected = True
            explanation = f"Public {public_pct}% on underdog, but line moved from {opening_line} to {current_line} (better value)"
        else:
            explanation = f"Line moved with public: {opening_line} to {current_line}"
    
    # Determine severity
    severity = 'none'
    if rlm_detected:
        if movement_abs >= 2.0:
            severity = 'extreme'  # 2+ point movement against public
        elif movement_abs >= 1.0:
            severity = 'strong'   # 1-2 point movement
        else:
            severity = 'moderate' # 0.5-1 point movement
    
    return {
        'rlm_detected': rlm_detected,
        'movement': movement,
        'movement_abs': movement_abs,
        'direction': 'reverse' if rlm_detected else 'normal',
        'severity': severity,
        'explanation': explanation,
        'public_pct': public_pct,
        'public_side': public_side
    }
```

## Practical Examples

### Example 1: Classic RLM (Spread)
```python
# Chiefs vs Colts
opening_line = -7.0   # Chiefs favored by 7
current_line = -5.5   # Chiefs favored by 5.5
public_pct = 75       # 75% of bets on Chiefs
public_side = 'favorite'

result = detect_reverse_line_movement(
    opening_line, current_line, public_pct, public_side
)

# Result:
{
    'rlm_detected': True,
    'movement': 1.5,  # Moved 1.5 points
    'direction': 'reverse',
    'severity': 'strong',
    'explanation': 'Public 75% on favorite, but line moved from -7.0 to -5.5 (easier to cover)'
}

# Interpretation: Sharp money on Colts +7
```

### Example 2: Normal Movement (Not RLM)
```python
# Bucks vs Wizards
opening_line = -12.0  # Bucks favored by 12
current_line = -13.5  # Bucks favored by 13.5
public_pct = 80       # 80% on Bucks
public_side = 'favorite'

result = detect_reverse_line_movement(
    opening_line, current_line, public_pct, public_side
)

# Result:
{
    'rlm_detected': False,
    'movement': -1.5,  # Moved 1.5 points MORE negative
    'direction': 'normal',
    'severity': 'none',
    'explanation': 'Line moved with public: -12.0 to -13.5'
}

# Interpretation: Line moved WITH public, no RLM
```

### Example 3: RLM on Underdog
```python
# Heat vs Bulls
opening_line = +3.5   # Heat are 3.5 point underdogs
current_line = +5.0   # Heat are 5 point underdogs
public_pct = 70       # 70% on Heat
public_side = 'underdog'

result = detect_reverse_line_movement(
    opening_line, current_line, public_pct, public_side
)

# Result:
{
    'rlm_detected': True,
    'movement': 1.5,
    'direction': 'reverse',
    'severity': 'strong',
    'explanation': 'Public 70% on underdog, but line moved from +3.5 to +5.0 (better value)'
}

# Interpretation: Sharp money on Bulls -3.5
```

### Example 4: Small Movement (Not Significant)
```python
opening_line = -6.0
current_line = -6.5   # Only 0.5 point move
public_pct = 72
public_side = 'favorite'

result = detect_reverse_line_movement(
    opening_line, current_line, public_pct, public_side
)

# Result:
{
    'rlm_detected': False,
    'movement': -0.5,
    'direction': 'normal',
    'severity': 'none',
    'explanation': 'Line moved with public: -6.0 to -6.5'
}

# This is NORMAL movement (line got harder for favorite)
```

## Common RLM Mistakes to Avoid

### ❌ WRONG: Comparing absolute values
```python
# INCORRECT - Don't do this!
if abs(opening_line) > abs(current_line):
    rlm_detected = True  # WRONG!

# Example where this fails:
# Opening: -7, Current: -8
# abs(-7) = 7, abs(-8) = 8
# 7 > 8 is False, but line moved WITH public (correct direction)
```

### ✅ CORRECT: Compare actual values with direction
```python
# CORRECT
if public_side == 'favorite':
    if current_line > opening_line:  # Line became less negative
        rlm_detected = True
```

### ❌ WRONG: Ignoring public percentage
```python
# INCORRECT - RLM requires lopsided public betting
if current_line != opening_line:
    rlm_detected = True  # WRONG! Need to check public %
```

### ✅ CORRECT: Check public threshold
```python
# CORRECT
if public_pct >= 65 and movement_indicates_rlm:
    rlm_detected = True
```

### ❌ WRONG: Not accounting for totals (O/U)
```python
# For totals, RLM logic is different!
# Opening total: 225
# Current total: 227
# Public: 75% on Over
# Movement: Line went UP → harder for Over → NORMAL (not RLM)
```

## RLM for Totals (Over/Under)

**Different logic required:**

```python
def detect_rlm_totals(
    opening_total: float,
    current_total: float,
    public_pct: float,
    public_side: str  # 'over' or 'under'
):
    movement = current_total - opening_total
    
    if public_side == 'over':
        # Public on Over
        # Normal: Total goes UP (harder for Over)
        # RLM: Total goes DOWN (easier for Over)
        if movement < 0:  # Total decreased
            return True  # RLM detected
    
    elif public_side == 'under':
        # Public on Under
        # Normal: Total goes DOWN (harder for Under)
        # RLM: Total goes UP (easier for Under)
        if movement > 0:  # Total increased
            return True  # RLM detected
    
    return False
```

## RLM Severity Levels

### Moderate RLM (0.5 - 1.0 points)
- Worth noting
- May indicate some sharp action
- **Action:** Monitor closely

### Strong RLM (1.0 - 2.0 points)
- Significant sharp action
- Line moved substantially against public
- **Action:** Consider betting with sharp side

### Extreme RLM (2.0+ points)
- Very unusual
- Major sharp money or news
- **Action:** Investigate why (injury, weather, etc.)

## What RLM Is NOT

1. **NOT a guaranteed winner** - Sharp bettors lose too
2. **NOT the only factor** - Use with other analysis
3. **NOT always available** - Need betting percentage data
4. **NOT the same as steam moves** - RLM is gradual, steam is sudden

## How to Use RLM in Your System

### Step 1: Collect Required Data
```python
required_data = {
    'opening_spread': -7.0,
    'current_spread': -5.5,
    'tickets_pct_favorite': 75,  # or tickets_pct_away
    'money_pct_favorite': 78,    # often differs from tickets
}
```

### Step 2: Determine Public Side
```python
# Usually, public is on favorite
# But check both tickets AND money percentages
if tickets_pct_favorite >= 60:
    public_side = 'favorite'
else:
    public_side = 'underdog'
```

### Step 3: Detect RLM
```python
rlm = detect_reverse_line_movement(
    opening_line=opening_spread,
    current_line=current_spread,
    public_pct=tickets_pct_favorite,
    public_side=public_side
)
```

### Step 4: Take Action
```python
if rlm['rlm_detected']:
    if rlm['severity'] == 'extreme':
        # Flag as high-priority sharp play
        alert_user('Extreme RLM detected!')
    
    # Consider betting the sharp side (opposite of public)
    sharp_side = 'underdog' if public_side == 'favorite' else 'favorite'
```

## Integration with Your System

### Add RLM Flag to Games
```python
class Game:
    # Existing fields
    spread_line: float
    opening_spread: float
    tickets_pct: float
    
    # New RLM fields
    rlm_detected: bool = False
    rlm_severity: str = 'none'
    rlm_explanation: str = ''
    
    def check_rlm(self):
        """Check for reverse line movement."""
        if not self.opening_spread or not self.spread_line:
            return
        
        # Determine public side
        public_side = 'favorite' if self.tickets_pct >= 50 else 'underdog'
        public_pct = self.tickets_pct if public_side == 'favorite' else (100 - self.tickets_pct)
        
        # Detect RLM
        rlm = detect_reverse_line_movement(
            opening_line=self.opening_spread,
            current_line=self.spread_line,
            public_pct=public_pct,
            public_side=public_side
        )
        
        # Update game fields
        self.rlm_detected = rlm['rlm_detected']
        self.rlm_severity = rlm['severity']
        self.rlm_explanation = rlm['explanation']
```

## RLM Red Flags (Additional Checks)

### Check 1: Steam Moves
- Line moved 1+ points in <5 minutes
- Usually NOT RLM (too fast)
- Indicates breaking news or sharp consensus

### Check 2: Injury News
- Major player out → Line should move significantly
- If line doesn't move much → May be priced in

### Check 3: Weather
- Bad weather → Totals typically move lower
- If total moves higher despite bad weather → Investigate

### Check 4: Professional Bettors
- Some books display "sharp money percentage"
- If sharp money conflicts with public → Strong RLM signal

## Summary: RLM Checklist

Before flagging RLM, verify:

- ✅ Public betting is lopsided (≥60% one side)
- ✅ Line moved meaningfully (≥0.5 points)
- ✅ Line moved OPPOSITE to public money
- ✅ Movement is recent (not from days ago)
- ✅ No major news explains the movement
- ✅ Not a steam move (gradual, not sudden)

## Code Implementation Checklist

When implementing RLM detection:

- ✅ Store opening line (from first scrape)
- ✅ Track current line (update regularly)
- ✅ Get betting percentages (tickets AND money)
- ✅ Determine which side is public (≥60%)
- ✅ Compare line movement to public direction
- ✅ Flag games with RLM
- ✅ Display RLM severity to user
- ✅ Log RLM results for tracking accuracy

---

**Remember:** RLM is a tool, not a crystal ball. Use it alongside your other analysis (trends, matchups, stats) for best results.
