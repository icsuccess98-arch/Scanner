# SPREAD CALCULATION FIX - APPLY THESE CHANGES TO sports_app.py

## FIX #1: Lower Favorite Margin Threshold (Lines 4321 & 4354)

### Change at Line 4321:
```python
# FIND THIS CODE:
        if is_home_favorite:
            # HOME FAVORITE: Must cover their spread (70% threshold)
            margin_threshold = abs(spread_line) * 0.70
            if home_avg_margin < margin_threshold:

# REPLACE WITH:
        if is_home_favorite:
            # HOME FAVORITE: Must cover their spread (50% threshold)
            margin_threshold = abs(spread_line) * 0.50
            if home_avg_margin < margin_threshold:
                result["reason"] = f"HOME_FAV_MARGIN_BELOW_50%: {home_avg_margin:.1f} < {margin_threshold:.1f}"
```

### Change at Line 4354:
```python
# FIND THIS CODE:
        if is_away_favorite:
            # AWAY FAVORITE: Must cover their spread (70% threshold)
            margin_threshold = abs(spread_line) * 0.70
            if away_avg_margin < margin_threshold:

# REPLACE WITH:
        if is_away_favorite:
            # AWAY FAVORITE: Must cover their spread (50% threshold)
            margin_threshold = abs(spread_line) * 0.50
            if away_avg_margin < margin_threshold:
                result["reason"] = f"AWAY_FAV_MARGIN_BELOW_50%: {away_avg_margin:.1f} < {margin_threshold:.1f}"
```

---

## FIX #2 (OPTIONAL): Improve Direction Logic (Lines 685-692)

This fix makes the direction determination more robust and less likely to skip valid picks.

### Find this code block around line 685:
```python
    projected_margin = (home_ppg - away_opp) - (away_ppg - home_opp)
    
    edge = abs(projected_margin - spread_line)
    result['spread_edge'] = round(edge, 1)
    
    if projected_margin > spread_line + 0.5:
        result['spread_direction'] = 'HOME'
    elif projected_margin < spread_line - 0.5:
        result['spread_direction'] = 'AWAY'
    else:
        result['spread_direction'] = None
        logger.info(f"Spread edge too small for {away_team} @ {home_team}: {edge:.1f}")
        return result
    
    threshold = GameConstants.EDGE_THRESHOLDS.get(league, 8.0)
```

### Replace with this improved logic:
```python
    projected_margin = (home_ppg - away_opp) - (away_ppg - home_opp)
    
    edge = abs(projected_margin - spread_line)
    result['spread_edge'] = round(edge, 1)
    
    # Improved direction logic - determine which team the model favors
    # and check if there's sufficient edge
    threshold = GameConstants.EDGE_THRESHOLDS.get(league, 8.0)
    
    if edge < threshold:
        # Not enough edge to qualify
        result['spread_direction'] = None
        logger.info(f"Spread edge too small for {away_team} @ {home_team}: {edge:.1f} < {threshold}")
        return result
    
    # Sufficient edge exists - determine direction based on projection
    if projected_margin > spread_line:
        # Model favors HOME more than the line suggests
        result['spread_direction'] = 'HOME'
        logger.info(f"HOME pick: {home_team} projected margin {projected_margin:.1f} > spread {spread_line:.1f}")
    elif projected_margin < spread_line:
        # Model favors AWAY more than the line suggests  
        result['spread_direction'] = 'AWAY'
        logger.info(f"AWAY pick: {away_team} projected margin {projected_margin:.1f} < spread {spread_line:.1f}")
    else:
        # Exactly on the line (rare)
        result['spread_direction'] = None
        logger.info(f"Spread exactly on projection for {away_team} @ {home_team}")
        return result
```

---

## COMPLETE FUNCTION REPLACEMENT (Lines 4266-4385)

If you want to replace the entire qualification function for better logic, here's the improved version:

```python
def qualify_spread_pick(
    spread_direction: str,
    spread_line: float,
    home_avg_margin: float,
    away_avg_margin: float,
    home_recent_margin: float,
    away_recent_margin: float,
    home_form_trending: str,
    away_form_trending: str,
    injury_data: dict
) -> dict:
    """
    IMPROVED: Qualification logic for spread picks.
    
    Changes from original:
    - Lowered favorite threshold from 70% to 50%
    - Added recent form weighting
    - Better logging for debugging
    
    Returns:
        dict with keys: qualified (bool), reason (str), confidence (str)
    """
    result = {
        "qualified": False,
        "reason": "",
        "confidence": "LOW"
    }
    
    if not spread_direction:
        result["reason"] = "NO_DIRECTION_SET"
        return result
    
    logger.info(f"Qualifying {spread_direction} spread pick: line={spread_line:.1f}, "
               f"home_margin={home_avg_margin:.1f}, away_margin={away_avg_margin:.1f}")
    
    if spread_direction == "HOME":
        # spread_line > 0 means HOME is favorite, < 0 means HOME is underdog
        is_home_favorite = spread_line < 0  # Fixed: negative spread means favorite
        
        if is_home_favorite:
            # HOME FAVORITE: Must cover their spread (50% threshold)
            margin_threshold = abs(spread_line) * 0.50
            
            # Use recent form if trending up, otherwise use season average
            check_margin = home_recent_margin if home_form_trending == "UP" else home_avg_margin
            
            if check_margin < margin_threshold:
                result["reason"] = (f"HOME_FAV_MARGIN_BELOW_50%: "
                                   f"margin={check_margin:.1f} < threshold={margin_threshold:.1f}")
                logger.info(result["reason"])
                return result
            
            logger.info(f"HOME favorite qualified: margin={check_margin:.1f} >= {margin_threshold:.1f}")
        else:
            # HOME UNDERDOG: Must have positive margin (not a losing team)
            if home_avg_margin <= 0:
                result["reason"] = f"HOME_DOG_NEGATIVE_MARGIN: {home_avg_margin:.1f}"
                logger.info(result["reason"])
                return result
            
            logger.info(f"HOME underdog qualified: positive margin={home_avg_margin:.1f}")
        
        # Check form trend for favorites
        if is_home_favorite and home_form_trending == "DOWN":
            if home_recent_margin < abs(spread_line) * 0.3:
                result["reason"] = (f"HOME_FAV_FORM_DECLINING: "
                                   f"recent={home_recent_margin:.1f} < 30% of spread")
                logger.info(result["reason"])
                return result
        
        # Check injuries
        team_injury = injury_data.get("home", {})
        if team_injury.get("has_key_injuries") or team_injury.get("star_out"):
            result["reason"] = f"HOME_KEY_INJURIES: impact={team_injury.get('impact_score', 0)}"
            logger.info(result["reason"])
            return result
        
        # QUALIFIED
        result["qualified"] = True
        result["reason"] = f"HOME_{'FAVORITE' if is_home_favorite else 'UNDERDOG'}_QUALIFIED"
        
        # Set confidence based on form and margin
        if home_form_trending == "UP" and home_avg_margin >= abs(spread_line) * 0.8:
            result["confidence"] = "HIGH"
        elif home_avg_margin >= abs(spread_line) * 0.5:
            result["confidence"] = "MEDIUM"
        else:
            result["confidence"] = "LOW"
        
        logger.info(f"✓ HOME QUALIFIED: confidence={result['confidence']}")
            
    elif spread_direction == "AWAY":
        # spread_line < 0 means AWAY is favorite, > 0 means AWAY is underdog
        is_away_favorite = spread_line > 0  # Fixed: positive spread means away is favorite
        
        if is_away_favorite:
            # AWAY FAVORITE: Must cover their spread (50% threshold)
            margin_threshold = abs(spread_line) * 0.50
            
            # Use recent form if trending up
            check_margin = away_recent_margin if away_form_trending == "UP" else away_avg_margin
            
            if check_margin < margin_threshold:
                result["reason"] = (f"AWAY_FAV_MARGIN_BELOW_50%: "
                                   f"margin={check_margin:.1f} < threshold={margin_threshold:.1f}")
                logger.info(result["reason"])
                return result
            
            logger.info(f"AWAY favorite qualified: margin={check_margin:.1f} >= {margin_threshold:.1f}")
        else:
            # AWAY UNDERDOG: Must have positive margin
            if away_avg_margin <= 0:
                result["reason"] = f"AWAY_DOG_NEGATIVE_MARGIN: {away_avg_margin:.1f}"
                logger.info(result["reason"])
                return result
            
            logger.info(f"AWAY underdog qualified: positive margin={away_avg_margin:.1f}")
        
        # Check form trend for favorites
        if is_away_favorite and away_form_trending == "DOWN":
            if away_recent_margin < 0:
                result["reason"] = f"AWAY_FAV_FORM_DECLINING: recent={away_recent_margin:.1f} < 0"
                logger.info(result["reason"])
                return result
        
        # Check injuries
        team_injury = injury_data.get("away", {})
        if team_injury.get("has_key_injuries") or team_injury.get("star_out"):
            result["reason"] = f"AWAY_KEY_INJURIES: impact={team_injury.get('impact_score', 0)}"
            logger.info(result["reason"])
            return result
        
        # QUALIFIED
        result["qualified"] = True
        result["reason"] = f"AWAY_{'FAVORITE' if is_away_favorite else 'UNDERDOG'}_QUALIFIED"
        
        # Set confidence
        if away_form_trending == "UP" and away_avg_margin >= abs(spread_line) * 0.8:
            result["confidence"] = "HIGH"
        elif away_avg_margin >= abs(spread_line) * 0.5:
            result["confidence"] = "MEDIUM"
        else:
            result["confidence"] = "LOW"
        
        logger.info(f"✓ AWAY QUALIFIED: confidence={result['confidence']}")
    
    return result
```

---

## TESTING AFTER CHANGES

After applying the fixes, add these debug logs to verify it's working:

### Add to the calculate_spread_edge function (around line 700):
```python
    if edge >= threshold:
        result['spread_is_qualified'] = True
        result['spread_history_qualified'] = True
        result['spread_ev'] = round(edge * 0.4, 2)
        result['away_spread_pct'] = round(50 + (edge / 2), 1)
        result['home_spread_pct'] = round(50 + (edge / 2), 1)
        
        # ADD THIS DEBUG LOG:
        logger.info(f"✓ SPREAD QUALIFIED: {away_team} @ {home_team}")
        logger.info(f"  Direction: {result['spread_direction']}")
        logger.info(f"  Edge: {edge:.1f}, Threshold: {threshold}")
        logger.info(f"  Projected margin: {projected_margin:.1f}, Line: {spread_line:.1f}")
```

### What you should see in logs after fix:
```
✓ SPREAD QUALIFIED: Iowa @ Purdue
  Direction: HOME
  Edge: 10.5, Threshold: 8.0
  Projected margin: +15.2, Line: -22.0
HOME favorite qualified: margin=13.1 >= 11.0
✓ HOME QUALIFIED: confidence=MEDIUM

✓ SPREAD QUALIFIED: Temple @ Memphis  
  Direction: AWAY
  Edge: 11.5, Threshold: 8.0
  Projected margin: -3.2, Line: +8.0
AWAY underdog qualified: positive margin=4.3
✓ AWAY QUALIFIED: confidence=HIGH
```

---

## VERIFICATION CHECKLIST

After applying fixes, verify:

- [ ] HOME favorite picks are now appearing (e.g., Purdue -22)
- [ ] AWAY favorite picks still work (e.g., Connecticut -15)
- [ ] Both HOME and AWAY underdogs qualify when appropriate
- [ ] Edge calculations haven't changed (still using same thresholds)
- [ ] Confidence levels (HIGH/MEDIUM/LOW) are being set correctly
- [ ] Dashboard shows both HOME and AWAY picks in "Top 5 Plays"

---

## QUICK FIX SUMMARY

**Minimum change to fix the issue:**

1. Change line 4321: `margin_threshold = abs(spread_line) * 0.50`
2. Change line 4354: `margin_threshold = abs(spread_line) * 0.50`

**This alone will unlock HOME favorite picks.**

The other improvements (direction logic, logging) are optional but recommended for better performance and debugging.
