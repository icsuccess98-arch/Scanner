# Quick Implementation Guide - "Closed" Lines & 5-Second Updates

## What Needs to Change

### 1. Database Schema (Game model)
Add these new columns to separate opening/closed/current lines:

```python
# In Game model (sports_app.py)
class Game(db.Model):
    # ... existing fields ...
    
    # Add these NEW fields:
    closed_spread = db.Column(db.Float)           # Final line before game starts
    closed_total = db.Column(db.Float)            # Final total before game starts
    closed_spread_odds = db.Column(db.String(10)) # e.g., "-110"
    closed_total_odds = db.Column(db.String(10))  # e.g., "-110"
    game_started = db.Column(db.Boolean, default=False)  # Track if game started
    
    # Keep these EXISTING fields:
    opening_spread    # First line seen
    opening_total     # First total seen
    spread_line       # Rename to: current_spread (for live updates)
    line              # Rename to: current_total (for live updates)
```

### 2. When Fetching WagerTalk Data

**CURRENT CODE (somewhere in your fetch_rlm_data or similar):**
```python
# This updates continuously
game.spread_line = wt_data['spread']
game.line = wt_data['total']
```

**CHANGE TO:**
```python
# Check if game has started
now = datetime.now(pytz.timezone('America/New_York'))
game_has_started = game.game_time and now >= game.game_time

if not game_has_started:
    # Game hasn't started - update everything
    
    # Set opening lines (first time only)
    if not game.opening_spread:
        game.opening_spread = wt_data['spread']
    if not game.opening_total:
        game.opening_total = wt_data['total']
    
    # Update current lines (for live tracking)
    game.current_spread = wt_data['spread']
    game.current_total = wt_data['total']
    
    # Update closed lines (becomes final when game starts)
    game.closed_spread = wt_data['spread']
    game.closed_total = wt_data['total']
    game.closed_spread_odds = wt_data.get('spread_odds', '-110')
    game.closed_total_odds = wt_data.get('total_odds', '-110')
    
    # Update betting percentages
    game.away_tickets_pct = wt_data['away_tickets_pct']
    game.home_tickets_pct = wt_data['home_tickets_pct']
    game.away_money_pct = wt_data['away_money_pct']
    game.home_money_pct = wt_data['home_money_pct']
    
else:
    # Game started - mark as started, stop updating WagerTalk data
    game.game_started = True
    logger.info(f"{game.away_team} @ {game.home_team} started - closing lines")
    
    # Only update current lines (for line movement display)
    # Get from live odds API (not WagerTalk)
    game.current_spread = live_odds_api.get_spread()
    game.current_total = live_odds_api.get_total()
```

### 3. Template Changes (HTML)

**FIND THIS (in your betting action template):**
```html
<div class="spread">
    <span>Now: -3 (-110)</span>
</div>

<div class="total">
    <span>Open: 225.5</span>
    <span>Current: 225.5 (-110)</span>
</div>

<div class="line-movement">
    <span>LINE MOVEMENT (UPDATES EVERY 30S)</span>
    <span>Open: Bucks -3</span>
    <span>Current: Bucks -3</span>
</div>
```

**REPLACE WITH:**
```html
<!-- LINE MOVEMENT SECTION - Always live, updates every 5s -->
<div class="line-movement">
    <h4>📊 LINE MOVEMENT</h4>
    <div class="line-row">
        <span>OPEN</span>
        <span class="dot">•</span>
        <span>CURRENT</span>
    </div>
    <div class="line-row">
        <span>{{ game.away_team }} {{ game.opening_spread }}</span>
        <span class="dot">•</span>
        <span id="live-spread-{{ game.id }}">
            {{ game.away_team }} {{ game.current_spread }}
        </span>
    </div>
    <!-- NO TEXT about update frequency -->
</div>

<!-- BETTING ACTION - Static after game starts -->
<div class="betting-action">
    <h4>🔥 BETTING ACTION</h4>
    
    <!-- SPREAD -->
    <div class="spread-section">
        <h5>SPREAD</h5>
        <div>Opened: {{ game.away_team }} {{ game.opening_spread }}</div>
        <div>
            {% if game.game_started %}
                Closed: {{ game.away_team }} {{ game.closed_spread }} ({{ game.closed_spread_odds }})
            {% else %}
                Current: {{ game.away_team }} {{ game.closed_spread }} ({{ game.closed_spread_odds }})
            {% endif %}
        </div>
        
        <div class="percentages">
            <div>{{ game.away_team }}: Tickets {{ game.away_tickets_pct }}%, Money {{ game.away_money_pct }}%</div>
            <div>{{ game.home_team }}: Tickets {{ game.home_tickets_pct }}%, Money {{ game.home_money_pct }}%</div>
        </div>
    </div>
    
    <!-- TOTAL -->
    <div class="total-section">
        <h5>GAME TOTAL</h5>
        <div>Opened: {{ game.opening_total }}</div>
        <div>
            {% if game.game_started %}
                Closed: {{ game.closed_total }} ({{ game.closed_total_odds }})
            {% else %}
                Current: {{ game.closed_total }} ({{ game.closed_total_odds }})
            {% endif %}
        </div>
        
        <div class="percentages">
            <div>OVER: Tickets {{ game.over_tickets_pct }}%, Money {{ game.over_money_pct }}%</div>
            <div>UNDER: Tickets {{ game.under_tickets_pct }}%, Money {{ game.under_money_pct }}%</div>
        </div>
    </div>
</div>
```

### 4. JavaScript for Live Updates (5 seconds)

**FIND THIS:**
```javascript
// Update every 30 seconds
setInterval(updateLines, 30000);
```

**REPLACE WITH:**
```javascript
// Update every 5 seconds (fast and efficient)
function updateLiveLines() {
    fetch('/api/live_lines')
        .then(response => response.json())
        .then(data => {
            data.games.forEach(game => {
                // Update ONLY the current spread in line movement section
                const spreadEl = document.getElementById(`live-spread-${game.id}`);
                if (spreadEl) {
                    spreadEl.textContent = `${game.away_team} ${game.current_spread}`;
                }
                
                // Update ONLY the current total in line movement section
                const totalEl = document.getElementById(`live-total-${game.id}`);
                if (totalEl) {
                    totalEl.textContent = game.current_total;
                }
            });
        })
        .catch(err => console.error('Error updating lines:', err));
}

// Update every 5 seconds
setInterval(updateLiveLines, 5000);

// Initial load
updateLiveLines();
```

### 5. API Endpoint for Live Lines

**ADD THIS NEW ENDPOINT:**
```python
@app.route('/api/live_lines')
def api_live_lines():
    """
    Fast API endpoint for live line updates.
    Returns ONLY current lines, not betting percentages or static data.
    This should be VERY fast - under 100ms response time.
    """
    et = pytz.timezone('America/New_York')
    today = datetime.now(et).date()
    
    games = Game.query.filter_by(date=today).all()
    
    result = {
        'games': [
            {
                'id': g.id,
                'away_team': g.away_team,
                'home_team': g.home_team,
                'current_spread': float(g.current_spread) if g.current_spread else None,
                'current_total': float(g.current_total) if g.current_total else None,
                'game_started': g.game_started
            }
            for g in games
        ],
        'timestamp': datetime.now(et).isoformat()
    }
    
    return jsonify(result)
```

## Migration Steps

### Step 1: Add Database Columns
```bash
# In your terminal
flask db migrate -m "Add closed lines and game_started"
flask db upgrade
```

Or manually in SQL:
```sql
ALTER TABLE game ADD COLUMN closed_spread FLOAT;
ALTER TABLE game ADD COLUMN closed_total FLOAT;
ALTER TABLE game ADD COLUMN closed_spread_odds VARCHAR(10);
ALTER TABLE game ADD COLUMN closed_total_odds VARCHAR(10);
ALTER TABLE game ADD COLUMN game_started BOOLEAN DEFAULT FALSE;
```

### Step 2: Rename Existing Columns (Optional)
```sql
-- If you want clearer names
ALTER TABLE game RENAME COLUMN spread_line TO current_spread;
ALTER TABLE game RENAME COLUMN line TO current_total;
```

### Step 3: Update Existing Games
```python
# Run this once to populate closed lines for today's games
from sports_app import db, Game
from datetime import datetime
import pytz

et = pytz.timezone('America/New_York')
today = datetime.now(et).date()

for game in Game.query.filter_by(date=today).all():
    # Set closed lines from current lines
    if not game.closed_spread:
        game.closed_spread = game.spread_line  # or current_spread
    if not game.closed_total:
        game.closed_total = game.line  # or current_total
    
    # Check if game started
    if game.game_time:
        now = datetime.now(et)
        if now >= game.game_time:
            game.game_started = True

db.session.commit()
```

### Step 4: Test

1. **Before game starts:**
   - Should see "Current: -1.5" (not "Closed")
   - WagerTalk data should update
   - Line movement should update every 5s

2. **After game starts:**
   - Should see "Closed: -1.5" (not "Current")
   - WagerTalk data should NOT update (locked)
   - Line movement should STILL update every 5s

3. **Check no "(UPDATES EVERY 30S)" text appears**

## Summary Checklist

- [ ] Add 5 new database columns
- [ ] Update WagerTalk fetch logic to check game_started
- [ ] Change template to show "Opened/Closed" instead of "Now/Current"
- [ ] Remove "(UPDATES EVERY 30S)" text
- [ ] Change JavaScript from 30s to 5s interval
- [ ] Add /api/live_lines endpoint
- [ ] Test before and after game starts
- [ ] Verify line movement updates every 5s
- [ ] Verify betting action stays static after game starts

## Visual Result

**BEFORE:**
```
Now: -3 (-110)                    ❌
Open: 225.5
Current: 225.5 (-110)             ❌
LINE MOVEMENT (UPDATES EVERY 30S) ❌
```

**AFTER:**
```
📊 LINE MOVEMENT
Open: -3  •  Current: -1.5        ✅
(no update text)                   ✅

🔥 BETTING ACTION
Opened: -3                         ✅
Closed: -1.5 (-110)               ✅

Opened: 225.5                      ✅
Closed: 223.5 (-110)              ✅
```
