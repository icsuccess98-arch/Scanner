# =============================================================================
# FIX: Label "Closed" Lines & Fast Live Line Updates (5 seconds)
# =============================================================================
#
# ISSUE 1: "Now" and "Current" should say "Closed" once game starts
# ISSUE 2: Line movement should update every 5 seconds (not 30)
# ISSUE 3: Remove "(UPDATES EVERY 30S)" text
#
# =============================================================================

"""
CHANGES NEEDED:

1. Betting Action data (WagerTalk) = CLOSED once game starts
   - These don't update during the game
   - Label as "Closed: -1.5" instead of "Now: -1.5"
   - Label as "Closed: 223.5" instead of "Current: 223.5"

2. Line Movement section = LIVE updates every 5 seconds
   - This DOES update during the game
   - Shows current line at time of refresh
   - Update frequency: 5 seconds (fast and efficient)
   - Remove the "(UPDATES EVERY 30S)" text

VISUAL LAYOUT:

┌─────────────────────────────────────────┐
│ 📊 LINE MOVEMENT                        │
│                                         │
│ OPEN          CURRENT                   │
│ Bucks -3  •   Bucks -1.5               │
│                                         │
│ ↻ Updates automatically                 │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 🔥 BETTING ACTION                       │
│                                         │
│ SPREAD                                  │
│ Opened: Bucks -3                        │
│ Closed: Bucks -1.5 (-110)              │
│                                         │
│ Bucks    Tickets: 60%  Money: 68%      │
│ Wizards  Tickets: 40%  Money: 32%      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ GAME TOTAL                              │
│ Opened: 225.5                           │
│ Closed: 223.5 (-110)                    │
│                                         │
│ OVER 223.5   Tickets: 22%  Money: 22%  │
│ UNDER 223.5  Tickets: 78%  Money: 78%  │
└─────────────────────────────────────────┘
"""

# =============================================================================
# PART 1: Template Changes (HTML/JavaScript)
# =============================================================================

TEMPLATE_FIX = """
<!-- In your betting_action.html or wherever this section is -->

<!-- LINE MOVEMENT SECTION - Updates every 5 seconds -->
<div class="line-movement-section">
    <h3>📊 LINE MOVEMENT</h3>
    <div class="line-display" data-refresh="5">
        <div class="line-row">
            <span class="label">OPEN</span>
            <span class="label">CURRENT</span>
        </div>
        <div class="line-row spread-line">
            <span class="open-line">{{ game.away_team }} {{ game.opening_spread }}</span>
            <span class="dot">•</span>
            <span class="current-line" id="live-spread-{{ game.id }}">
                {{ game.away_team }} {{ game.current_spread }}
            </span>
        </div>
    </div>
    <!-- NO TEXT saying "updates every 30s" -->
</div>

<!-- BETTING ACTION SECTION - Static after game starts -->
<div class="betting-action-section">
    <h3>🔥 BETTING ACTION</h3>
    
    <!-- SPREAD -->
    <div class="spread-section">
        <h4>SPREAD</h4>
        <div class="line-row">
            <span class="label">Opened:</span>
            <span class="value">{{ game.away_team }} {{ game.spread_open_line }}</span>
        </div>
        <div class="line-row">
            <span class="label">Closed:</span>
            <span class="value">{{ game.away_team }} {{ game.spread_closed_line }} ({{ game.spread_closed_odds }})</span>
        </div>
        
        <!-- Betting percentages -->
        <div class="betting-pcts">
            <div class="team-row">
                <span class="team">{{ game.away_team }}</span>
                <span class="tickets">Tickets: {{ game.away_tickets_pct }}%</span>
                <span class="money">Money: {{ game.away_money_pct }}%</span>
            </div>
            <div class="team-row">
                <span class="team">{{ game.home_team }}</span>
                <span class="tickets">Tickets: {{ game.home_tickets_pct }}%</span>
                <span class="money">Money: {{ game.home_money_pct }}%</span>
            </div>
        </div>
    </div>
    
    <!-- GAME TOTAL -->
    <div class="total-section">
        <h4>GAME TOTAL</h4>
        <div class="line-row">
            <span class="label">Opened:</span>
            <span class="value">{{ game.total_open_line }}</span>
        </div>
        <div class="line-row">
            <span class="label">Closed:</span>
            <span class="value">{{ game.total_closed_line }} ({{ game.total_closed_odds }})</span>
        </div>
        
        <!-- Over/Under percentages -->
        <div class="betting-pcts">
            <div class="team-row">
                <span class="team">OVER {{ game.total_closed_line }}</span>
                <span class="tickets">Tickets: {{ game.over_tickets_pct }}%</span>
                <span class="money">Money: {{ game.over_money_pct }}%</span>
            </div>
            <div class="team-row">
                <span class="team">UNDER {{ game.total_closed_line }}</span>
                <span class="tickets">Tickets: {{ game.under_tickets_pct }}%</span>
                <span class="money">Money: {{ game.under_money_pct }}%</span>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for LIVE updates (5 seconds) -->
<script>
// Update live lines every 5 seconds (not 30)
function updateLiveLines() {
    fetch('/api/live_lines')
        .then(response => response.json())
        .then(data => {
            data.games.forEach(game => {
                // Update only the CURRENT spread (not the betting action)
                const spreadElement = document.getElementById(`live-spread-${game.id}`);
                if (spreadElement) {
                    spreadElement.textContent = `${game.away_team} ${game.current_spread}`;
                }
                
                // Update only the CURRENT total
                const totalElement = document.getElementById(`live-total-${game.id}`);
                if (totalElement) {
                    totalElement.textContent = game.current_total;
                }
            });
        })
        .catch(error => console.error('Error updating lines:', error));
}

// Update every 5 seconds (was 30)
setInterval(updateLiveLines, 5000);

// Initial load
updateLiveLines();
</script>
"""

# =============================================================================
# PART 2: Backend Changes (Python)
# =============================================================================

BACKEND_FIX = """
# In your sports_app.py, update the game object to have separate fields

class Game(db.Model):
    # ... existing fields ...
    
    # Opening lines (never change)
    opening_spread = db.Column(db.Float)
    opening_total = db.Column(db.Float)
    
    # Closing lines (WagerTalk final line before game starts)
    closed_spread = db.Column(db.Float)
    closed_total = db.Column(db.Float)
    closed_spread_odds = db.Column(db.String(10))
    closed_total_odds = db.Column(db.String(10))
    
    # Live lines (updates during game for LINE MOVEMENT section only)
    current_spread = db.Column(db.Float)
    current_total = db.Column(db.Float)
    
    # Betting percentages (from WagerTalk, don't update after game starts)
    away_tickets_pct = db.Column(db.Float)
    home_tickets_pct = db.Column(db.Float)
    away_money_pct = db.Column(db.Float)
    home_money_pct = db.Column(db.Float)
    over_tickets_pct = db.Column(db.Float)
    under_tickets_pct = db.Column(db.Float)
    over_money_pct = db.Column(db.Float)
    under_money_pct = db.Column(db.Float)
    
    # Game state
    game_started = db.Column(db.Boolean, default=False)
    
    def update_from_wagertalk(self, wt_data):
        '''
        Update betting action data from WagerTalk.
        This only updates BEFORE game starts.
        Once game starts, these values are "closed" and don't change.
        '''
        if self.game_started:
            logger.info(f"Game already started, not updating WagerTalk data")
            return
        
        # Store opening lines (first time only)
        if not self.opening_spread and wt_data.get('spread'):
            self.opening_spread = wt_data['spread']
        if not self.opening_total and wt_data.get('total'):
            self.opening_total = wt_data['total']
        
        # Update closed lines (WagerTalk's current line becomes "closed" when game starts)
        self.closed_spread = wt_data.get('spread')
        self.closed_total = wt_data.get('total')
        self.closed_spread_odds = wt_data.get('spread_odds', '-110')
        self.closed_total_odds = wt_data.get('total_odds', '-110')
        
        # Update betting percentages
        self.away_tickets_pct = wt_data.get('away_tickets_pct')
        self.home_tickets_pct = wt_data.get('home_tickets_pct')
        self.away_money_pct = wt_data.get('away_money_pct')
        self.home_money_pct = wt_data.get('home_money_pct')
        self.over_tickets_pct = wt_data.get('over_tickets_pct')
        self.under_tickets_pct = wt_data.get('under_tickets_pct')
        self.over_money_pct = wt_data.get('over_money_pct')
        self.under_money_pct = wt_data.get('under_money_pct')
    
    def update_live_lines(self, live_data):
        '''
        Update ONLY the current lines for LINE MOVEMENT display.
        This updates every 5 seconds, even during the game.
        Does NOT update betting percentages or "closed" lines.
        '''
        # Update current lines from live odds feed
        self.current_spread = live_data.get('spread')
        self.current_total = live_data.get('total')
        
        # Do NOT update betting percentages here


# API endpoint for live line updates (5 second refresh)
@app.route('/api/live_lines')
def api_live_lines():
    '''
    Return ONLY current lines for fast updates.
    Does not include betting percentages or other static data.
    '''
    today = datetime.now(pytz.timezone('America/New_York')).date()
    games = Game.query.filter_by(date=today).all()
    
    result = {
        'games': [
            {
                'id': game.id,
                'away_team': game.away_team,
                'home_team': game.home_team,
                'current_spread': game.current_spread,
                'current_total': game.current_total,
                'game_started': game.game_started
            }
            for game in games
        ],
        'timestamp': datetime.now().isoformat()
    }
    
    return jsonify(result)


# When fetching WagerTalk data (before game starts)
def fetch_wagertalk_data(league='NBA'):
    '''
    Fetch betting action from WagerTalk.
    Only updates if game hasn't started.
    '''
    from wagertalk_scraper import get_wagertalk_odds
    
    wt_data = get_wagertalk_odds(league)
    
    for game in Game.query.filter_by(date=today, league=league).all():
        # Check if game has started
        if game.game_time:
            game_time = game.game_time
            now = datetime.now(pytz.timezone('America/New_York'))
            
            if now >= game_time:
                game.game_started = True
                logger.info(f"{game.away_team} @ {game.home_team} has started - closing betting action")
            else:
                # Game hasn't started yet, update from WagerTalk
                matchup_key = f"{game.away_team}_vs_{game.home_team}".lower()
                if matchup_key in wt_data:
                    game.update_from_wagertalk(wt_data[matchup_key])
    
    db.session.commit()


# When fetching live odds (every 5 seconds)
def fetch_live_odds(league='NBA'):
    '''
    Fetch ONLY current lines from odds API.
    Fast and efficient - just the numbers, no betting percentages.
    '''
    # Use a fast odds API (like Odds API, The Rundown, etc.)
    # This should be FAST - just grab current spread and total
    
    for game in Game.query.filter_by(date=today, league=league).all():
        # Get current lines from odds feed
        current_lines = get_current_odds_fast(game.away_team, game.home_team)
        
        if current_lines:
            game.update_live_lines(current_lines)
    
    db.session.commit()
"""

# =============================================================================
# PART 3: Summary of Changes
# =============================================================================

SUMMARY = """
=============================================================================
SUMMARY: 3 Key Changes
=============================================================================

1. TERMINOLOGY CHANGE
   Before game starts:
   - "Opening: -3" → First line seen
   - "Current: -1.5" → Most recent line
   
   After game starts:
   - "Opened: -3" → First line (never changes)
   - "Closed: -1.5" → Final line before game (never changes)
   
   Line Movement section (always live):
   - "Open: -3" → Opening line
   - "Current: -1.5" → Real-time line (updates every 5s)

2. UPDATE FREQUENCY
   - Betting Action section: NO updates after game starts (static)
   - Line Movement section: Updates every 5 seconds (was 30)
   - Remove "(UPDATES EVERY 30S)" text completely

3. DATA SEPARATION
   - opening_spread / opening_total → Never changes
   - closed_spread / closed_total → Set when game starts, never changes
   - current_spread / current_total → Updates every 5s for line movement
   - Betting percentages → From WagerTalk, don't update after game starts

=============================================================================
DISPLAY LOGIC
=============================================================================

BEFORE GAME STARTS:
┌────────────────────────────────┐
│ LINE MOVEMENT                  │
│ Open: -3  •  Current: -1.5    │
│ ↻ Live updates                 │
└────────────────────────────────┘
┌────────────────────────────────┐
│ SPREAD                         │
│ Opened: -3                     │
│ Current: -1.5 (-110)           │ ← Updates from WagerTalk
│                                │
│ Bucks: 60% / 68%              │ ← Updates from WagerTalk
└────────────────────────────────┘

AFTER GAME STARTS:
┌────────────────────────────────┐
│ LINE MOVEMENT                  │
│ Open: -3  •  Current: -0.5    │ ← Still updating (live odds)
│ ↻ Live updates                 │
└────────────────────────────────┘
┌────────────────────────────────┐
│ SPREAD                         │
│ Opened: -3                     │
│ Closed: -1.5 (-110)           │ ← LOCKED (no more updates)
│                                │
│ Bucks: 60% / 68%              │ ← LOCKED (no more updates)
└────────────────────────────────┘

=============================================================================
"""

print(SUMMARY)
