# WagerTalk Scraper Update Guide

## Problem
The old WagerTalk URLs are returning 404 errors:
- ❌ `https://www.wagertalk.com/nba-betting-splits` → 404 Not Found
- ❌ Action Network API → 404 Not Found

## Solution
Updated scraper uses the WagerTalk odds page which is publicly available:
- ✅ `https://www.wagertalk.com/odds` → Works!

## What Changed

### Old Approach (Broken)
```python
# wagertalk_production_api.py or similar
url = "https://www.wagertalk.com/nba-betting-splits"  # 404 ERROR
```

### New Approach (Working)
```python
# wagertalk_scraper_UPDATED.py
url = "https://www.wagertalk.com/odds"  # Uses main odds page
# Parses the NBA section from the dynamic table
```

## Integration Steps

### Step 1: Replace the Scraper File

**Option A - Complete Replacement:**
```bash
# Backup old file
cp wagertalk_scraper.py wagertalk_scraper_OLD.py

# Replace with updated version
cp wagertalk_scraper_UPDATED.py wagertalk_scraper.py
```

**Option B - Update Existing Code:**
If you have customizations in the old file, update just the URL and parsing logic:

```python
# OLD CODE - REMOVE THIS:
url = "https://www.wagertalk.com/nba-betting-splits"

# NEW CODE - ADD THIS:
url = "https://www.wagertalk.com/odds"
```

### Step 2: Update Function Calls (If Needed)

The new scraper has slightly different function names for clarity:

**Old:**
```python
from wagertalk_scraper import get_all_wagertalk_data
data = get_all_wagertalk_data('NBA')
```

**New:**
```python
from wagertalk_scraper import get_wagertalk_odds, find_game_data

# Get all games
data = get_wagertalk_odds('NBA')

# Or find specific game
game = find_game_data('Bucks', 'Wizards', 'NBA')
```

### Step 3: Update Data Structure Handling

The returned data structure is similar but cleaner:

**Old format:**
```python
{
    'Bucks vs Wizards': {
        'tickets_away': 52,
        'tickets_home': 48,
        'money_away': 55,
        'money_home': 45,
        # ... other fields
    }
}
```

**New format:**
```python
{
    'Bucks vs Wizards': {
        'away_team': 'Bucks',
        'home_team': 'Wizards',
        'away_tickets_pct': 52,
        'home_tickets_pct': 48,
        'away_money_pct': 55,
        'home_money_pct': 45,
    }
}
```

## Testing the Updated Scraper

### Test 1: Verify Playwright is Installed

```bash
# Check if Playwright is installed
python -c "import playwright; print('✓ Playwright installed')"

# If not installed:
pip install playwright --break-system-packages
playwright install chromium
```

### Test 2: Run Standalone Test

```bash
# Test the scraper directly
python wagertalk_scraper_UPDATED.py
```

Expected output:
```
Fetching WagerTalk odds data...
[WagerTalk] Launching browser...
[WagerTalk] Navigating to https://www.wagertalk.com/odds
[WagerTalk] Waiting for NBA odds table...
[WagerTalk] Found Bucks vs Wizards: Tickets 52% / Money 55%
[WagerTalk] Found Heat vs Bulls: Tickets 48% / Money 47%
...
[WagerTalk] Extracted 8 games from odds page

Found 8 NBA games:

Bucks vs Wizards:
  Tickets: 52% away / 48% home
  Money: 55% away / 45% home
...
```

### Test 3: Integration Test

Update your main app to use the new scraper and test:

```python
# In sports_app.py or wherever you call WagerTalk
from wagertalk_scraper import get_wagertalk_odds

# Fetch data
wt_data = get_wagertalk_odds('NBA')

# Check if we got data
if wt_data:
    print(f"✓ WagerTalk working: {len(wt_data)} games found")
else:
    print("✗ WagerTalk failed: no data returned")
```

## Known Limitations

### 1. Betting Percentages May Not Always Be Available

The `/odds` page sometimes doesn't show betting percentages for all games. This is a WagerTalk limitation, not a scraper issue.

**Workaround:** The scraper will return games with available data. Games without betting percentages will be skipped.

### 2. Page Structure May Change

If WagerTalk updates their page layout, the scraper may need adjustments.

**Indicators:**
- Scraper returns 0 games
- Logs show "Could not find NBA section"

**Fix:** Update the parsing selectors in `_fetch_wagertalk_odds_async()`

### 3. Rate Limiting

WagerTalk may rate limit frequent requests.

**Built-in Protection:**
- 3-minute cache (configurable via `CACHE_TTL`)
- Polite user-agent headers
- Reasonable timeouts

## Deployment Checklist

Before deploying to Cloud Run:

- [ ] Replace wagertalk_scraper.py with updated version
- [ ] Test locally: `python wagertalk_scraper.py`
- [ ] Verify Playwright installs in startup.sh:
  ```bash
  python -m playwright install --with-deps chromium
  ```
- [ ] Update any imports in sports_app.py
- [ ] Test full app locally with Docker
- [ ] Deploy to Cloud Run with VM (gen2)
- [ ] Monitor logs for WagerTalk activity

## Troubleshooting

### "No data found"

**Check:**
1. Is Playwright installed? `python -m playwright install chromium`
2. Are browsers accessible? Check logs for "BrowserType.launch" errors
3. Is WagerTalk blocking requests? Try different user agent
4. Is the page structure different? Inspect live page HTML

### "Playwright executable doesn't exist"

**Fix:**
```bash
# Install Playwright browsers
python -m playwright install --with-deps chromium

# Or in Docker/Cloud Run, add to startup.sh:
python -m playwright install chromium
```

### "Browser launch failed"

**Common Causes:**
- Missing system dependencies (use provided Dockerfile)
- Running in restricted environment
- Out of memory (increase to 2Gi+)

**Fix:** Use the provided Dockerfile with all browser dependencies

### "Timeout waiting for NBA section"

**Possible Issues:**
- Page loading slowly
- WagerTalk changed layout
- Network issues

**Fix:**
- Increase timeout in code: `timeout=30000` → `timeout=60000`
- Check if page loaded: inspect `page.content()` in logs

## Production Recommendations

1. **Use Caching:** The 3-minute cache reduces load on WagerTalk
2. **Monitor Logs:** Watch for "WagerTalk" entries in Cloud Run logs
3. **Fallback Strategy:** If WagerTalk fails, continue without betting percentages
4. **Alert on Failures:** Set up monitoring for repeated WagerTalk errors

## Support

If the updated scraper doesn't work:

1. **Check logs:**
   ```bash
   gcloud run services logs read 730sports --limit 100 | grep -i wagertalk
   ```

2. **Test locally:**
   ```bash
   docker build -t test . && docker run test python wagertalk_scraper.py
   ```

3. **Verify WagerTalk page:**
   - Visit https://www.wagertalk.com/odds in browser
   - Check if NBA games are listed
   - Verify betting percentages are shown

## Next Steps

1. ✅ Download `wagertalk_scraper_UPDATED.py`
2. ✅ Replace old scraper file
3. ✅ Update any function calls if needed
4. ✅ Test locally
5. ✅ Deploy to Cloud Run with VM support
6. ✅ Monitor logs for WagerTalk activity

---

**Key Takeaway:** The new scraper uses `/odds` page which is publicly available and doesn't require authentication. It should work reliably as long as Playwright is properly installed in your Cloud Run environment.
