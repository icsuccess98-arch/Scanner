# 🚀 QUICK START - Deploy Your Fixed App

## ⏱️ 5-Minute Deployment

### Step 1: Backup (30 seconds)
```bash
cd /path/to/your/app
cp instance/730sports.db instance/730sports.db.backup
```

### Step 2: Extract Fixed Files (30 seconds)
```bash
# Unzip the fixed app
unzip sports_app_FIXED.zip

# This will replace:
# - sports_app.py
# - templates/spreads.html
# (Other files are unchanged)
```

### Step 3: Run Database Migration (2 minutes)

**Option A - Using Flask-Migrate:**
```bash
flask db migrate -m "Add betting action columns"
flask db upgrade
```

**Option B - Manual SQL:**
```bash
# For SQLite:
sqlite3 instance/730sports.db < database_migration.sql

# For PostgreSQL:
psql -d your_database -f database_migration.sql
```

### Step 4: Populate Existing Data (1 minute)
```python
# Run this Python script:
from sports_app import app, db, Game
from datetime import datetime
import pytz

with app.app_context():
    games = Game.query.all()
    et = pytz.timezone('America/New_York')
    now = datetime.now(et).date()
    
    for game in games:
        # Populate opening/closed lines
        if game.spread_line and not game.opening_spread:
            game.opening_spread = game.spread_line
            game.closed_spread = game.spread_line
            game.current_spread = game.spread_line
        
        if game.line and not game.opening_total:
            game.opening_total = game.line
            game.closed_total = game.line
            game.current_total = game.line
        
        # Mark past games as started
        if game.date < now:
            game.game_started = True
    
    db.session.commit()
    print(f"✓ Updated {len(games)} games")
```

Save as `populate_data.py` and run:
```bash
python populate_data.py
```

### Step 5: Restart App (30 seconds)
```bash
# If using Gunicorn:
sudo systemctl restart 730sports

# If using Flask dev server:
# Ctrl+C then:
flask run

# If using Replit:
# Just click the Run button
```

### Step 6: Verify (1 minute)
1. Open your app
2. Go to Spreads page
3. Check Bucks @ Wizards game
4. **Should see: RLM FAVOR = Wizards** ✅
5. **Should NOT see: "(Updates every 30s)"** ✅
6. Open DevTools → Network tab
7. **Should see: Requests every ~5 seconds** ✅

---

## ✅ DONE!

Your app now has:
- ✅ Correct RLM detection
- ✅ Proper "Closed" vs "Current" labels
- ✅ 5-second update frequency (was 30s)
- ✅ No more "(Updates every 30s)" text
- ✅ Full betting action tracking

---

## 🆘 QUICK TROUBLESHOOTING

**Problem: "Column does not exist" error**
→ Run: `sqlite3 instance/730sports.db < database_migration.sql`

**Problem: RLM still shows "None"**
→ Run: `python populate_data.py`

**Problem: Still see "(Updates every 30s)"**
→ Hard refresh browser: Ctrl+F5 (Windows) or Cmd+Shift+R (Mac)

**Problem: Lines not updating every 5 seconds**
→ Check browser console for JavaScript errors
→ Verify `/api/line_movement_updates` endpoint works

---

## 📞 NEED HELP?

Check the full guide: `COMPREHENSIVE_FIX_SUMMARY.md`
