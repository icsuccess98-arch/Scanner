"""
🏀 PROFESSIONAL TOTALS BETTING SYSTEM
Built by a 20+ year veteran sports bettor
Focus: OVER/UNDER totals ONLY - No spreads, no moneylines

Key Philosophy:
1. Pace + Defensive Efficiency = Everything
2. Rest days matter more than people think
3. Historical trends are gold (30+ game samples)
4. Vig-adjusted expectations beat raw edges
5. Weather for outdoor sports is non-negotiable
"""

import os
import logging
import time
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
from math import radians, sin, cos, sqrt, atan2

from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_compress import Compress
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import func, and_, or_
import requests
import pytz
from bs4 import BeautifulSoup

# ============================================================================
# LOGGING SETUP
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

APP_VERSION = "3.0.0-TOTALS-ONLY-PRO"
logger.info(f"🏀 Professional Totals System Starting - v{APP_VERSION}")

# ============================================================================
# FLASK & DATABASE SETUP
# ============================================================================

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__, static_folder='static', static_url_path='/static')

# Configuration
flask_secret = os.environ.get("FLASK_SECRET_KEY", "your-secret-key-here")
app.secret_key = flask_secret

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Enable compression
compress = Compress()
compress.init_app(app)
logger.info("✅ Response compression enabled")

# ============================================================================
# PROFESSIONAL TOTALS THRESHOLDS
# ============================================================================

@dataclass(frozen=True)
class TotalsThresholds:
    """
    Professional totals betting thresholds from 20+ years experience.
    
    Philosophy:
    - NBA/CBB: Need significant edge (volatile scoring)
    - NFL/CFB: Tighter lines (need less edge)
    - NHL: Lowest scoring, tiny edges matter
    """
    
    # Minimum true edge needed (after vig removal)
    MIN_TRUE_EDGE: Dict[str, float] = None
    
    # Minimum historical hit rate
    MIN_HISTORY_PCT: float = 60.0
    
    # Minimum sample size for confidence
    MIN_SAMPLE_SIZE: int = 30  # CRITICAL: 30 games minimum!
    
    # Confidence tiers for totals
    CONFIDENCE_TIERS: Dict[str, Dict] = None
    
    # Pace impact factors (points per possession difference)
    PACE_IMPACT: Dict[str, float] = None
    
    # Rest day fatigue multipliers
    REST_IMPACT: Dict[str, Dict] = None
    
    def __post_init__(self):
        # Can't set mutable defaults in frozen dataclass, so set them here
        object.__setattr__(self, 'MIN_TRUE_EDGE', {
            'NBA': 3.5,   # NBA totals are sharp, need good edge
            'CBB': 3.0,   # CBB softer market
            'NFL': 2.0,   # NFL very efficient
            'CFB': 2.5,   # CFB has spots
            'NHL': 0.3,   # NHL low scoring, small edges
        })
        
        object.__setattr__(self, 'CONFIDENCE_TIERS', {
            'ELITE': {
                'edge_min': 8.0,
                'history_min': 70.0,
                'ev_min': 3.0,
                'color': '#00ff41'  # Bright green
            },
            'HIGH': {
                'edge_min': 6.0,
                'history_min': 65.0,
                'ev_min': 1.5,
                'color': '#4ade80'  # Green
            },
            'MEDIUM': {
                'edge_min': 4.0,
                'history_min': 60.0,
                'ev_min': 0.0,
                'color': '#fbbf24'  # Yellow
            },
            'LOW': {
                'edge_min': 3.0,
                'history_min': 55.0,
                'ev_min': -1.0,
                'color': '#f87171'  # Red
            }
        })
        
        object.__setattr__(self, 'PACE_IMPACT', {
            'NBA': 1.5,   # 1 PPP diff = 1.5 pts on total
            'CBB': 1.2,
            'NFL': 0.8,
            'CFB': 1.0,
            'NHL': 0.5,
        })
        
        object.__setattr__(self, 'REST_IMPACT', {
            'NBA': {
                'back_to_back': -4.0,      # Major fatigue
                'one_day': -2.0,           # Tired
                'two_days': 0.0,           # Normal
                'three_plus': +1.5,        # Well rested
            },
            'NFL': {
                'thursday': -3.0,          # Short week
                'sunday_to_sunday': 0.0,   # Normal
                'bye_week': +2.5,          # Fresh
            },
            'NHL': {
                'back_to_back': -2.5,      # Fatigue
                'one_day': -1.0,
                'two_plus': 0.0,
            }
        })

# Global config instance
CONFIG = TotalsThresholds()

# ============================================================================
# DATABASE MODELS - TOTALS ONLY
# ============================================================================

class Game(db.Model):
    """
    Game model - TOTALS ONLY, no spread/moneyline fields.
    """
    __tablename__ = 'game'
    
    # Primary info
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, index=True)
    game_time = db.Column(db.String(20))
    league = db.Column(db.String(10), nullable=False, index=True)
    away_team = db.Column(db.String(50), nullable=False)
    home_team = db.Column(db.String(50), nullable=False)
    
    # TOTALS DATA (core focus)
    line = db.Column(db.Float)  # Vegas total line
    projected_total = db.Column(db.Float)  # Our projection
    edge = db.Column(db.Float)  # Raw edge
    true_edge = db.Column(db.Float)  # Vig-adjusted edge
    direction = db.Column(db.String(10))  # OVER or UNDER
    
    # Historical validation (30+ game samples)
    away_ou_pct = db.Column(db.Float)  # Away team O/U hit rate (last 30)
    home_ou_pct = db.Column(db.Float)  # Home team O/U hit rate (last 30)
    h2h_over_pct = db.Column(db.Float)  # Head to head over rate
    
    # Advanced metrics
    away_pace = db.Column(db.Float)  # Possessions per game
    home_pace = db.Column(db.Float)
    combined_pace = db.Column(db.Float)  # Projected pace for this game
    away_def_efficiency = db.Column(db.Float)  # Points allowed per 100 poss
    home_def_efficiency = db.Column(db.Float)
    
    # Situational factors
    days_rest_away = db.Column(db.Integer)
    days_rest_home = db.Column(db.Integer)
    is_back_to_back_away = db.Column(db.Boolean, default=False)
    is_back_to_back_home = db.Column(db.Boolean, default=False)
    travel_distance = db.Column(db.Float)
    situational_adjustment = db.Column(db.Float, default=0.0)
    
    # Weather (NFL/CFB only)
    weather_wind_mph = db.Column(db.Float)
    weather_temp = db.Column(db.Float)
    weather_precipitation = db.Column(db.String(20))
    weather_impact = db.Column(db.Float, default=0.0)  # Points impact
    is_dome = db.Column(db.Boolean, default=False)
    
    # Odds & EV
    bovada_over_odds = db.Column(db.Integer)
    bovada_under_odds = db.Column(db.Integer)
    pinnacle_over_odds = db.Column(db.Integer)
    pinnacle_under_odds = db.Column(db.Integer)
    total_ev = db.Column(db.Float)  # EV vs Pinnacle
    vig_pct = db.Column(db.Float)  # Market vig percentage
    
    # Qualification
    is_qualified = db.Column(db.Boolean, default=False, index=True)
    confidence_tier = db.Column(db.String(10))  # ELITE, HIGH, MEDIUM, LOW
    disqualification_reason = db.Column(db.String(200))
    
    # Tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Game {self.away_team} @ {self.home_team} - {self.direction} {self.line}>"


class Pick(db.Model):
    """
    Saved picks - TOTALS ONLY
    """
    __tablename__ = 'pick'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, index=True)
    league = db.Column(db.String(10), nullable=False)
    away_team = db.Column(db.String(50), nullable=False)
    home_team = db.Column(db.String(50), nullable=False)
    
    # Pick details
    pick_type = db.Column(db.String(10), default='totals')  # Always 'totals'
    direction = db.Column(db.String(10))  # OVER or UNDER
    line = db.Column(db.Float)  # Total line
    odds = db.Column(db.Integer, default=-110)
    
    # Metrics at time of pick
    edge = db.Column(db.Float)
    true_edge = db.Column(db.Float)
    confidence_tier = db.Column(db.String(10))
    historical_hit_rate = db.Column(db.Float)
    ev = db.Column(db.Float)
    
    # Bet sizing
    kelly_pct = db.Column(db.Float)  # Kelly criterion %
    recommended_units = db.Column(db.Float)
    
    # Result tracking
    result = db.Column(db.String(1))  # W, L, P (win/loss/push)
    actual_total = db.Column(db.Float)
    closing_line = db.Column(db.Float)  # CLV tracking
    clv = db.Column(db.Float)  # Closing line value
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<Pick {self.away_team}@{self.home_team} {self.direction}{self.line}>"


# ============================================================================
# PROFESSIONAL EDGE CALCULATOR
# ============================================================================

class TotalsEdgeCalculator:
    """
    Professional totals edge calculation.
    
    20+ years wisdom:
    - Raw edge is what you see
    - True edge (vig-adjusted) is what matters
    - Pace + Defense = projected total
    - Historical validation is non-negotiable
    """
    
    @staticmethod
    def calculate_raw_edge(projected: float, line: float) -> float:
        """Calculate raw edge (before vig removal)."""
        return abs(projected - line)
    
    @staticmethod
    def calculate_true_edge(projected: float, line: float, 
                           over_odds: int, under_odds: int) -> Tuple[float, float]:
        """
        Calculate true edge after vig removal.
        
        Returns:
            (true_edge, fair_line)
        """
        # Remove vig to get fair line
        fair_line = VigCalculator.get_fair_line(line, over_odds, under_odds)
        true_edge = abs(projected - fair_line)
        
        return true_edge, fair_line
    
    @staticmethod
    def determine_direction(projected: float, line: float) -> Optional[str]:
        """Determine if OVER or UNDER."""
        if projected > line:
            return 'OVER'
        elif projected < line:
            return 'UNDER'
        return None
    
    @staticmethod
    def qualifies(true_edge: float, league: str, history_pct: float, 
                 sample_size: int) -> Tuple[bool, str]:
        """
        Check if pick qualifies.
        
        Returns:
            (qualified, reason)
        """
        min_edge = CONFIG.MIN_TRUE_EDGE.get(league, 3.0)
        
        # Check true edge
        if true_edge < min_edge:
            return False, f"True edge {true_edge:.1f} < {min_edge} minimum"
        
        # Check historical sample size
        if sample_size < CONFIG.MIN_SAMPLE_SIZE:
            return False, f"Sample size {sample_size} < {CONFIG.MIN_SAMPLE_SIZE} minimum"
        
        # Check historical hit rate
        if history_pct < CONFIG.MIN_HISTORY_PCT:
            return False, f"History {history_pct:.0f}% < {CONFIG.MIN_HISTORY_PCT}% minimum"
        
        return True, "Qualified"
    
    @staticmethod
    def calculate_confidence_tier(edge: float, history_pct: float, ev: float) -> str:
        """
        Determine confidence tier.
        
        Returns:
            'ELITE', 'HIGH', 'MEDIUM', 'LOW', or 'NONE'
        """
        for tier in ['ELITE', 'HIGH', 'MEDIUM', 'LOW']:
            reqs = CONFIG.CONFIDENCE_TIERS[tier]
            if (edge >= reqs['edge_min'] and 
                history_pct >= reqs['history_min'] and 
                ev >= reqs['ev_min']):
                return tier
        return 'NONE'


# ============================================================================
# VIG CALCULATOR
# ============================================================================

class VigCalculator:
    """
    Calculate vig and fair lines.
    
    Professional insight:
    Vig removal is critical - raw lines are ALWAYS inflated.
    """
    
    @staticmethod
    def american_to_decimal(odds: int) -> float:
        """Convert American odds to decimal."""
        if odds > 0:
            return (odds / 100) + 1
        else:
            return (100 / abs(odds)) + 1
    
    @staticmethod
    def calculate_vig_pct(over_odds: int, under_odds: int) -> float:
        """Calculate market vig percentage."""
        over_decimal = VigCalculator.american_to_decimal(over_odds)
        under_decimal = VigCalculator.american_to_decimal(under_odds)
        
        implied_over = 1 / over_decimal
        implied_under = 1 / under_decimal
        
        total_prob = implied_over + implied_under
        vig_pct = ((total_prob - 1.0) / total_prob) * 100
        
        return round(vig_pct, 2)
    
    @staticmethod
    def get_fair_line(line: float, over_odds: int, under_odds: int) -> float:
        """
        Calculate fair line after vig removal.
        
        Professional method:
        Move the line based on true probabilities.
        """
        over_decimal = VigCalculator.american_to_decimal(over_odds)
        under_decimal = VigCalculator.american_to_decimal(under_odds)
        
        implied_over = 1 / over_decimal
        implied_under = 1 / under_decimal
        
        # Remove vig proportionally
        total_prob = implied_over + implied_under
        fair_over_prob = implied_over / total_prob
        fair_under_prob = implied_under / total_prob
        
        # Adjust line based on true probability
        if fair_over_prob > 0.52:  # Over is favored
            adjustment = (fair_over_prob - 0.5) * 4  # Scaling factor
            fair_line = line + adjustment
        elif fair_under_prob > 0.52:  # Under is favored
            adjustment = (fair_under_prob - 0.5) * 4
            fair_line = line - adjustment
        else:
            fair_line = line
        
        return round(fair_line, 1)


# ============================================================================
# EV CALCULATOR
# ============================================================================

class EVCalculator:
    """
    Calculate Expected Value vs Pinnacle (sharpest book).
    
    Pinnacle is the gold standard - if you have +EV vs Pinnacle, you're sharp.
    """
    
    @staticmethod
    def calculate_ev(our_odds: int, pinnacle_odds: int) -> float:
        """
        Calculate EV percentage.
        
        Args:
            our_odds: The odds we're betting at (e.g., Bovada -110)
            pinnacle_odds: Pinnacle's odds (sharpest line)
            
        Returns:
            EV percentage (positive = good)
        """
        if not pinnacle_odds or pinnacle_odds == 0:
            return 0.0
        
        our_decimal = VigCalculator.american_to_decimal(our_odds)
        pinnacle_decimal = VigCalculator.american_to_decimal(pinnacle_odds)
        
        # True win probability from Pinnacle (remove their vig)
        pinnacle_prob = 1 / pinnacle_decimal
        
        # Our payout if we win
        our_payout = our_decimal
        
        # EV = (Win Probability × Payout) - 1
        ev = (pinnacle_prob * our_payout) - 1
        
        return round(ev * 100, 2)  # Convert to percentage


# ============================================================================
# KELLY CRITERION CALCULATOR
# ============================================================================

class KellyCalculator:
    """
    Kelly Criterion for optimal bet sizing.
    
    Formula: (bp - q) / b
    where:
        b = decimal odds - 1
        p = win probability
        q = lose probability (1 - p)
    """
    
    @staticmethod
    def calculate_kelly(win_prob: float, odds: int, fraction: float = 0.25) -> float:
        """
        Calculate Kelly percentage.
        
        Args:
            win_prob: Probability of winning (0-1)
            odds: American odds
            fraction: Kelly fraction (0.25 = quarter Kelly, conservative)
            
        Returns:
            Percentage of bankroll to bet
        """
        if win_prob <= 0 or win_prob >= 1:
            return 0.0
        
        decimal_odds = VigCalculator.american_to_decimal(odds)
        b = decimal_odds - 1
        q = 1 - win_prob
        
        kelly = ((b * win_prob) - q) / b
        
        # Apply fractional Kelly (more conservative)
        kelly = kelly * fraction
        
        # Cap at 5% (safety limit)
        kelly = min(kelly, 0.05)
        kelly = max(kelly, 0.0)  # Never negative
        
        return round(kelly * 100, 2)  # Return as percentage


# ============================================================================
# PACE & TEMPO CALCULATOR
# ============================================================================

class PaceCalculator:
    """
    Pace/tempo analysis for totals betting.
    
    CRITICAL INSIGHT:
    Pace drives totals more than most realize.
    Fast pace + weak defense = OVER
    Slow pace + strong defense = UNDER
    """
    
    @staticmethod
    def calculate_projected_pace(away_pace: float, home_pace: float, 
                                 league: str) -> float:
        """
        Calculate expected pace for this matchup.
        
        Method: Weighted average favoring home team slightly (60/40)
        """
        if not away_pace or not home_pace:
            return 0.0
        
        # Home team controls pace slightly more
        projected = (away_pace * 0.4) + (home_pace * 0.6)
        
        return round(projected, 1)
    
    @staticmethod
    def pace_impact_on_total(projected_pace: float, league_avg_pace: float, 
                            league: str) -> float:
        """
        Calculate how pace difference affects projected total.
        
        Args:
            projected_pace: Expected possessions for this game
            league_avg_pace: League average pace
            league: NBA, CBB, etc.
            
        Returns:
            Points to add/subtract from baseline total
        """
        pace_diff = projected_pace - league_avg_pace
        impact_per_possession = CONFIG.PACE_IMPACT.get(league, 1.0)
        
        return round(pace_diff * impact_per_possession, 1)


# ============================================================================
# HISTORICAL ANALYZER - 30 GAME SAMPLES
# ============================================================================

class HistoricalAnalyzer:
    """
    Analyze historical O/U performance.
    
    PROFESSIONAL STANDARD:
    - 30 game minimum sample (not 10!)
    - Recent games weighted more
    - Head-to-head history critical
    """
    
    @staticmethod
    def get_team_ou_history(team: str, league: str, n_games: int = 30) -> Dict:
        """
        Get team's O/U hit rate for last N games.
        
        Returns:
            {
                'over_pct': float,
                'sample_size': int,
                'recent_form': str ('hot', 'cold', 'neutral')
            }
        """
        try:
            today = date.today()
            
            # Query historical games
            games = Game.query.filter(
                or_(Game.away_team == team, Game.home_team == team),
                Game.league == league,
                Game.date < today,
                Game.line.isnot(None)
            ).order_by(Game.date.desc()).limit(n_games).all()
            
            if len(games) < CONFIG.MIN_SAMPLE_SIZE:
                return {
                    'over_pct': 0.0,
                    'sample_size': len(games),
                    'recent_form': 'insufficient'
                }
            
            # Calculate O/U hit rate
            # NOTE: This would need actual results populated
            # For now, using the stored ou_pct if available
            over_count = sum(1 for g in games if getattr(g, 'went_over', False))
            over_pct = (over_count / len(games)) * 100 if games else 0.0
            
            # Determine recent form (last 10 games)
            recent_games = games[:10]
            recent_over = sum(1 for g in recent_games if getattr(g, 'went_over', False))
            recent_pct = (recent_over / len(recent_games)) * 100 if recent_games else 0.0
            
            if recent_pct >= 70:
                form = 'hot_over'
            elif recent_pct <= 30:
                form = 'hot_under'
            else:
                form = 'neutral'
            
            return {
                'over_pct': round(over_pct, 1),
                'sample_size': len(games),
                'recent_form': form
            }
            
        except Exception as e:
            logger.error(f"Error getting O/U history for {team}: {e}")
            return {'over_pct': 0.0, 'sample_size': 0, 'recent_form': 'error'}
    
    @staticmethod
    def get_h2h_over_trend(team1: str, team2: str, league: str) -> Dict:
        """
        Get head-to-head O/U trend between two teams.
        
        Returns:
            {
                'over_pct': float,
                'sample_size': int,
                'avg_total': float
            }
        """
        try:
            today = date.today()
            
            # Query H2H games
            h2h_games = Game.query.filter(
                and_(
                    or_(
                        and_(Game.away_team == team1, Game.home_team == team2),
                        and_(Game.away_team == team2, Game.home_team == team1)
                    ),
                    Game.league == league,
                    Game.date < today,
                    Game.line.isnot(None)
                )
            ).order_by(Game.date.desc()).limit(10).all()
            
            if not h2h_games:
                return {'over_pct': 0.0, 'sample_size': 0, 'avg_total': 0.0}
            
            # Calculate O/U trend
            over_count = sum(1 for g in h2h_games if getattr(g, 'went_over', False))
            over_pct = (over_count / len(h2h_games)) * 100
            
            # Average total in H2H games
            avg_total = sum(getattr(g, 'actual_total', g.line) for g in h2h_games) / len(h2h_games)
            
            return {
                'over_pct': round(over_pct, 1),
                'sample_size': len(h2h_games),
                'avg_total': round(avg_total, 1)
            }
            
        except Exception as e:
            logger.error(f"Error getting H2H trend: {e}")
            return {'over_pct': 0.0, 'sample_size': 0, 'avg_total': 0.0}


# ============================================================================
# SITUATIONAL FACTORS
# ============================================================================

class SituationalAnalyzer:
    """
    Analyze situational factors affecting totals.
    
    KEY FACTORS:
    1. Rest days (huge for NBA/NHL)
    2. Travel distance
    3. Weather (NFL/CFB)
    4. Back-to-backs
    """
    
    @staticmethod
    def get_rest_impact(team: str, league: str, game_date: date) -> Dict:
        """
        Calculate rest days impact on total.
        
        Returns:
            {
                'days_rest': int,
                'is_back_to_back': bool,
                'fatigue_impact': float (points adjustment)
            }
        """
        try:
            recent_games = Game.query.filter(
                or_(Game.away_team == team, Game.home_team == team),
                Game.league == league,
                Game.date < game_date
            ).order_by(Game.date.desc()).limit(1).all()
            
            if not recent_games:
                return {
                    'days_rest': None,
                    'is_back_to_back': False,
                    'fatigue_impact': 0.0
                }
            
            last_game = recent_games[0]
            days_rest = (game_date - last_game.date).days
            is_b2b = (days_rest == 1)
            
            # Get impact from config
            rest_impacts = CONFIG.REST_IMPACT.get(league, {})
            
            if league == 'NBA':
                if is_b2b:
                    impact = rest_impacts.get('back_to_back', -4.0)
                elif days_rest == 2:
                    impact = rest_impacts.get('one_day', -2.0)
                elif days_rest == 3:
                    impact = rest_impacts.get('two_days', 0.0)
                else:
                    impact = rest_impacts.get('three_plus', +1.5)
            
            elif league == 'NFL':
                if days_rest <= 4:  # Thursday game
                    impact = rest_impacts.get('thursday', -3.0)
                elif days_rest >= 10:  # Bye week
                    impact = rest_impacts.get('bye_week', +2.5)
                else:
                    impact = 0.0
            
            elif league == 'NHL':
                if is_b2b:
                    impact = rest_impacts.get('back_to_back', -2.5)
                elif days_rest == 2:
                    impact = rest_impacts.get('one_day', -1.0)
                else:
                    impact = 0.0
            
            else:
                impact = 0.0
            
            return {
                'days_rest': days_rest,
                'is_back_to_back': is_b2b,
                'fatigue_impact': impact
            }
            
        except Exception as e:
            logger.error(f"Error calculating rest impact: {e}")
            return {'days_rest': None, 'is_back_to_back': False, 'fatigue_impact': 0.0}
    
    @staticmethod
    def calculate_travel_distance(team1: str, team2: str) -> float:
        """Calculate travel distance between cities."""
        # City coordinates (major sports cities)
        CITIES = {
            'Atlanta': (33.7490, -84.3880), 'Boston': (42.3601, -71.0589),
            'Brooklyn': (40.6782, -73.9442), 'Charlotte': (35.2271, -80.8431),
            'Chicago': (41.8781, -87.6298), 'Cleveland': (41.4993, -81.6944),
            'Dallas': (32.7767, -96.7970), 'Denver': (39.7392, -104.9903),
            'Detroit': (42.3314, -83.0458), 'Golden State': (37.7749, -122.4194),
            'Houston': (29.7604, -95.3698), 'Los Angeles': (34.0522, -118.2437),
            'Memphis': (35.1495, -90.0490), 'Miami': (25.7617, -80.1918),
            'Milwaukee': (43.0389, -87.9065), 'Minnesota': (44.9778, -93.2650),
            'New Orleans': (29.9511, -90.0715), 'New York': (40.7128, -74.0060),
            'Oklahoma City': (35.4676, -97.5164), 'Orlando': (28.5383, -81.3792),
            'Philadelphia': (39.9526, -75.1652), 'Phoenix': (33.4484, -112.0740),
            'Portland': (45.5152, -122.6784), 'Sacramento': (38.5816, -121.4944),
            'San Antonio': (29.4241, -98.4936), 'Toronto': (43.6532, -79.3832),
            'Utah': (40.7608, -111.8910), 'Washington': (38.9072, -77.0369),
        }
        
        def get_city(team_name):
            for city in CITIES.keys():
                if city.lower() in team_name.lower():
                    return city
            return None
        
        city1 = get_city(team1)
        city2 = get_city(team2)
        
        if not city1 or not city2:
            return 0.0
        
        lat1, lon1 = CITIES[city1]
        lat2, lon2 = CITIES[city2]
        
        # Haversine formula
        R = 3959  # Earth radius in miles
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return round(R * c, 0)
    
    @staticmethod
    def get_travel_impact(distance: float, league: str) -> float:
        """
        Calculate travel fatigue impact on total.
        
        Professional insight:
        Long travel = tired away team = UNDER tendency
        """
        if league == 'NBA':
            if distance >= 2500:
                return -2.0  # Cross-country exhaustion
            elif distance >= 1500:
                return -1.0
        elif league == 'NFL':
            if distance >= 2000:
                return -1.5
        elif league == 'NHL':
            if distance >= 2000:
                return -1.0
        
        return 0.0


# ============================================================================
# WEATHER ANALYZER (NFL/CFB ONLY)
# ============================================================================

class WeatherAnalyzer:
    """
    Weather impact on totals.
    
    CRITICAL FOR NFL/CFB:
    - Wind >15mph = significant UNDER tendency
    - Cold <20F = UNDER
    - Rain/snow = UNDER
    - Dome games = ignore weather
    """
    
    # NFL dome stadiums
    DOME_STADIUMS = {
        'Atlanta', 'Dallas', 'Detroit', 'Houston', 'Indianapolis',
        'Las Vegas', 'Los Angeles', 'Minnesota', 'New Orleans', 'Arizona'
    }
    
    @staticmethod
    def is_dome_game(home_team: str) -> bool:
        """Check if game is in a dome."""
        for city in WeatherAnalyzer.DOME_STADIUMS:
            if city.lower() in home_team.lower():
                return True
        return False
    
    @staticmethod
    def fetch_weather(city: str, date: date) -> Dict:
        """
        Fetch weather data for game location.
        
        NOTE: You'd integrate with weather API here
        For now, returning placeholder
        """
        # TODO: Integrate weather API
        return {
            'temperature': None,
            'wind_mph': None,
            'precipitation': None
        }
    
    @staticmethod
    def calculate_weather_impact(temp: Optional[float], wind: Optional[float],
                                 precip: Optional[str], is_dome: bool) -> float:
        """
        Calculate weather impact on total.
        
        Returns:
            Points adjustment (negative = UNDER, positive = OVER)
        """
        if is_dome:
            return 0.0
        
        impact = 0.0
        
        # Temperature impact
        if temp is not None:
            if temp < 20:  # Very cold
                impact -= 3.0
            elif temp < 32:  # Cold
                impact -= 1.5
            elif temp > 85:  # Hot (can slow pace)
                impact -= 0.5
        
        # Wind impact (CRITICAL)
        if wind is not None:
            if wind >= 20:  # Very windy
                impact -= 4.0
            elif wind >= 15:  # Windy
                impact -= 2.0
            elif wind >= 10:
                impact -= 1.0
        
        # Precipitation impact
        if precip:
            precip_lower = precip.lower()
            if 'snow' in precip_lower:
                impact -= 3.0
            elif 'rain' in precip_lower or 'storm' in precip_lower:
                impact -= 2.0
        
        return round(impact, 1)


# ============================================================================
# FLASK ROUTES - TOTALS ONLY
# ============================================================================

@app.route('/')
def dashboard():
    """
    Main dashboard - show today's qualified totals picks.
    
    Professional display:
    - Sorted by confidence tier
    - Clear metrics (edge, history, EV)
    - One-click save to picks
    """
    try:
        et = pytz.timezone('America/New_York')
        today = datetime.now(et).date()
        
        # Get qualified games
        qualified = Game.query.filter(
            Game.date == today,
            Game.is_qualified == True
        ).order_by(
            Game.true_edge.desc()
        ).all()
        
        # Get today's saved picks
        saved_picks = Pick.query.filter_by(date=today).all()
        saved_game_ids = {f"{p.away_team}_{p.home_team}" for p in saved_picks}
        
        # Calculate stats
        stats = {
            'total_games': Game.query.filter_by(date=today).count(),
            'qualified': len(qualified),
            'elite': len([g for g in qualified if g.confidence_tier == 'ELITE']),
            'high': len([g for g in qualified if g.confidence_tier == 'HIGH']),
            'saved': len(saved_picks)
        }
        
        return render_template('dashboard.html',
                              games=qualified,
                              saved_game_ids=saved_game_ids,
                              stats=stats,
                              today=today)
    
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return f"Error loading dashboard: {e}", 500


@app.route('/api/stats')
def api_stats():
    """API endpoint for statistics."""
    try:
        picks = Pick.query.all()
        
        wins = len([p for p in picks if p.result == 'W'])
        losses = len([p for p in picks if p.result == 'L'])
        total = wins + losses
        
        stats = {
            'total_picks': total,
            'wins': wins,
            'losses': losses,
            'win_rate': round((wins / total * 100) if total > 0 else 0, 1)
        }
        
        return jsonify(stats)
    
    except Exception as e:
        logger.error(f"Stats API error: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# DATABASE INITIALIZATION
# ============================================================================

with app.app_context():
    db.create_all()
    logger.info("✅ Database initialized")


# ============================================================================
# RUN APP
# ============================================================================

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

# ============================================================================
# FLASK ROUTES - TOTALS ONLY
# ============================================================================

@app.route('/')
def dashboard():
    """
    Main dashboard - show today's qualified totals picks.
    
    Professional display:
    - Sorted by confidence tier
    - Clear metrics (edge, history, EV)
    - One-click save to picks
    """
    try:
        et = pytz.timezone('America/New_York')
        today = datetime.now(et).date()
        
        # Get qualified games
        qualified = Game.query.filter(
            Game.date == today,
            Game.is_qualified == True
        ).order_by(
            Game.true_edge.desc()
        ).all()
        
        # Get today's saved picks
        saved_picks = Pick.query.filter_by(date=today).all()
        saved_game_ids = {f"{p.away_team}_{p.home_team}" for p in saved_picks}
        
        # Calculate stats
        stats = {
            'total_games': Game.query.filter_by(date=today).count(),
            'qualified': len(qualified),
            'elite': len([g for g in qualified if g.confidence_tier == 'ELITE']),
            'high': len([g for g in qualified if g.confidence_tier == 'HIGH']),
            'saved': len(saved_picks)
        }
        
        return render_template('dashboard.html',
                              games=qualified,
                              saved_game_ids=saved_game_ids,
                              stats=stats,
                              today=today)
    
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return f"Error loading dashboard: {e}", 500


@app.route('/fetch_odds', methods=['POST'])
def fetch_odds():
    """
    Fetch today's games and odds, calculate projections.
    
    Professional process:
    1. Fetch games from Odds API
    2. Get historical O/U rates (30 games)
    3. Calculate pace projections
    4. Apply situational factors
    5. Calculate edges and qualify picks
    """
    try:
        et = pytz.timezone('America/New_York')
        today = datetime.now(et).date()
        
        logger.info("🔄 Fetching odds and calculating totals projections...")
        
        # Get Odds API key
        odds_api_key = os.environ.get('ODDS_API_KEY')
        if not odds_api_key:
            return jsonify({'success': False, 'error': 'ODDS_API_KEY not set'}), 400
        
        # Fetch from Odds API (professional implementation would go here)
        # For now, placeholder response
        
        qualified_count = 0
        games_processed = 0
        
        # Example processing logic (you'd implement actual API calls)
        # games = fetch_from_odds_api(today)
        # for game_data in games:
        #     process_and_qualify_game(game_data)
        #     qualified_count += 1
        
        logger.info(f"✅ Processed {games_processed} games, {qualified_count} qualified")
        
        return jsonify({
            'success': True,
            'games_processed': games_processed,
            'qualified': qualified_count
        })
    
    except Exception as e:
        logger.error(f"Fetch odds error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/save_pick/<int:game_id>', methods=['POST'])
def save_pick(game_id):
    """Save a pick to history."""
    try:
        game = Game.query.get_or_404(game_id)
        
        # Check if already saved
        existing = Pick.query.filter_by(
            date=game.date,
            away_team=game.away_team,
            home_team=game.home_team
        ).first()
        
        if existing:
            return jsonify({'success': False, 'error': 'Pick already saved'})
        
        # Calculate Kelly sizing
        win_prob = game.away_ou_pct / 100 if game.direction == 'OVER' else game.home_ou_pct / 100
        kelly_pct = KellyCalculator.calculate_kelly(win_prob, game.bovada_over_odds or -110)
        
        # Create pick
        pick = Pick(
            date=game.date,
            league=game.league,
            away_team=game.away_team,
            home_team=game.home_team,
            pick_type='totals',
            direction=game.direction,
            line=game.line,
            odds=game.bovada_over_odds if game.direction == 'OVER' else game.bovada_under_odds,
            edge=game.edge,
            true_edge=game.true_edge,
            confidence_tier=game.confidence_tier,
            historical_hit_rate=max(game.away_ou_pct or 0, game.home_ou_pct or 0),
            ev=game.total_ev,
            kelly_pct=kelly_pct,
            recommended_units=round(kelly_pct / 20, 1)  # 1 unit = 20% of Kelly
        )
        
        db.session.add(pick)
        db.session.commit()
        
        logger.info(f"✅ Saved pick: {game.away_team} @ {game.home_team} {game.direction} {game.line}")
        
        return jsonify({'success': True})
    
    except Exception as e:
        logger.error(f"Save pick error: {e}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/history')
def history():
    """View pick history and performance."""
    try:
        # Get all picks sorted by date descending
        picks = Pick.query.order_by(Pick.date.desc(), Pick.created_at.desc()).all()
        
        # Calculate stats
        total_picks = len(picks)
        wins = len([p for p in picks if p.result == 'W'])
        losses = len([p for p in picks if p.result == 'L'])
        pushes = len([p for p in picks if p.result == 'P'])
        pending = len([p for p in picks if p.result is None])
        
        win_rate = (wins / (wins + losses) * 100) if (wins + losses) > 0 else 0
        
        # Calculate by tier
        tier_stats = {}
        for tier in ['ELITE', 'HIGH', 'MEDIUM', 'LOW']:
            tier_picks = [p for p in picks if p.confidence_tier == tier]
            tier_wins = len([p for p in tier_picks if p.result == 'W'])
            tier_losses = len([p for p in tier_picks if p.result == 'L'])
            tier_total = tier_wins + tier_losses
            tier_stats[tier] = {
                'record': f"{tier_wins}-{tier_losses}",
                'win_rate': round((tier_wins / tier_total * 100) if tier_total > 0 else 0, 1)
            }
        
        stats = {
            'total': total_picks,
            'wins': wins,
            'losses': losses,
            'pushes': pushes,
            'pending': pending,
            'win_rate': round(win_rate, 1),
            'tier_stats': tier_stats
        }
        
        return render_template('history.html', picks=picks, stats=stats)
    
    except Exception as e:
        logger.error(f"History error: {e}")
        return f"Error loading history: {e}", 500


@app.route('/api/update_result/<int:pick_id>', methods=['POST'])
def update_result(pick_id):
    """Update pick result (W/L/P)."""
    try:
        data = request.get_json()
        result = data.get('result')
        actual_total = data.get('actual_total')
        
        if result not in ['W', 'L', 'P']:
            return jsonify({'success': False, 'error': 'Invalid result'}), 400
        
        pick = Pick.query.get_or_404(pick_id)
        pick.result = result
        pick.actual_total = actual_total
        
        db.session.commit()
        
        logger.info(f"✅ Updated pick {pick_id} result: {result}")
        
        return jsonify({'success': True})
    
    except Exception as e:
        logger.error(f"Update result error: {e}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/stats')
def api_stats():
    """API endpoint for statistics."""
    try:
        picks = Pick.query.all()
        
        wins = len([p for p in picks if p.result == 'W'])
        losses = len([p for p in picks if p.result == 'L'])
        total = wins + losses
        
        stats = {
            'total_picks': total,
            'wins': wins,
            'losses': losses,
            'win_rate': round((wins / total * 100) if total > 0 else 0, 1),
            'by_league': {},
            'by_tier': {}
        }
        
        # By league
        for league in ['NBA', 'CBB', 'NFL', 'CFB', 'NHL']:
            league_picks = [p for p in picks if p.league == league and p.result in ['W', 'L']]
            league_wins = len([p for p in league_picks if p.result == 'W'])
            league_total = len(league_picks)
            stats['by_league'][league] = {
                'record': f"{league_wins}-{league_total - league_wins}",
                'win_rate': round((league_wins / league_total * 100) if league_total > 0 else 0, 1)
            }
        
        # By tier
        for tier in ['ELITE', 'HIGH', 'MEDIUM', 'LOW']:
            tier_picks = [p for p in picks if p.confidence_tier == tier and p.result in ['W', 'L']]
            tier_wins = len([p for p in tier_picks if p.result == 'W'])
            tier_total = len(tier_picks)
            stats['by_tier'][tier] = {
                'record': f"{tier_wins}-{tier_total - tier_wins}",
                'win_rate': round((tier_wins / tier_total * 100) if tier_total > 0 else 0, 1)
            }
        
        return jsonify(stats)
    
    except Exception as e:
        logger.error(f"Stats API error: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# DATABASE INITIALIZATION
# ============================================================================

with app.app_context():
    db.create_all()
    logger.info("✅ Database initialized")


# ============================================================================
# RUN APP
# ============================================================================

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
