# NBA MATCHUP TABLE - INTEGRATION GUIDE

## 🎯 What You Got

Two complete systems for generating NBA matchup analysis tables:

### 1. `matchup_table_generator.py` - READY TO USE NOW
- ✅ Complete table formatting matching your screenshots
- ✅ Power Rating section (overall, offensive, defensive)
- ✅ Season stats comparison
- ✅ Last 5 games comparison  
- ✅ Edge summary (NO "Savant Analytics" branding)
- ✅ Works with sample data immediately

### 2. `nba_matchup_analyzer.py` - DATA SCRAPING FRAMEWORK
- Framework for pulling from TeamRankings, NBA.com, Covers, CleaningTheGlass
- Requires API implementation (see below)

---

## 🚀 Quick Start (5 Minutes)

### Test with Sample Data:

```bash
python3 matchup_table_generator.py
```

You'll get output like this:

```
====================================================================================================
                                        NBA MATCHUP ANALYSIS                                        
====================================================================================================

┌─ POWER RATING ─────────────────────────────────────────────────────────────┐
│ Overall Team Strength                                                       │
│                                                                             │
│             #44 Bulls ✓             vs             #77 Pacers              │
│               Top 12%                                Top 21%               │
│                                      +33                                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─ OFFENSIVE EFFICIENCY ─────────────────────────────────────────────────────┐
│ Scoring Ability (pts/100)                                                   │
│                                                                             │
│             #47 Bulls ✓             vs             #73 Pacers              │
│               Top 13%                                Top 20%               │
│                                      +26                                      │
└─────────────────────────────────────────────────────────────────────────────┘

[...complete table continues...]
```

---

## 📊 What's Included vs Your Screenshot

### ✅ Included (Matching Your Requirements):

1. **Power Rating Section**
   - Overall team strength rank
   - Top percentile display
   - Edge calculation
   - Checkmark for leader

2. **Offensive Efficiency Section**
   - Scoring ability rank (pts/100)
   - Percentile
   - Edge

3. **Defensive Efficiency Section**
   - Points allowed rank (pts/100)
   - Percentile
   - Edge

4. **Season Stats Comparison**
   - ORB%, DRB%, TOV%, Forced TOV%
   - OFF/DEF Efficiency
   - eFG%, Opp eFG%
   - 3PM/Game, FT Rate
   - SOS, Edge Count
   - Clear edge designation per metric

5. **Last 5 Games Comparison**
   - Same metrics as season
   - Side-by-side format

6. **Edge Summary**
   - Edge count per team
   - Clear winner determination
   - **NO "Savant Analytics" branding** ✅

### ❌ NOT Included (From Screenshots 2-4):

These were deeper breakdown items you said to leave out:

- 2PT%, 3PT%, 3PT Rate details
- Turnover rate with "protects/doesn't press"
- Offensive rebound % with "crashes glass" labels
- Free throw rate with "attacks" labels
- Tempo/Pace details
- Detailed shooting profile section

**Why?** You said: "if anything is repeated leave it out" - these overlap with main table metrics.

---

## 🔧 How to Use With YOUR Data

### Option 1: Manual Data Entry

```python
from matchup_table_generator import CompleteMatchupTable

# Your data
bulls_stats = {
    'ORB%': 26.3,
    'DRB%': 78.8,
    'TOV%': 12.5,
    'Forced TOV%': 7.8,
    'OFF_Efficiency': 113.6,
    'DEF_Efficiency': 113.2,
    'eFG%': 56.6,
    'Opp_eFG%': 52.0,
    '3PM_Game': 14.2,
    'FT_Rate': 22.5,
    'SOS': 18.0,
    'Edge_Count': 5.0
}

# Same structure for Pacers, L5 games, and power ratings...

# Generate table
generator = CompleteMatchupTable('Bulls', 'Pacers')
table = generator.generate_complete_table(
    team1_stats=bulls_stats,
    team2_stats=pacers_stats,
    team1_l5_stats=bulls_l5,
    team2_l5_stats=pacers_l5,
    team1_power=bulls_power,
    team2_power=pacers_power
)

print(table)
```

### Option 2: Pull From Your Data Sources

You need to implement data fetching from:

1. **TeamRankings.com** - Power ratings
2. **NBA.com** - Official stats (they have a free API!)
3. **Covers.com** - Betting data
4. **CleaningTheGlass.com** - Advanced analytics (requires subscription)

---

## 🌐 Data Source Implementation Guide

### NBA.com Official Stats API (FREE!)

The best source for accurate current season data:

```python
import requests

def get_nba_team_stats(team_abbr):
    """
    Get stats from NBA.com official API.
    """
    url = "https://stats.nba.com/stats/teamdashboardbygeneralsplits"
    
    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'https://www.nba.com/'
    }
    
    params = {
        'Season': '2024-25',
        'SeasonType': 'Regular Season',
        'TeamID': get_team_id(team_abbr),
        'MeasureType': 'Advanced',
        'PerMode': 'PerGame'
    }
    
    response = requests.get(url, headers=headers, params=params)
    data = response.json()
    
    # Parse response
    return parse_nba_stats(data)
```

**NBA.com Team IDs:**
```python
team_ids = {
    'CHI': 1610612741,
    'IND': 1610612754,
    'BOS': 1610612738,
    # ... etc
}
```

### TeamRankings.com (Web Scraping)

For power ratings:

```python
from bs4 import BeautifulSoup
import requests

def get_power_rating(team_name):
    """
    Scrape power rating from TeamRankings.
    """
    url = f"https://www.teamrankings.com/nba/team/{team_name.lower()}"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find power rating elements
    # (You'll need to inspect the actual HTML structure)
    rank = soup.find('div', class_='rank').text
    rating = soup.find('div', class_='rating').text
    
    return {
        'rank': int(rank),
        'rating': float(rating),
        'percentile': calculate_percentile(rank)
    }
```

### Covers.com (Web Scraping)

For betting data and SOS:

```python
def get_covers_data(team_abbr):
    """
    Get SOS and other data from Covers.
    """
    url = f"https://www.covers.com/sport/basketball/nba/teams/main/{team_abbr.lower()}"
    # Scrape and parse...
    pass
```

### CleaningTheGlass.com (Requires Subscription)

For advanced analytics:

```python
def get_cleaning_glass_stats(team_abbr):
    """
    Get garbage-time adjusted stats.
    Requires CleaningTheGlass subscription.
    """
    # Use their API if available
    # Or scrape with authentication
    pass
```

---

## 📈 Complete Integration Example

Here's how to wire everything together:

```python
from matchup_table_generator import CompleteMatchupTable
from nba_matchup_analyzer import NBAOfficialScraper

# Initialize scrapers
nba_scraper = NBAOfficialScraper()

# Get data for both teams
bulls_stats = nba_scraper.get_team_stats('CHI')
pacers_stats = nba_scraper.get_team_stats('IND')

bulls_l5 = nba_scraper.get_last_n_games_stats('CHI', 5)
pacers_l5 = nba_scraper.get_last_n_games_stats('IND', 5)

# Get power ratings (you implement this)
bulls_power = get_power_rating_from_teamrankings('bulls')
pacers_power = get_power_rating_from_teamrankings('pacers')

# Generate table
generator = CompleteMatchupTable('Bulls', 'Pacers')
table = generator.generate_complete_table(
    bulls_stats, pacers_stats,
    bulls_l5, pacers_l5,
    bulls_power, pacers_power
)

# Output
print(table)

# Or save to file
with open('bulls_vs_pacers_analysis.txt', 'w') as f:
    f.write(table)
```

---

## 🎨 Customizing the Table

### Change Metrics Displayed

In `matchup_table_generator.py`, edit `METRICS_CONFIG`:

```python
METRICS_CONFIG = {
    'ORB%': {'display': 'ORB%', 'direction': 'higher', 'format': '{:.1f}%'},
    'DRB%': {'display': 'DRB%', 'direction': 'higher', 'format': '{:.1f}%'},
    # Add more or remove...
}
```

### Change Table Width

Adjust the width constant:

```python
TABLE_WIDTH = 100  # Change this number
```

### Add New Sections

Add a new formatting method:

```python
def _format_my_new_section(self, data1, data2) -> str:
    """Add your custom section here."""
    output = []
    output.append("┌─ MY NEW SECTION ───────────────┐")
    # ... format your content
    output.append("└────────────────────────────────┘")
    return "\n".join(output)
```

Then call it in `generate_complete_table()`.

---

## 🔗 Integration With Your Betting Engine

Combine with the main betting engine:

```python
from nba_betting_engine import ComprehensiveGameAnalyzer
from matchup_table_generator import CompleteMatchupTable

# Get betting analysis
analyzer = ComprehensiveGameAnalyzer()
betting_analysis = analyzer.analyze_game(game_data)

# Get matchup table
table_gen = CompleteMatchupTable(away_team, home_team)
matchup_table = table_gen.generate_complete_table(...)

# Combine outputs
full_report = f"""
{matchup_table}

{'='*100}
BETTING RECOMMENDATION
{'='*100}
Decision: {betting_analysis['bet_recommendation']['decision']}
Confidence: {betting_analysis['bet_recommendation']['confidence']}

Reasons:
{chr(10).join(f"  - {r}" for r in betting_analysis['bet_recommendation']['reasons'])}

Market Analysis:
  Sharp Side: {betting_analysis['market_analysis']['sharp_info']['sharp_side']}
  RLM Detected: {betting_analysis['market_analysis']['rlm_info']['rlm_detected']}
  
True Spread: {betting_analysis['spread_analysis']['true_spread']:.1f}
Vegas Spread: {betting_analysis['vegas_spread']:.1f}
{'='*100}
"""

print(full_report)
```

---

## 📝 Data Structure Requirements

### Team Stats Dictionary

```python
{
    'ORB%': float,           # 20.0-35.0 typical range
    'DRB%': float,           # 70.0-85.0 typical range
    'TOV%': float,           # 8.0-18.0 typical range
    'Forced TOV%': float,    # 7.0-15.0 typical range
    'OFF_Efficiency': float, # 105.0-120.0 typical range
    'DEF_Efficiency': float, # 105.0-120.0 typical range
    'eFG%': float,           # 48.0-58.0 typical range
    'Opp_eFG%': float,       # 48.0-58.0 typical range
    '3PM_Game': float,       # 10.0-16.0 typical range
    'FT_Rate': float,        # 18.0-30.0 typical range
    'SOS': float,            # 1.0-30.0 (rank)
    'Edge_Count': float      # 0-12 (calculated)
}
```

### Power Rating Dictionary

```python
{
    'rank': int,                    # 1-30 for NBA
    'percentile': str,              # "Top 12%"
    'has_edge': bool,               # True if better rank
    'off_rank': int,                # Offensive efficiency rank
    'off_percentile': str,          # "Top 13%"
    'off_edge': bool,
    'off_diff': str,                # "+26"
    'def_rank': int,                # Defensive efficiency rank
    'def_percentile': str,          # "Top 17%"
    'def_edge': bool,
    'def_diff': str,                # "+33"
    'edge': str                     # Overall edge "+33"
}
```

---

## 🧪 Testing Your Data

Before going live, test with your data:

```python
def validate_stats(stats_dict):
    """
    Validate that stats are in reasonable ranges.
    """
    validations = {
        'ORB%': (15.0, 40.0),
        'DRB%': (65.0, 90.0),
        'TOV%': (5.0, 20.0),
        'OFF_Efficiency': (100.0, 125.0),
        'DEF_Efficiency': (100.0, 125.0),
        'eFG%': (40.0, 65.0),
        # ... etc
    }
    
    issues = []
    for metric, (min_val, max_val) in validations.items():
        if metric in stats_dict:
            val = stats_dict[metric]
            if not (min_val <= val <= max_val):
                issues.append(f"{metric} out of range: {val} (expected {min_val}-{max_val})")
    
    return issues

# Test
issues = validate_stats(your_bulls_stats)
if issues:
    print("Data validation issues:")
    for issue in issues:
        print(f"  - {issue}")
```

---

## 🔄 Updating for New Season

When the season changes:

1. Update season parameter in NBA.com API calls:
   ```python
   'Season': '2025-26'  # Change this
   ```

2. Update team IDs if new teams added

3. Recalibrate typical ranges if league-wide changes occur

---

## 💡 Pro Tips

### 1. Cache Data
Don't hit APIs repeatedly:

```python
import json
from datetime import datetime, timedelta

def get_cached_or_fetch(team_abbr, cache_hours=1):
    """
    Return cached data if fresh, otherwise fetch new.
    """
    cache_file = f"cache_{team_abbr}.json"
    
    try:
        with open(cache_file, 'r') as f:
            cached = json.load(f)
            cache_time = datetime.fromisoformat(cached['timestamp'])
            
            if datetime.now() - cache_time < timedelta(hours=cache_hours):
                return cached['data']
    except:
        pass
    
    # Fetch fresh data
    data = fetch_from_api(team_abbr)
    
    # Save to cache
    with open(cache_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'data': data
        }, f)
    
    return data
```

### 2. Rate Limit API Calls

```python
import time

def rate_limited_get(url, min_delay=2):
    """
    Add delay between requests.
    """
    time.sleep(min_delay)
    return requests.get(url)
```

### 3. Handle Missing Data Gracefully

```python
def safe_get_stats(team_abbr):
    """
    Return stats or None if unavailable.
    """
    try:
        return get_stats(team_abbr)
    except Exception as e:
        print(f"Error fetching {team_abbr}: {e}")
        return get_default_stats()
```

---

## 🎯 Next Steps

### Immediate (Today):
1. ✅ Run `matchup_table_generator.py` to see sample output
2. ✅ Understand the data structure requirements
3. ✅ Identify which data sources you'll use

### This Week:
1. Implement NBA.com API calls (easiest, free, accurate)
2. Implement TeamRankings.com scraping (for power ratings)
3. Test with real current season data
4. Validate output matches your needs

### This Month:
1. Add Covers.com scraping (for SOS and betting data)
2. Set up caching system
3. Integrate with main betting engine
4. Automate daily slate generation

---

## ❓ Troubleshooting

### Issue: "API returns 403 error"
**Solution:** Check headers, add proper User-Agent and Referer

### Issue: "Stats don't match what I see on website"
**Solution:** 
- Verify season parameter
- Check if using right stat type (per game vs per 100)
- Confirm team abbreviation/ID is correct

### Issue: "Power ratings not pulling"
**Solution:** TeamRankings may have changed HTML structure - inspect page and update selectors

### Issue: "Last 5 games data looks wrong"
**Solution:** Make sure `LastNGames` parameter is being sent correctly

---

## 📚 Additional Resources

- NBA.com Stats API: https://github.com/swar/nba_api (unofficial documentation)
- TeamRankings: Inspect page manually for current HTML structure
- Beautiful Soup docs: https://www.crummy.com/software/BeautifulSoup/bs4/doc/
- Pandas table formatting: https://pandas.pydata.org/docs/

---

## ✅ Deliverables Summary

You now have:

1. ✅ **Complete table formatting system** (matches your screenshot)
2. ✅ **Power rating display** (3 sections: overall, offensive, defensive)
3. ✅ **Season stats comparison**
4. ✅ **Last 5 games comparison**
5. ✅ **Edge summary** (NO "Savant Analytics" branding)
6. ✅ **Data structure specifications**
7. ✅ **Integration examples**
8. ✅ **API framework** (needs implementation)
9. ✅ **Sample data generator** (for testing)
10. ✅ **Validation tools**

**The table generator works NOW with sample data. You just need to wire in your data sources.**

Good luck! 🚀
