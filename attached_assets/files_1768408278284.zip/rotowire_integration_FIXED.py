"""
BULLETPROOF ROTOWIRE INTEGRATION - FIXED VERSION
Professional-grade injury and lineup tracking with robust error handling

FIXES IN THIS VERSION:
1. ✅ Impact score cap corrected (4.5 instead of 3.0)
2. ✅ Added helper functions that were missing
3. ✅ Improved team name matching
4. ✅ Better error messages
5. ✅ Added get_team_injury_status and get_game_injury_analysis functions
"""

import logging
import time
import requests
from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
from bs4 import BeautifulSoup
import re

logger = logging.getLogger(__name__)


class InjuryStatus(Enum):
    """Standardized injury statuses with impact scores."""
    OUT = ("OUT", 3.0)
    DOUBTFUL = ("DOUBTFUL", 2.5)
    GTD = ("GTD", 2.0)  # Game-Time Decision
    QUESTIONABLE = ("Q", 1.5)
    PROBABLE = ("PROB", 0.5)
    UNKNOWN = ("UNKNOWN", 1.0)
    
    def __init__(self, label: str, impact: float):
        self.label = label
        self.impact = impact
    
    @classmethod
    def from_text(cls, text: str) -> 'InjuryStatus':
        """Parse injury status from text with fuzzy matching."""
        text_upper = text.upper().strip()
        
        # Exact matches
        if "OUT" in text_upper:
            return cls.OUT
        if "DOUBTFUL" in text_upper:
            return cls.DOUBTFUL
        if "QUESTIONABLE" in text_upper or text_upper == "Q":
            return cls.QUESTIONABLE
        if "PROBABLE" in text_upper:
            return cls.PROBABLE
        if "GTD" in text_upper or "GAME TIME" in text_upper:
            return cls.GTD
        
        return cls.UNKNOWN


@dataclass
class InjuredPlayer:
    """Represents an injured player with all relevant data."""
    name: str
    team: str
    position: str
    status: InjuryStatus
    injury: str
    source: str  # 'rotowire' or 'espn'
    is_starter: bool = False
    minutes_per_game: float = 0.0
    points_per_game: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def impact_score(self) -> float:
        """
        Calculate injury impact score (0-4.5).
        
        FIXED: Changed cap from 3.0 to 4.5 to allow OUT starters to trigger
        disqualification threshold.
        """
        base_impact = self.status.impact
        
        # Multiply by starter bonus
        if self.is_starter:
            base_impact *= 1.5
        
        # Cap at 4.5 (not 3.0!)
        return min(base_impact, 4.5)
    
    def __repr__(self) -> str:
        return f"{self.name} ({self.position}) - {self.status.label}: {self.injury}"


@dataclass
class LineupData:
    """Represents confirmed starting lineup."""
    team: str
    league: str
    starters: List[str]
    confirmed: bool
    source: str  # 'rotowire' or 'espn'
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def strength_indicator(self) -> str:
        """Estimate lineup strength based on number of confirmed starters."""
        if not self.confirmed:
            return "UNKNOWN"
        
        count = len(self.starters)
        if count >= 5:  # NBA/NHL full lineup
            return "FULL_STRENGTH"
        elif count >= 3:
            return "PARTIAL"
        else:
            return "WEAK"


class RotoWireCache:
    """Time-based cache with source tracking."""
    
    def __init__(self, ttl_seconds: int = 3600):
        self._cache: Dict[str, Tuple[any, datetime, str]] = {}
        self._ttl = timedelta(seconds=ttl_seconds)
    
    def get(self, key: str) -> Optional[Tuple[any, str]]:
        """Get cached value and source if not expired."""
        if key in self._cache:
            value, timestamp, source = self._cache[key]
            if datetime.now() - timestamp < self._ttl:
                return (value, source)
            del self._cache[key]
        return None
    
    def set(self, key: str, value: any, source: str):
        """Cache value with source and timestamp."""
        self._cache[key] = (value, datetime.now(), source)
    
    def clear(self):
        """Clear all cached data."""
        self._cache.clear()
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        now = datetime.now()
        valid_entries = sum(1 for _, ts, _ in self._cache.values() 
                           if now - ts < self._ttl)
        return {
            'total_entries': len(self._cache),
            'valid_entries': valid_entries,
            'ttl_seconds': self._ttl.total_seconds()
        }


class RotoWireScraper:
    """
    Professional RotoWire scraper with robust error handling.
    
    Rate Limiting:
    - 1 request per 2 seconds to be respectful
    - Exponential backoff on failures
    - Circuit breaker pattern after 3 consecutive failures
    
    Error Handling:
    - Comprehensive try-catch blocks
    - Fallback to ESPN on any failure
    - Detailed logging for debugging
    - Data validation before returning
    """
    
    ROTOWIRE_BASE = "https://www.rotowire.com"
    ESPN_BASE = "https://www.espn.com"
    
    ROTOWIRE_URLS = {
        'NBA': {
            'injuries': f"{ROTOWIRE_BASE}/basketball/nba/injury-report.php",
            'lineups': f"{ROTOWIRE_BASE}/basketball/nba/daily-lineups.php"
        },
        'NFL': {
            'injuries': f"{ROTOWIRE_BASE}/football/nfl/injury-report.php",
            'lineups': f"{ROTOWIRE_BASE}/football/nfl/daily-lineups.php"
        },
        'NHL': {
            'injuries': f"{ROTOWIRE_BASE}/hockey/nhl/injury-report.php",
            'lineups': f"{ROTOWIRE_BASE}/hockey/nhl/daily-lineups.php"
        },
        'CBB': {
            'injuries': f"{ROTOWIRE_BASE}/basketball/college-basketball/injury-report.php",
            'lineups': None  # CBB doesn't have daily lineups on RotoWire
        }
    }
    
    ESPN_URLS = {
        'NBA': f"{ESPN_BASE}/nba/injuries",
        'NFL': f"{ESPN_BASE}/nfl/injuries",
        'NHL': f"{ESPN_BASE}/nhl/injuries",
        'CBB': f"{ESPN_BASE}/mens-college-basketball/injuries"
    }
    
    # Team name aliases for better matching
    TEAM_ALIASES = {
        'lakers': ['los angeles lakers', 'la lakers', 'l.a. lakers'],
        'clippers': ['los angeles clippers', 'la clippers', 'l.a. clippers'],
        'warriors': ['golden state warriors', 'gs warriors'],
        'trail blazers': ['portland trail blazers', 'blazers', 'portland'],
        '76ers': ['philadelphia 76ers', 'sixers'],
        'heat': ['miami heat'],
        'nets': ['brooklyn nets'],
        # Add more as needed
    }
    
    def __init__(self, cache_ttl: int = 3600):
        self._cache = RotoWireCache(ttl_seconds=cache_ttl)
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self._last_request_time = 0
        self._failure_count = 0
        self._circuit_open = False
        self._circuit_open_until = 0
    
    def _rate_limit(self):
        """Enforce 2-second delay between requests."""
        elapsed = time.time() - self._last_request_time
        if elapsed < 2.0:
            time.sleep(2.0 - elapsed)
        self._last_request_time = time.time()
    
    def _check_circuit_breaker(self) -> bool:
        """Check if circuit breaker is open."""
        if self._circuit_open:
            if time.time() > self._circuit_open_until:
                logger.info("Circuit breaker closing, retrying RotoWire")
                self._circuit_open = False
                self._failure_count = 0
                return False
            return True
        return False
    
    def _record_failure(self):
        """Record failure and potentially open circuit breaker."""
        self._failure_count += 1
        if self._failure_count >= 3:
            self._circuit_open = True
            self._circuit_open_until = time.time() + 300  # 5 minute cooldown
            logger.warning("🔴 Circuit breaker OPEN - 3 consecutive RotoWire failures. Using ESPN fallback for 5 minutes.")
    
    def _record_success(self):
        """Reset failure count on success."""
        self._failure_count = max(0, self._failure_count - 1)
    
    def _fetch_url(self, url: str, timeout: int = 15) -> Optional[BeautifulSoup]:
        """
        Fetch and parse URL with comprehensive error handling.
        
        Returns None on any error, allowing caller to fallback gracefully.
        """
        try:
            self._rate_limit()
            
            response = self._session.get(url, timeout=timeout)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            self._record_success()
            return soup
            
        except requests.exceptions.Timeout:
            logger.error(f"RotoWire timeout: {url}")
            self._record_failure()
            return None
        except requests.exceptions.HTTPError as e:
            logger.error(f"RotoWire HTTP error {e.response.status_code}: {url}")
            self._record_failure()
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"RotoWire request failed: {url} - {str(e)}")
            self._record_failure()
            return None
        except Exception as e:
            logger.error(f"RotoWire unexpected error: {url} - {str(e)}")
            self._record_failure()
            return None
    
    def get_injuries(self, team: str, league: str) -> Tuple[List[InjuredPlayer], str]:
        """
        Get injury report for a team with automatic ESPN fallback.
        
        Returns:
            (list of InjuredPlayer objects, source name)
            Source will be 'rotowire', 'espn', or 'none'
        """
        cache_key = f"injuries:{league}:{team}"
        
        # Check cache
        cached = self._cache.get(cache_key)
        if cached:
            injuries, source = cached
            logger.debug(f"💾 Cache hit: {team} injuries from {source}")
            return injuries, source
        
        # Try RotoWire first (unless circuit breaker is open)
        if not self._check_circuit_breaker():
            injuries = self._get_injuries_rotowire(team, league)
            if injuries is not None:
                self._cache.set(cache_key, injuries, 'rotowire')
                logger.info(f"✅ RotoWire: Found {len(injuries)} injuries for {team}")
                return injuries, 'rotowire'
        
        # Fallback to ESPN
        logger.info(f"⚠️  Falling back to ESPN for {team} injuries")
        injuries = self._get_injuries_espn(team, league)
        if injuries is not None:
            self._cache.set(cache_key, injuries, 'espn')
            logger.info(f"✅ ESPN: Found {len(injuries)} injuries for {team}")
            return injuries, 'espn'
        
        # Complete failure
        logger.warning(f"❌ Could not fetch injuries for {team} from any source")
        return [], 'none'
    
    def _get_injuries_rotowire(self, team: str, league: str) -> Optional[List[InjuredPlayer]]:
        """Scrape RotoWire injury report."""
        if league not in self.ROTOWIRE_URLS:
            return None
        
        url = self.ROTOWIRE_URLS[league]['injuries']
        soup = self._fetch_url(url)
        if not soup:
            return None
        
        injuries = []
        
        try:
            # RotoWire uses tables or div structures for injuries
            # Try multiple selectors to handle different HTML structures
            injury_sections = (
                soup.find_all('div', class_='injury-report__team') or
                soup.find_all('table', class_='tablesorter') or
                soup.find_all('div', class_='lineup__box')
            )
            
            for section in injury_sections:
                # Check if this is the team we want
                team_elem = (
                    section.find('div', class_='injury-report__team-name') or
                    section.find('a', class_='lineup__abbr') or
                    section.find('th', class_='teamheader')
                )
                
                if not team_elem:
                    continue
                
                team_name = team_elem.text.strip()
                if not self._team_matches(team, team_name):
                    continue
                
                # Parse injury rows for this team
                injury_rows = (
                    section.find_all('div', class_='injury-report__row') or
                    section.find_all('tr')[1:]  # Skip header row
                )
                
                for row in injury_rows:
                    try:
                        # Try different HTML structures
                        player_name = (
                            row.find('a', class_='injury-report__player-name') or
                            row.find('a') or
                            row.find('td')
                        )
                        
                        if not player_name:
                            continue
                        
                        name = player_name.text.strip()
                        
                        # Extract position
                        position_elem = (
                            row.find('span', class_='injury-report__position') or
                            row.find_all('td')[1] if len(row.find_all('td')) > 1 else None
                        )
                        position = position_elem.text.strip() if position_elem else 'N/A'
                        
                        # Extract status
                        status_elem = (
                            row.find('span', class_='injury-report__status') or
                            row.find_all('td')[2] if len(row.find_all('td')) > 2 else None
                        )
                        status_text = status_elem.text.strip() if status_elem else 'QUESTIONABLE'
                        status = InjuryStatus.from_text(status_text)
                        
                        # Extract injury description
                        injury_elem = (
                            row.find('span', class_='injury-report__injury') or
                            row.find_all('td')[3] if len(row.find_all('td')) > 3 else None
                        )
                        injury_desc = injury_elem.text.strip() if injury_elem else 'Undisclosed'
                        
                        # Determine if starter based on position
                        is_starter = position in ['PG', 'SG', 'SF', 'PF', 'C', 'QB', 'RB', 'WR', 'TE', 'C', 'RW', 'LW', 'D', 'G']
                        
                        injuries.append(InjuredPlayer(
                            name=name,
                            team=team,
                            position=position,
                            status=status,
                            injury=injury_desc,
                            source='rotowire',
                            is_starter=is_starter
                        ))
                        
                    except Exception as e:
                        logger.debug(f"Error parsing injury row: {str(e)}")
                        continue
            
            return injuries if injuries else None
            
        except Exception as e:
            logger.error(f"Error parsing RotoWire injuries: {str(e)}")
            return None
    
    def _get_injuries_espn(self, team: str, league: str) -> Optional[List[InjuredPlayer]]:
        """Scrape ESPN injury report as fallback."""
        if league not in self.ESPN_URLS:
            return None
        
        url = self.ESPN_URLS[league]
        soup = self._fetch_url(url)
        if not soup:
            return None
        
        injuries = []
        
        try:
            # ESPN uses <div class="ResponsiveTable"> for injuries
            injury_tables = soup.find_all('div', class_='ResponsiveTable')
            
            for table in injury_tables:
                # Check team name in header
                team_header = table.find_previous('h2') or table.find_previous('div', class_='team__name')
                if not team_header:
                    continue
                
                team_name = team_header.text.strip()
                if not self._team_matches(team, team_name):
                    continue
                
                # Parse injury rows
                rows = table.find_all('tr')
                for row in rows:
                    try:
                        cells = row.find_all('td')
                        if len(cells) < 3:
                            continue
                        
                        name = cells[0].text.strip()
                        position = cells[1].text.strip() if len(cells) > 1 else 'N/A'
                        status_text = cells[2].text.strip() if len(cells) > 2 else 'QUESTIONABLE'
                        injury_desc = cells[3].text.strip() if len(cells) > 3 else 'Undisclosed'
                        
                        status = InjuryStatus.from_text(status_text)
                        
                        injuries.append(InjuredPlayer(
                            name=name,
                            team=team,
                            position=position,
                            status=status,
                            injury=injury_desc,
                            source='espn',
                            is_starter=False  # ESPN doesn't indicate starters
                        ))
                        
                    except Exception as e:
                        logger.debug(f"Error parsing ESPN injury row: {str(e)}")
                        continue
            
            return injuries if injuries else None
            
        except Exception as e:
            logger.error(f"Error parsing ESPN injuries: {str(e)}")
            return None
    
    def get_lineups(self, team: str, league: str) -> Optional[Tuple[LineupData, str]]:
        """
        Get confirmed starting lineups from RotoWire.
        
        Returns:
            (LineupData object, source name) or (None, 'none')
        """
        if league == 'CBB':
            logger.debug("CBB lineups not available on RotoWire")
            return None, 'none'
        
        cache_key = f"lineups:{league}:{team}"
        
        # Check cache
        cached = self._cache.get(cache_key)
        if cached:
            lineup, source = cached
            logger.debug(f"💾 Cache hit: {team} lineup from {source}")
            return lineup, source
        
        # Check circuit breaker
        if self._check_circuit_breaker():
            logger.debug("Circuit breaker open, skipping lineup fetch")
            return None, 'none'
        
        # Fetch from RotoWire
        lineup = self._get_lineups_rotowire(team, league)
        if lineup:
            self._cache.set(cache_key, lineup, 'rotowire')
            logger.info(f"✅ RotoWire: Found lineup for {team} ({len(lineup.starters)} starters)")
            return lineup, 'rotowire'
        
        return None, 'none'
    
    def _get_lineups_rotowire(self, team: str, league: str) -> Optional[LineupData]:
        """Scrape RotoWire starting lineups."""
        if league not in self.ROTOWIRE_URLS or not self.ROTOWIRE_URLS[league]['lineups']:
            return None
        
        url = self.ROTOWIRE_URLS[league]['lineups']
        soup = self._fetch_url(url)
        if not soup:
            return None
        
        try:
            # RotoWire lineups use <div class="lineup"> structure
            lineup_sections = soup.find_all('div', class_='lineup')
            
            for section in lineup_sections:
                # Check team name
                team_elem = section.find('div', class_='lineup__abbr') or section.find('a', class_='lineup__team')
                if not team_elem:
                    continue
                
                team_name = team_elem.text.strip()
                if not self._team_matches(team, team_name):
                    continue
                
                # Extract starters
                starters = []
                starter_rows = section.find_all('div', class_='lineup__player') or section.find_all('a', class_='lineup__player')
                
                for row in starter_rows:
                    try:
                        player_name = row.find('a') or row
                        if player_name:
                            starters.append(player_name.text.strip())
                    except:
                        continue
                
                # Check if lineup is confirmed
                status_elem = section.find('div', class_='lineup__status')
                confirmed = False
                if status_elem:
                    status_text = status_elem.text.strip().upper()
                    confirmed = 'CONFIRMED' in status_text or 'EXPECTED' in status_text
                
                return LineupData(
                    team=team,
                    league=league,
                    starters=starters,
                    confirmed=confirmed,
                    source='rotowire'
                )
            
            return None
            
        except Exception as e:
            logger.error(f"Error parsing RotoWire lineups: {str(e)}")
            return None
    
    def _team_matches(self, target: str, scraped: str) -> bool:
        """
        IMPROVED: Stricter team name matching with aliases.
        """
        target_clean = target.lower().strip().replace('.', '')
        scraped_clean = scraped.lower().strip().replace('.', '')
        
        # Direct match
        if target_clean == scraped_clean:
            return True
        
        # One contains the other
        if target_clean in scraped_clean or scraped_clean in target_clean:
            return True
        
        # Check aliases
        for key, aliases in self.TEAM_ALIASES.items():
            target_in_aliases = any(alias in target_clean for alias in aliases + [key])
            scraped_in_aliases = any(alias in scraped_clean for alias in aliases + [key])
            if target_in_aliases and scraped_in_aliases:
                return True
        
        # Word-based matching (require at least 2 common words)
        target_words = set(target_clean.split())
        scraped_words = set(scraped_clean.split())
        common_words = target_words & scraped_words
        
        # Filter out common words like "the", "of", etc.
        stop_words = {'the', 'of', 'in', 'at', 'and', 'or'}
        meaningful_common = common_words - stop_words
        
        return len(meaningful_common) >= 2
    
    def get_cache_stats(self) -> Dict:
        """Get cache statistics for monitoring."""
        return self._cache.get_stats()


class InjuryImpactCalculator:
    """
    Calculate the impact of injuries on game qualification.
    
    Impact Scoring:
    - OUT starter: 4.5 points (FIXED: was capped at 3.0)
    - OUT bench: 3.0 points
    - DOUBTFUL starter: 3.75 points
    - QUESTIONABLE starter: 2.25 points
    - PROBABLE starter: 0.75 points
    
    Disqualification Thresholds:
    - Total impact >= 4.5: DISQUALIFY game
    - Total impact 3.0-4.4: WARNING flag
    - Total impact < 3.0: OK to play
    """
    
    DISQUALIFY_THRESHOLD = 4.5
    WARNING_THRESHOLD = 3.0
    
    @classmethod
    def calculate_team_impact(cls, injuries: List[InjuredPlayer]) -> Dict:
        """Calculate total injury impact for a team."""
        if not injuries:
            return {
                'total_impact': 0.0,
                'out_count': 0,
                'doubtful_count': 0,
                'questionable_count': 0,
                'starter_out_count': 0,
                'should_disqualify': False,
                'warning_flag': False,
                'details': [],
                'source': 'none'
            }
        
        total_impact = 0.0
        out_count = 0
        doubtful_count = 0
        questionable_count = 0
        starter_out_count = 0
        details = []
        
        for injury in injuries:
            impact = injury.impact_score
            total_impact += impact
            
            if injury.status == InjuryStatus.OUT:
                out_count += 1
                if injury.is_starter:
                    starter_out_count += 1
            elif injury.status == InjuryStatus.DOUBTFUL:
                doubtful_count += 1
            elif injury.status in [InjuryStatus.QUESTIONABLE, InjuryStatus.GTD]:
                questionable_count += 1
            
            details.append({
                'name': injury.name,
                'position': injury.position,
                'status': injury.status.label,
                'impact': impact,
                'is_starter': injury.is_starter
            })
        
        return {
            'total_impact': round(total_impact, 2),
            'out_count': out_count,
            'doubtful_count': doubtful_count,
            'questionable_count': questionable_count,
            'starter_out_count': starter_out_count,
            'should_disqualify': total_impact >= cls.DISQUALIFY_THRESHOLD,
            'warning_flag': cls.WARNING_THRESHOLD <= total_impact < cls.DISQUALIFY_THRESHOLD,
            'details': details,
            'source': injuries[0].source if injuries else 'none'
        }
    
    @classmethod
    def calculate_game_impact(cls, away_injuries: List[InjuredPlayer], 
                             home_injuries: List[InjuredPlayer]) -> Dict:
        """Calculate injury impact for both teams in a game."""
        away_impact = cls.calculate_team_impact(away_injuries)
        home_impact = cls.calculate_team_impact(home_injuries)
        
        # Determine if game should be disqualified
        away_disqualify = away_impact['should_disqualify']
        home_disqualify = home_impact['should_disqualify']
        
        # Asymmetric impact check (one team much more injured than other)
        impact_diff = abs(away_impact['total_impact'] - home_impact['total_impact'])
        asymmetric_concern = impact_diff >= 3.0
        
        return {
            'away': away_impact,
            'home': home_impact,
            'should_disqualify': away_disqualify or home_disqualify,
            'asymmetric_concern': asymmetric_concern,
            'total_impact': away_impact['total_impact'] + home_impact['total_impact'],
            'recommendation': cls._get_recommendation(away_disqualify, home_disqualify, 
                                                     asymmetric_concern)
        }
    
    @classmethod
    def _get_recommendation(cls, away_dq: bool, home_dq: bool, 
                           asymmetric: bool) -> str:
        """Generate recommendation based on injury analysis."""
        if away_dq and home_dq:
            return "DISQUALIFY - Both teams have major injury concerns"
        elif away_dq:
            return "DISQUALIFY - Away team has major injury concerns"
        elif home_dq:
            return "DISQUALIFY - Home team has major injury concerns"
        elif asymmetric:
            return "WARNING - Significant injury imbalance between teams"
        else:
            return "OK - No major injury concerns"


# ============================================================================
# PUBLIC API - Use these functions in your main app
# ============================================================================

# Global scraper instance (reuses session and cache)
_scraper_instance = None

def get_scraper(cache_ttl: int = 3600) -> RotoWireScraper:
    """Get or create global scraper instance."""
    global _scraper_instance
    if _scraper_instance is None:
        _scraper_instance = RotoWireScraper(cache_ttl=cache_ttl)
    return _scraper_instance


def fetch_team_injuries(team: str, league: str) -> Tuple[List[InjuredPlayer], str]:
    """
    Fetch injuries for a team with automatic fallback.
    
    Args:
        team: Team name (e.g., "Lakers", "Cowboys")
        league: League code ("NBA", "NFL", "NHL", "CBB")
    
    Returns:
        (list of InjuredPlayer objects, source name)
        Source will be 'rotowire', 'espn', or 'none'
    """
    scraper = get_scraper()
    return scraper.get_injuries(team, league)


def fetch_team_lineup(team: str, league: str) -> Optional[LineupData]:
    """
    Fetch confirmed starting lineup for a team.
    
    Args:
        team: Team name
        league: League code ("NBA", "NFL", "NHL")
    
    Returns:
        LineupData object or None if not available
    """
    scraper = get_scraper()
    lineup, source = scraper.get_lineups(team, league)
    return lineup


def check_game_injuries(away_team: str, home_team: str, league: str) -> Dict:
    """
    Check injuries for both teams and determine game qualification impact.
    
    Args:
        away_team: Away team name
        home_team: Home team name
        league: League code
    
    Returns:
        Dict with complete injury analysis including disqualification recommendation
    """
    scraper = get_scraper()
    
    away_injuries, away_source = scraper.get_injuries(away_team, league)
    home_injuries, home_source = scraper.get_injuries(home_team, league)
    
    return InjuryImpactCalculator.calculate_game_impact(away_injuries, home_injuries)


def get_team_injury_status(team: str, league: str) -> Dict:
    """
    NEW FUNCTION: Get injury status summary for a single team.
    
    Returns:
        Dict with injury summary
    """
    injuries, source = fetch_team_injuries(team, league)
    impact_data = InjuryImpactCalculator.calculate_team_impact(injuries)
    
    return {
        'team': team,
        'league': league,
        'total_injuries': len(injuries),
        'out_count': impact_data['out_count'],
        'questionable_count': impact_data['questionable_count'],
        'starter_out_count': impact_data['starter_out_count'],
        'total_impact': impact_data['total_impact'],
        'should_disqualify': impact_data['should_disqualify'],
        'source': source
    }


def get_game_injury_analysis(away_team: str, home_team: str, league: str) -> Dict:
    """
    NEW FUNCTION: Alias for check_game_injuries for backward compatibility.
    """
    return check_game_injuries(away_team, home_team, league)


def get_cache_stats() -> Dict:
    """Get cache statistics for monitoring."""
    scraper = get_scraper()
    return scraper.get_cache_stats()


def clear_cache():
    """Clear all cached data (use for testing or manual refresh)."""
    scraper = get_scraper()
    scraper._cache.clear()
    logger.info("RotoWire cache cleared")


if __name__ == "__main__":
    # Quick test
    logging.basicConfig(level=logging.INFO)
    print("Testing RotoWire integration...")
    injuries, source = fetch_team_injuries("Lakers", "NBA")
    print(f"Found {len(injuries)} injuries from {source}")
    for inj in injuries[:3]:
        print(f"  - {inj.name}: {inj.status.label} (Impact: {inj.impact_score})")
