# 🔍 COMPREHENSIVE CODE CRITIQUE & IMPROVEMENTS

## Executive Summary

I've analyzed your entire sports betting system (12,289 lines of code across 7 files). Overall, the codebase is **solid and functional**, but there are **critical issues** that need fixing to ensure correctness, reliability, and optimal performance.

**Status**: 🟡 FUNCTIONAL BUT NEEDS IMPROVEMENTS

**Priority Fixes Required**: 7 critical, 12 high-priority, 18 medium-priority

---

## 🚨 CRITICAL ISSUES (Fix Immediately)

### 1. **RotoWire Integration Not Applied in Qualification**

**ISSUE**: The `fetch_odds_internal()` function calls `check_qualification_professional()` but does NOT integrate RotoWire injury checking before qualification.

**Location**: `sports_app.py`, lines 6790-6801

**Current Code**:
```python
# SHARP QUALIFICATION
qual_result = check_qualification_professional(
    projected_total=proj_total,
    line=line,
    over_odds=over_odds,
    under_odds=under_odds,
    league=league,
    pinnacle_over_odds=pinn_over_odds,
    pinnacle_under_odds=pinn_under_odds,
    historical_win_rate=history_rate,
    sample_size=sample
)
```

**PROBLEM**: No injury check happens before qualification. This means:
- Games with major injuries can still qualify
- RotoWire integration is imported but not used
- The whole purpose of RotoWire (injury-based disqualification) is bypassed

**FIX**: Add pre-flight injury check:
```python
# PRE-FLIGHT INJURY CHECK (RotoWire)
injury_result = quick_injury_check(game.away_team, game.home_team, league)
if not injury_result['should_play']:
    logger.warning(
        f"{game.away_team} @ {game.home_team}: DISQUALIFIED - {injury_result['recommendation']}"
    )
    game.is_qualified = False
    continue  # Skip this game

# If injury check passes, proceed with qualification
qual_result = check_qualification_professional(...)
```

**IMPACT**: HIGH - This is the main integration point. Without this fix, RotoWire does nothing.

---

### 2. **Missing Database Columns for RotoWire Tracking**

**ISSUE**: The `Pick` model doesn't have columns to store injury source and impact data.

**Location**: `sports_app.py`, lines 3665-3690

**Current Model**:
```python
class Pick(db.Model):
    # ... existing columns ...
    # NO INJURY TRACKING COLUMNS
```

**PROBLEM**: 
- Can't track which picks used RotoWire vs ESPN
- Can't analyze injury impact on pick performance
- Can't optimize based on data source quality

**FIX**: Add these columns to the `Pick` model:
```python
class Pick(db.Model):
    # ... existing columns ...
    
    # RotoWire tracking
    injury_source = db.Column(db.String(20))  # 'rotowire', 'espn', 'none'
    away_injury_impact = db.Column(db.Float, default=0.0)
    home_injury_impact = db.Column(db.Float, default=0.0)
    lineup_confirmed = db.Column(db.Boolean, default=False)
    injury_check_timestamp = db.Column(db.DateTime)
```

**Database Migration**:
```sql
ALTER TABLE pick ADD COLUMN injury_source VARCHAR(20);
ALTER TABLE pick ADD COLUMN away_injury_impact FLOAT DEFAULT 0.0;
ALTER TABLE pick ADD COLUMN home_injury_impact FLOAT DEFAULT 0.0;
ALTER TABLE pick ADD COLUMN lineup_confirmed BOOLEAN DEFAULT FALSE;
ALTER TABLE pick ADD COLUMN injury_check_timestamp TIMESTAMP;
```

**IMPACT**: CRITICAL - Without these columns, you can't track RotoWire effectiveness.

---

### 3. **Impact Score Calculation Error**

**ISSUE**: The impact score cap logic is incorrect.

**Location**: `rotowire_integration.py`, lines 74-80

**Current Code**:
```python
@property
def impact_score(self) -> float:
    """Calculate injury impact score (0-3.0)."""
    base_impact = self.status.impact
    if self.is_starter:
        base_impact *= 1.5
    return min(base_impact, 3.0)  # ❌ WRONG CAP
```

**PROBLEM**: 
- OUT starter: 3.0 × 1.5 = 4.5, capped to 3.0
- But disqualification threshold is 4.5!
- This means OUT starters (4.5 impact) will never trigger disqualification

**CORRECT LOGIC**:
```python
@property
def impact_score(self) -> float:
    """Calculate injury impact score (0-4.5)."""
    base_impact = self.status.impact
    if self.is_starter:
        base_impact *= 1.5
    return min(base_impact, 4.5)  # ✅ CORRECT CAP
```

**OR** keep the 3.0 cap but lower the disqualification threshold:
```python
# In InjuryImpactCalculator
DISQUALIFY_THRESHOLD = 3.0  # Instead of 4.5
```

**IMPACT**: CRITICAL - OUT starters won't disqualify games as intended.

---

### 4. **Edge Threshold Inconsistency**

**ISSUE**: Edge thresholds differ between files.

**Locations**: 
- `sports_app.py`, lines 89-95: NBA=8.0, NFL=3.5, NHL=0.5
- `rotowire_qualification.py`, lines 46-52: Same values ✅

**PROBLEM**: If you update one file, you must update the other. Risk of desync.

**FIX**: Create a single source of truth:
```python
# In a new file: config.py
class BettingConfig:
    EDGE_THRESHOLDS = {
        "NBA": 8.0,
        "CBB": 8.0,
        "NFL": 3.5,
        "CFB": 3.5,
        "NHL": 0.5
    }
    
    MIN_GAMES = {
        "NBA": 8,
        "CBB": 8,
        "NFL": 4,
        "CFB": 4,
        "NHL": 8
    }
    
    HISTORY_QUALIFY_RATE = 0.60
    MIN_EV = 0.0

# Then import everywhere:
from config import BettingConfig
```

**IMPACT**: HIGH - Prevents desync bugs.

---

### 5. **Circuit Breaker State Not Persisted**

**ISSUE**: Circuit breaker state is in-memory only.

**Location**: `rotowire_integration.py`, lines 251-267

**PROBLEM**:
- App restart = circuit breaker state lost
- Multiple workers = each has separate circuit breaker
- Can't monitor circuit breaker across instances

**FIX**: Store circuit breaker state in database:
```python
class RotoWireCircuitBreaker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    is_open = db.Column(db.Boolean, default=False)
    failure_count = db.Column(db.Integer, default=0)
    open_until = db.Column(db.DateTime)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
```

**Or** use Redis for distributed state:
```python
import redis
r = redis.Redis()
r.set('rotowire:circuit_open', '1')
r.expire('rotowire:circuit_open', 300)  # 5 minute TTL
```

**IMPACT**: HIGH - Multi-worker deployments need this.

---

### 6. **Missing Error Handling in Auto-Save**

**ISSUE**: `auto_save_qualified_picks()` has validation but doesn't handle database exceptions.

**Location**: `sports_app.py`, lines 3737-3850

**Current Code**:
```python
for pick_data in top_picks:
    # Validation checks...
    new_pick = Pick(...)
    db.session.add(new_pick)
    # ❌ No try-catch for db.session.commit()
```

**PROBLEM**: Database errors will crash the entire save operation.

**FIX**:
```python
saved_count = 0
errors = []

for pick_data in top_picks:
    try:
        # Validation checks...
        new_pick = Pick(...)
        db.session.add(new_pick)
        db.session.flush()  # Flush to catch errors immediately
        saved_count += 1
    except Exception as e:
        db.session.rollback()
        errors.append(f"{pick_data.get('matchup')}: {str(e)}")
        logger.error(f"Error saving pick: {e}")
        continue

if saved_count > 0:
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        logger.error(f"Final commit failed: {e}")
        return 0

logger.info(f"Saved {saved_count} picks, {len(errors)} errors")
return saved_count
```

**IMPACT**: HIGH - Prevents data loss.

---

### 7. **Timezone Handling Inconsistency**

**ISSUE**: Mixing UTC and ET timezones without clear conversion.

**Locations**: Multiple throughout `sports_app.py`

**PROBLEMS**:
- `created_at = db.Column(db.DateTime, default=datetime.utcnow)` - UTC
- `datetime.now(et)` - ET
- Comparing UTC and ET times without conversion

**FIX**: Standardize on UTC internally, convert to ET for display only:
```python
# Always store in UTC
created_at = db.Column(db.DateTime, default=lambda: datetime.now(pytz.UTC))

# Convert for display
def to_et(utc_time):
    et = pytz.timezone('America/New_York')
    return utc_time.replace(tzinfo=pytz.UTC).astimezone(et)

# Convert user input to UTC
def from_et(et_time):
    et = pytz.timezone('America/New_York')
    return et.localize(et_time).astimezone(pytz.UTC)
```

**IMPACT**: CRITICAL - Timezone bugs cause wrong game times.

---

## 🔶 HIGH-PRIORITY ISSUES

### 8. **No Retry Logic for API Calls**

**ISSUE**: API calls don't retry on transient failures.

**Location**: `sports_app.py`, line 974-1000

**FIX**: Add retry decorator:
```python
from functools import wraps
import time

def retry(max_attempts=3, delay=1, backoff=2):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except (requests.Timeout, requests.ConnectionError) as e:
                    if attempt == max_attempts - 1:
                        raise
                    wait_time = delay * (backoff ** attempt)
                    logger.warning(f"Retry {attempt+1}/{max_attempts} after {wait_time}s: {e}")
                    time.sleep(wait_time)
        return wrapper
    return decorator

@retry(max_attempts=3, delay=2, backoff=2)
def fetch_odds_api_safe(url: str, params: dict, timeout: int = 30) -> dict:
    # existing code...
```

---

### 9. **Cache TTL Not Configurable**

**ISSUE**: Cache TTL is hardcoded to 3600 seconds.

**FIX**: Make it configurable via environment variable:
```python
CACHE_TTL = int(os.environ.get("ROTOWIRE_CACHE_TTL", "3600"))
_scraper_instance = RotoWireScraper(cache_ttl=CACHE_TTL)
```

---

### 10. **No Logging of Disqualification Reasons**

**ISSUE**: When games are disqualified, the reason isn't logged clearly.

**FIX**: Add structured logging:
```python
if not injury_result['should_play']:
    logger.warning(
        f"DISQUALIFIED - {game.away_team} @ {game.home_team}",
        extra={
            'reason': 'injury_concern',
            'away_impact': injury_result['away_impact'],
            'home_impact': injury_result['home_impact'],
            'source': injury_result['source'],
            'recommendation': injury_result['recommendation']
        }
    )
```

---

### 11. **Missing Index on injury_source Column**

**ISSUE**: New injury tracking columns don't have indexes.

**FIX**: Add indexes for query performance:
```python
__table_args__ = (
    # ... existing indexes ...
    db.Index('idx_injury_source', 'injury_source'),
    db.Index('idx_lineup_confirmed', 'lineup_confirmed'),
)
```

---

### 12. **No Validation of Injury Impact Bounds**

**ISSUE**: Impact scores aren't validated before storing.

**FIX**: Add validation in Pick model:
```python
@validates('away_injury_impact', 'home_injury_impact')
def validate_injury_impact(self, key, value):
    if value is not None and (value < 0 or value > 10):
        raise ValueError(f"{key} must be between 0 and 10")
    return value
```

---

### 13. **RotoWire Functions Have Different Names Than Expected**

**ISSUE**: The imports in `sports_app.py` reference functions that don't exist in the new `rotowire_integration.py`.

**Current Imports (line 17-25)**:
```python
from rotowire_integration import (
    get_team_injury_status,  # ❌ Doesn't exist
    get_game_injury_analysis,  # ❌ Doesn't exist
    # ... other functions
)
```

**Available Functions**:
```python
# From rotowire_integration.py
fetch_team_injuries
fetch_team_lineup
check_game_injuries
get_cache_stats
clear_cache
```

**FIX**: Update imports to match actual function names:
```python
from rotowire_integration import (
    fetch_team_injuries as rotowire_fetch_injuries,
    fetch_team_lineup as rotowire_fetch_lineup,
    check_game_injuries as rotowire_check_game_injuries,
    get_cache_stats as get_rotowire_cache_stats,
    clear_cache as clear_rotowire_cache
)
```

---

### 14. **Missing Rate Limiting Between Injury Checks**

**ISSUE**: If checking injuries for 20 games simultaneously, you'll hit 20 requests at once.

**FIX**: Add batch processing with delays:
```python
def check_injuries_batch(games, league):
    results = {}
    for i, game in enumerate(games):
        results[game.id] = quick_injury_check(
            game.away_team, game.home_team, league
        )
        if i < len(games) - 1:
            time.sleep(0.5)  # 500ms delay between checks
    return results
```

---

### 15. **No Monitoring Metrics for RotoWire**

**ISSUE**: Can't track RotoWire performance over time.

**FIX**: Add metrics collection:
```python
class RotoWireMetrics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    source = db.Column(db.String(20))  # 'rotowire' or 'espn'
    success = db.Column(db.Boolean)
    response_time_ms = db.Column(db.Integer)
    games_checked = db.Column(db.Integer)
    cache_hit = db.Column(db.Boolean)
```

---

### 16. **Team Name Matching Too Loose**

**ISSUE**: `_team_matches()` function might match wrong teams.

**Example**: "Portland Trail Blazers" vs "Portland State"

**FIX**: Implement stricter matching:
```python
def _team_matches(self, target: str, scraped: str) -> bool:
    # Normalize both strings
    target_clean = target.lower().strip()
    scraped_clean = scraped.lower().strip()
    
    # Exact match
    if target_clean == scraped_clean:
        return True
    
    # Known aliases
    aliases = {
        'lakers': ['los angeles lakers', 'la lakers'],
        'clippers': ['los angeles clippers', 'la clippers'],
        'trail blazers': ['portland trail blazers', 'blazers'],
        # Add more as needed
    }
    
    for key, values in aliases.items():
        if (key in target_clean or target_clean in values) and \
           (key in scraped_clean or scraped_clean in values):
            return True
    
    # Word-based matching (both words must match)
    target_words = set(target_clean.split())
    scraped_words = set(scraped_clean.split())
    common_words = target_words & scraped_words
    
    # Require at least 2 common words
    return len(common_words) >= 2
```

---

### 17. **Missing Backup for ESPN Fallback Failure**

**ISSUE**: If both RotoWire AND ESPN fail, system returns empty list. No third fallback.

**FIX**: Add manual injury entry system:
```python
class ManualInjury(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    team = db.Column(db.String(100))
    player_name = db.Column(db.String(100))
    status = db.Column(db.String(20))
    impact_score = db.Column(db.Float)
    added_by = db.Column(db.String(100))
    valid_until = db.Column(db.Date)
    
# Then in injury check:
if not injuries_from_api:
    manual_injuries = ManualInjury.query.filter(
        ManualInjury.team == team,
        ManualInjury.valid_until >= date.today()
    ).all()
    if manual_injuries:
        # Convert to InjuredPlayer objects
```

---

### 18. **No Alert System for Circuit Breaker**

**ISSUE**: When circuit breaker opens, nobody knows.

**FIX**: Add alert mechanism:
```python
def send_alert(subject, message):
    # Email
    if os.environ.get("ALERT_EMAIL"):
        # Send email via SendGrid/Mailgun
        pass
    
    # Slack
    if os.environ.get("SLACK_WEBHOOK"):
        requests.post(
            os.environ["SLACK_WEBHOOK"],
            json={"text": f"🚨 {subject}\n{message}"}
        )

# In circuit breaker:
if self._failure_count >= 3:
    self._circuit_open = True
    send_alert(
        "RotoWire Circuit Breaker OPEN",
        f"3 consecutive failures. Falling back to ESPN for 5 minutes."
    )
```

---

### 19. **Qualification Logic Uses Old Function**

**ISSUE**: The `check_qualification_professional()` function doesn't integrate injury checks.

**Location**: `sports_app.py`, line 6791

**FIX**: Replace with RotoWire-aware qualification:
```python
# Instead of:
qual_result = check_qualification_professional(...)

# Use:
qual_result = qualify_game_with_injuries(
    game_data={
        'projected_total': proj_total,
        'line': line,
        'over_odds': over_odds,
        'under_odds': under_odds,
        'historical_win_rate': history_rate,
        'sample_size': sample,
        'pinnacle_odds': pinn_over_odds,
        'bovada_odds': over_odds
    },
    away_team=game.away_team,
    home_team=game.home_team,
    league=league,
    pick_type='total'
)

# Then check if qualified
game.is_qualified = qual_result['qualified']
game.injury_source = qual_result['injury_source']
game.away_injury_impact = qual_result['away_injury_impact']
game.home_injury_impact = qual_result['home_injury_impact']
```

---

## 🟡 MEDIUM-PRIORITY ISSUES

### 20. **Hardcoded Sleep Times**

**ISSUE**: Rate limiting uses hardcoded 2-second delays.

**FIX**: Make configurable:
```python
RATE_LIMIT_DELAY = float(os.environ.get("ROTOWIRE_RATE_LIMIT", "2.0"))
```

---

### 21. **No Request ID Tracking**

**ISSUE**: Can't correlate logs across multiple function calls.

**FIX**: Add request ID:
```python
import uuid

@app.before_request
def add_request_id():
    g.request_id = str(uuid.uuid4())

logger.info(f"[{g.request_id}] Processing game...")
```

---

### 22. **Missing Unit Tests**

**ISSUE**: No tests for critical functions.

**FIX**: Add pytest tests:
```python
def test_injury_impact_calculation():
    injury = InjuredPlayer(
        name="Test",
        team="Lakers",
        position="PG",
        status=InjuryStatus.OUT,
        injury="Knee",
        source="test",
        is_starter=True
    )
    assert injury.impact_score == 4.5

def test_qualification_with_injuries():
    # Test that major injuries disqualify
    pass
```

---

### 23-37. **Additional Medium-Priority Issues**

- Missing docstrings on some functions
- No type hints in older functions
- Inconsistent error messages
- No performance monitoring
- Cache key collisions possible
- No A/B testing framework
- Missing audit trail for pick changes
- No rollback mechanism for bad deployments
- Hardcoded magic numbers
- No feature flags for experimental features
- Missing data export functionality
- No backup/restore procedures
- Inconsistent naming conventions (camelCase vs snake_case)
- No API versioning
- Missing rate limit headers in responses

---

## ✅ WHAT'S WORKING WELL

1. **Overall architecture** - Clean separation of concerns
2. **Database schema** - Well-structured with proper indexes
3. **Error handling** - Most functions have try-catch
4. **Logging** - Comprehensive logging throughout
5. **Type safety** - Good use of dataclasses and type hints
6. **Documentation** - Functions are well-documented
7. **Constants** - GameConstants class centralizes config
8. **Circuit breaker** - Good pattern (just needs persistence)
9. **Cache implementation** - TTLCache is solid
10. **Thread safety** - Uses locks appropriately

---

## 📋 RECOMMENDED ACTION PLAN

### Week 1: Critical Fixes
- [ ] Fix injury impact score cap (Issue #3)
- [ ] Add RotoWire pre-flight check to fetch_odds_internal (Issue #1)
- [ ] Update Pick model with injury tracking columns (Issue #2)
- [ ] Fix function name imports (Issue #13)
- [ ] Standardize timezone handling (Issue #7)

### Week 2: High-Priority
- [ ] Add retry logic to API calls (Issue #8)
- [ ] Persist circuit breaker state (Issue #5)
- [ ] Add database error handling to auto-save (Issue #6)
- [ ] Create centralized config file (Issue #4)
- [ ] Add structured logging for disqualifications (Issue #10)

### Week 3: Medium-Priority
- [ ] Add monitoring metrics
- [ ] Implement alert system
- [ ] Write unit tests
- [ ] Add request ID tracking
- [ ] Improve team name matching

### Week 4: Polish & Deploy
- [ ] Performance testing
- [ ] Load testing
- [ ] Documentation updates
- [ ] Production deployment

---

## 🎯 PRIORITY RANKING

**P0 - Fix Before Deploy**:
1. Issue #1 - RotoWire integration not applied
2. Issue #2 - Missing database columns
3. Issue #3 - Impact score calculation error

**P1 - Fix Within 1 Week**:
4. Issue #7 - Timezone handling
5. Issue #13 - Function name mismatch
6. Issue #6 - Auto-save error handling

**P2 - Fix Within 2 Weeks**:
7. Issues #8-19

**P3 - Nice to Have**:
8. Issues #20-37

---

## 📊 CODE QUALITY METRICS

**Current Score**: 7.5/10

- Architecture: 9/10 ✅
- Error Handling: 7/10 🟡
- Testing: 2/10 ❌
- Documentation: 8/10 ✅
- Performance: 7/10 🟡
- Security: 8/10 ✅
- Maintainability: 8/10 ✅

**Target Score**: 9/10

---

## 💡 CONCLUSION

Your codebase is **functionally sound** but has **critical integration gaps** that prevent RotoWire from working as intended. The main issue is that the injury checking logic isn't called in the qualification flow.

**Estimated Fix Time**:
- Critical fixes: 8-12 hours
- High-priority: 16-20 hours
- Medium-priority: 20-30 hours
- **Total: 2-3 weeks for full optimization**

**Priority Order**:
1. Fix the integration (Issue #1) - Without this, nothing else matters
2. Add database columns (Issue #2) - Needed for tracking
3. Fix impact score cap (Issue #3) - Incorrect logic
4. Everything else is polish

**Ready to implement the fixes?** I'll create corrected versions of the key files.
