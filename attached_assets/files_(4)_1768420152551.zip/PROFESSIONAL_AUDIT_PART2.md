# 🎯 PROFESSIONAL AUDIT - PART 2
## Implementation Guide & Code Refactoring

---

## 🏗️ ARCHITECTURE IMPROVEMENTS

### **Current Architecture Issues:**

```
sports_app.py (8,999 lines) ← MONOLITH
├── Database models (500 lines)
├── API clients (800 lines)
├── Calculation logic (1,500 lines)
├── Routes/Views (1,200 lines)
├── Utilities (2,000 lines)
└── Everything else (3,000 lines)
```

**Problems:**
- Everything in one file
- No separation of concerns
- Hard to test
- Hard to find things
- Merge conflicts

### **Professional Architecture:**

```
project/
├── config/
│   ├── __init__.py
│   ├── thresholds.py          ← Single source of truth
│   └── leagues.py              ← League-specific configs
│
├── models/
│   ├── __init__.py
│   ├── game.py                 ← Game model only
│   ├── pick.py                 ← Pick model only
│   └── schemas.py              ← Pydantic validation
│
├── services/
│   ├── __init__.py
│   ├── edge_calculator.py      ← Edge logic
│   ├── ev_calculator.py        ← EV logic
│   ├── vig_remover.py          ← Vig logic
│   ├── historical_analyzer.py  ← History logic
│   └── qualifier.py            ← Qualification logic
│
├── integrations/
│   ├── __init__.py
│   ├── odds_api.py             ← Odds API client
│   ├── espn_client.py          ← ESPN client
│   ├── rotowire_client.py      ← RotoWire client
│   └── pinnacle_client.py      ← Pinnacle client
│
├── routes/
│   ├── __init__.py
│   ├── dashboard.py            ← Dashboard routes
│   ├── history.py              ← History routes
│   └── api.py                  ← API endpoints
│
├── utils/
│   ├── __init__.py
│   ├── cache.py                ← Caching utilities
│   ├── logger.py               ← Logging setup
│   └── validators.py           ← Input validation
│
├── tests/
│   ├── test_edge_calculator.py
│   ├── test_ev_calculator.py
│   └── test_qualifier.py
│
├── app.py                      ← Main app (50 lines)
├── requirements.txt
└── README.md
```

**Benefits:**
- Each file < 200 lines
- Easy to find code
- Easy to test
- Team-friendly
- Professional standard

---

## 🔧 CRITICAL REFACTORING EXAMPLES

### **1. Unified Threshold Configuration**

**Create**: `config/thresholds.py`

```python
"""
Betting thresholds configuration
Single source of truth for ALL threshold decisions
"""
from dataclasses import dataclass, field
from typing import Dict

@dataclass(frozen=True)  # Immutable for safety
class BettingThresholds:
    """
    All betting thresholds in one place.
    
    Philosophy:
    - Raw edge: Before vig removal (what user sees)
    - True edge: After vig removal (what actually matters)
    - Tiers: Universal across leagues (consistency)
    """
    
    # Raw edge thresholds (before vig removal)
    # These are what we show users - they understand these
    RAW_EDGE: Dict[str, float] = field(default_factory=lambda: {
        'NBA': 8.0,    # NBA needs 8+ point edge
        'CBB': 8.0,    # CBB needs 8+ point edge  
        'NFL': 6.0,    # NFL needs 6+ point edge (tighter)
        'CFB': 7.0,    # CFB needs 7+ point edge
        'NHL': 0.3,    # NHL needs 0.3+ goal edge (low scoring)
    })
    
    # True edge thresholds (after vig removal)
    # These are what professional bettors use
    TRUE_EDGE: Dict[str, float] = field(default_factory=lambda: {
        'NBA': 3.5,    # After vig: need 3.5+ true edge
        'CBB': 4.0,    # CBB: need 4.0+ true edge
        'NFL': 2.0,    # NFL: need 2.0+ true edge
        'CFB': 2.5,    # CFB: need 2.5+ true edge
        'NHL': 0.3,    # NHL: need 0.3+ true edge
    })
    
    # Confidence tier thresholds (universal)
    TIERS: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        'SUPERMAX': {
            'edge': 12.0,      # Need 12+ point edge
            'ev': 3.0,         # Need 3%+ EV vs Pinnacle
            'history': 70.0,   # Need 70%+ historical win rate
            'kelly': 5.0,      # Bet 5% of bankroll (max)
        },
        'HIGH': {
            'edge': 10.0,      # Need 10+ point edge
            'ev': 1.0,         # Need 1%+ EV vs Pinnacle
            'history': 65.0,   # Need 65%+ historical win rate
            'kelly': 3.0,      # Bet 3% of bankroll
        },
        'MEDIUM': {
            'edge': 8.0,       # Need 8+ point edge
            'ev': -1.0,        # Allow slight negative EV if other metrics strong
            'history': 60.0,   # Need 60%+ historical win rate
            'kelly': 2.0,      # Bet 2% of bankroll
        },
        'LOW': {
            'edge': 6.0,       # Need 6+ point edge
            'ev': -2.0,        # Allow more negative EV (borderline)
            'history': 55.0,   # Need 55%+ historical win rate
            'kelly': 1.0,      # Bet 1% of bankroll
        }
    })
    
    # Historical validation minimums
    MIN_HISTORY_PCT: float = 55.0          # Minimum win rate to qualify
    MIN_SAMPLE_SIZE: int = 5               # Minimum games in history
    IDEAL_SAMPLE_SIZE: int = 10            # Ideal games for confidence
    
    # EV boundaries
    MIN_EV_FOR_MEDIUM: float = -1.0        # Can have -1% EV if other metrics strong
    MIN_EV_FOR_LOW: float = -2.0           # Can have -2% EV (absolute floor)
    TARGET_EV: float = 3.0                 # Target for SUPERMAX
    
    # Kelly criterion parameters
    KELLY_FRACTION: float = 0.25           # Use quarter Kelly (conservative)
    MAX_KELLY: float = 5.0                 # Never bet more than 5% (safety)
    MIN_KELLY: float = 0.5                 # Minimum bet 0.5% (worth betting)
    
    # Vig tolerance
    MAX_VIG_PCT: float = 5.0               # Skip if vig > 5% (bad line)
    IDEAL_VIG_PCT: float = 2.5             # Target vig < 2.5%
    
    def get_raw_edge_threshold(self, league: str) -> float:
        """Get raw edge threshold for league."""
        return self.RAW_EDGE.get(league, 8.0)
    
    def get_true_edge_threshold(self, league: str) -> float:
        """Get true edge threshold for league."""
        return self.TRUE_EDGE.get(league, 3.5)
    
    def get_tier_requirements(self, tier: str) -> Dict[str, float]:
        """Get requirements for confidence tier."""
        return self.TIERS.get(tier, self.TIERS['LOW'])
    
    def calculate_tier(self, edge: float, ev: float, history_pct: float) -> str:
        """
        Determine confidence tier from metrics.
        
        Returns: 'SUPERMAX', 'HIGH', 'MEDIUM', 'LOW', or 'NONE'
        """
        for tier in ['SUPERMAX', 'HIGH', 'MEDIUM', 'LOW']:
            req = self.TIERS[tier]
            if (edge >= req['edge'] and 
                ev >= req['ev'] and 
                history_pct >= req['history']):
                return tier
        return 'NONE'

# Global instance - use everywhere
THRESHOLDS = BettingThresholds()
```

**Usage Example**:
```python
# OLD WAY (inconsistent):
if edge >= 8.0:  # Magic number!
    qualified = True

# NEW WAY (consistent):
from config.thresholds import THRESHOLDS

if edge >= THRESHOLDS.get_raw_edge_threshold(league):
    qualified = True

# Tier calculation:
tier = THRESHOLDS.calculate_tier(edge=10.5, ev=2.0, history_pct=68.0)
# Returns: 'HIGH'
```

---

### **2. Edge Calculator Service**

**Create**: `services/edge_calculator.py`

```python
"""
Edge calculation service
Handles all edge-related math in one place
"""
from typing import Tuple
from config.thresholds import THRESHOLDS

class EdgeCalculator:
    """
    Centralized edge calculation.
    
    Responsibilities:
    - Calculate raw edge (before vig removal)
    - Calculate true edge (after vig removal)
    - Determine if edge qualifies
    - Calculate margin of victory
    """
    
    @staticmethod
    def calculate_raw_edge(projected: float, line: float) -> float:
        """
        Calculate raw edge (absolute difference).
        
        Args:
            projected: Your projected total/spread
            line: Vegas line
            
        Returns:
            Raw edge in points (always positive)
            
        Example:
            projected = 225.0, line = 217.5
            → edge = 7.5 points
        """
        return abs(projected - line)
    
    @staticmethod
    def calculate_true_edge(
        projected: float, 
        line: float, 
        over_odds: int, 
        under_odds: int
    ) -> Tuple[float, float]:
        """
        Calculate true edge after vig removal.
        
        Args:
            projected: Your projected total
            line: Vegas line
            over_odds: Odds for OVER (e.g., -110)
            under_odds: Odds for UNDER (e.g., -110)
            
        Returns:
            (true_edge, fair_line)
            
        Process:
            1. Remove vig to get fair line
            2. Calculate edge vs fair line
            
        Example:
            projected = 225.0
            line = 217.5
            over_odds = -110, under_odds = -110
            
            fair_line = 217.8 (after vig removal)
            true_edge = |225.0 - 217.8| = 7.2 points
        """
        from services.vig_remover import VigRemover
        
        fair_line = VigRemover.calculate_fair_line_totals(
            line, over_odds, under_odds
        )
        true_edge = abs(projected - fair_line)
        
        return true_edge, fair_line
    
    @staticmethod
    def qualifies_raw(edge: float, league: str) -> bool:
        """
        Check if raw edge meets threshold.
        
        Args:
            edge: Raw edge in points
            league: 'NBA', 'NFL', etc.
            
        Returns:
            True if edge >= threshold
        """
        threshold = THRESHOLDS.get_raw_edge_threshold(league)
        return edge >= threshold
    
    @staticmethod
    def qualifies_true(true_edge: float, league: str) -> bool:
        """
        Check if true edge meets threshold.
        
        Args:
            true_edge: True edge (after vig removal)
            league: 'NBA', 'NFL', etc.
            
        Returns:
            True if true_edge >= threshold
        """
        threshold = THRESHOLDS.get_true_edge_threshold(league)
        return true_edge >= threshold
    
    @staticmethod
    def calculate_direction(projected: float, line: float) -> str:
        """
        Determine bet direction (OVER or UNDER).
        
        Args:
            projected: Your projected total
            line: Vegas line
            
        Returns:
            'OVER' if projected > line
            'UNDER' if projected < line
            None if exactly equal (don't bet)
        """
        if projected > line:
            return 'OVER'
        elif projected < line:
            return 'UNDER'
        return None
    
    @staticmethod
    def calculate_margin(
        team_ppg: float, 
        team_opp_ppg: float
    ) -> float:
        """
        Calculate expected margin of victory.
        
        Args:
            team_ppg: Team's points per game
            team_opp_ppg: Opponent's points allowed per game
            
        Returns:
            Expected margin (positive = team favored)
            
        Example:
            Lakers PPG: 115.0
            Heat allow: 108.0
            → margin = 7.0 (Lakers by 7)
        """
        return team_ppg - team_opp_ppg
    
    @staticmethod
    def calculate_edge_percentage(edge: float, line: float) -> float:
        """
        Calculate edge as percentage of line.
        
        Useful for comparing edges across different lines.
        
        Args:
            edge: Edge in points
            line: Vegas line
            
        Returns:
            Edge as percentage
            
        Example:
            edge = 10.0, line = 220.0
            → 4.5% edge
        """
        if line == 0:
            return 0.0
        return (edge / line) * 100


# Example usage:
calculator = EdgeCalculator()

# Calculate edges
raw_edge = calculator.calculate_raw_edge(225.0, 217.5)  # 7.5
true_edge, fair_line = calculator.calculate_true_edge(225.0, 217.5, -110, -110)  # 7.2, 217.8

# Check qualification
if calculator.qualifies_true(true_edge, 'NBA'):
    direction = calculator.calculate_direction(225.0, fair_line)  # 'OVER'
    print(f"QUALIFIED: {direction} {fair_line} (True Edge: {true_edge:.1f})")
```

---

### **3. Historical Analyzer Service**

**Create**: `services/historical_analyzer.py`

```python
"""
Historical performance analyzer
Validates picks against historical data
"""
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from models.game import Game
from config.thresholds import THRESHOLDS

class HistoricalAnalyzer:
    """
    Analyzes historical performance for validation.
    
    Key metrics:
    - Over/Under hit rates
    - Spread cover rates
    - Head-to-head trends
    - Sample size adequacy
    """
    
    @staticmethod
    def get_team_ou_rate(
        team: str, 
        league: str, 
        last_n_games: int = 10
    ) -> Dict[str, float]:
        """
        Get team's Over/Under hit rate for last N games.
        
        Args:
            team: Team name
            league: League
            last_n_games: Number of recent games to analyze
            
        Returns:
            {
                'over_pct': float (0-100),
                'under_pct': float (0-100),
                'sample_size': int,
                'valid': bool (meets minimum sample size)
            }
        """
        from datetime import date
        
        # Query last N games for this team
        recent_games = Game.query.filter(
            db.or_(Game.away_team == team, Game.home_team == team),
            Game.league == league,
            Game.date < date.today()
        ).order_by(Game.date.desc()).limit(last_n_games).all()
        
        if not recent_games:
            return {
                'over_pct': 0.0,
                'under_pct': 0.0,
                'sample_size': 0,
                'valid': False
            }
        
        # Count overs vs unders
        over_count = 0
        under_count = 0
        
        for game in recent_games:
            # Would need actual results - placeholder logic
            # In production: check if actual_total > line
            pass
        
        total_games = len(recent_games)
        over_pct = (over_count / total_games * 100) if total_games > 0 else 0
        under_pct = (under_count / total_games * 100) if total_games > 0 else 0
        
        return {
            'over_pct': over_pct,
            'under_pct': under_pct,
            'sample_size': total_games,
            'valid': total_games >= THRESHOLDS.MIN_SAMPLE_SIZE
        }
    
    @staticmethod
    def qualifies_on_history(
        history_pct: float,
        sample_size: int,
        tier: str = 'MEDIUM'
    ) -> bool:
        """
        Check if historical performance qualifies.
        
        Args:
            history_pct: Win rate percentage (0-100)
            sample_size: Number of games in sample
            tier: Target confidence tier
            
        Returns:
            True if meets both win rate and sample size requirements
        """
        tier_reqs = THRESHOLDS.get_tier_requirements(tier)
        min_history = tier_reqs['history']
        
        return (
            history_pct >= min_history and 
            sample_size >= THRESHOLDS.MIN_SAMPLE_SIZE
        )
    
    @staticmethod
    def calculate_confidence_from_sample(sample_size: int) -> float:
        """
        Calculate confidence multiplier based on sample size.
        
        Args:
            sample_size: Number of games in sample
            
        Returns:
            Confidence multiplier (0.5 to 1.0)
            
        Logic:
            - 5 games: 0.5x confidence (minimum)
            - 10 games: 1.0x confidence (ideal)
            - 15+ games: 1.0x confidence (cap)
        """
        if sample_size < THRESHOLDS.MIN_SAMPLE_SIZE:
            return 0.0  # Not enough data
        
        if sample_size >= THRESHOLDS.IDEAL_SAMPLE_SIZE:
            return 1.0  # Full confidence
        
        # Linear interpolation between min and ideal
        return 0.5 + (0.5 * (sample_size - THRESHOLDS.MIN_SAMPLE_SIZE) / 
                      (THRESHOLDS.IDEAL_SAMPLE_SIZE - THRESHOLDS.MIN_SAMPLE_SIZE))
    
    @staticmethod
    def get_h2h_trend(
        team1: str, 
        team2: str, 
        league: str, 
        last_n_games: int = 5
    ) -> Dict[str, any]:
        """
        Analyze head-to-head trends between two teams.
        
        Args:
            team1: First team name
            team2: Second team name
            league: League
            last_n_games: Number of recent matchups
            
        Returns:
            {
                'over_pct': float,
                'under_pct': float,
                'avg_total': float,
                'sample_size': int,
                'trend': str ('OVER', 'UNDER', 'NEUTRAL')
            }
        """
        # Query head-to-head games
        # This would integrate with existing H2H logic
        
        return {
            'over_pct': 0.0,
            'under_pct': 0.0,
            'avg_total': 0.0,
            'sample_size': 0,
            'trend': 'NEUTRAL'
        }
```

---

### **4. Line Movement Tracker** 💎 **NEW FEATURE**

**Create**: `services/line_movement.py`

```python
"""
Line movement tracking and analysis
Critical for sharp betting - follow where the sharp money goes
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class LineMovement:
    """Track how a line moves from opening to current."""
    opening_line: float
    current_line: float
    opening_time: datetime
    current_time: datetime
    public_betting_pct: Optional[float] = None  # % on OVER/favorite
    
    @property
    def movement(self) -> float:
        """Total line movement in points."""
        return self.current_line - self.opening_line
    
    @property
    def movement_direction(self) -> str:
        """Direction of movement."""
        if self.movement > 0.5:
            return 'UP'
        elif self.movement < -0.5:
            return 'DOWN'
        return 'FLAT'
    
    @property
    def is_reverse_line_movement(self) -> bool:
        """
        Detect reverse line movement (RLM).
        
        RLM = Line moves AGAINST public betting %.
        This indicates sharp money on the opposite side.
        
        Example:
            Public: 75% on OVER
            Line: Moved DOWN (from 220 to 218)
            → RLM! Sharps are hammering UNDER
        """
        if self.public_betting_pct is None:
            return False
        
        # If public is heavy on OVER (>60%) but line moved DOWN
        if self.public_betting_pct > 60 and self.movement < -0.5:
            return True
        
        # If public is heavy on UNDER (<40%) but line moved UP
        if self.public_betting_pct < 40 and self.movement > 0.5:
            return True
        
        return False
    
    @property
    def sharp_money_indicator(self) -> str:
        """
        Determine which side sharp money is on.
        
        Returns:
            'OVER', 'UNDER', or 'NEUTRAL'
        """
        if self.is_reverse_line_movement:
            # Line moved opposite of public = sharps on opposite side
            if self.movement < 0:
                return 'UNDER'  # Line down = sharps on UNDER
            else:
                return 'OVER'   # Line up = sharps on OVER
        
        # No RLM = follow the line movement
        if abs(self.movement) < 0.5:
            return 'NEUTRAL'
        
        return 'OVER' if self.movement > 0 else 'UNDER'
    
    def agrees_with_pick(self, pick_direction: str) -> bool:
        """
        Check if sharp money agrees with your pick.
        
        Args:
            pick_direction: Your pick ('OVER' or 'UNDER')
            
        Returns:
            True if sharp money on same side
        """
        sharp_side = self.sharp_money_indicator
        
        if sharp_side == 'NEUTRAL':
            return True  # Neutral is fine
        
        return sharp_side == pick_direction
    
    def get_clv_projection(self, pick_direction: str) -> float:
        """
        Project closing line value based on current movement.
        
        Args:
            pick_direction: Your intended pick
            
        Returns:
            Projected CLV in points (positive = good)
        """
        # If line moving toward your pick, you'll get worse CLV
        # If line moving away from your pick, you'll get better CLV
        
        if pick_direction == 'OVER':
            return -self.movement  # Line up = worse OVER CLV
        else:  # UNDER
            return self.movement   # Line up = better UNDER CLV


class LineMovementTracker:
    """Track and analyze line movements."""
    
    @staticmethod
    def should_bet_based_on_movement(
        movement: LineMovement,
        pick_direction: str,
        min_clv: float = 0.5
    ) -> Dict[str, any]:
        """
        Determine if you should bet based on line movement.
        
        Args:
            movement: LineMovement object
            pick_direction: Your pick direction
            min_clv: Minimum acceptable CLV
            
        Returns:
            {
                'should_bet': bool,
                'reason': str,
                'confidence_boost': float,
                'sharp_agreement': bool
            }
        """
        sharp_agrees = movement.agrees_with_pick(pick_direction)
        projected_clv = movement.get_clv_projection(pick_direction)
        is_rlm = movement.is_reverse_line_movement
        
        # Best case: RLM + sharp money on your side
        if is_rlm and sharp_agrees:
            return {
                'should_bet': True,
                'reason': 'RLM detected - sharp money agrees with your pick',
                'confidence_boost': 2.0,  # Boost edge by 2 points
                'sharp_agreement': True
            }
        
        # Good case: Sharp money on your side
        if sharp_agrees:
            return {
                'should_bet': True,
                'reason': 'Sharp money indicator agrees',
                'confidence_boost': 1.0,
                'sharp_agreement': True
            }
        
        # Neutral: No strong signals
        if movement.movement_direction == 'FLAT':
            return {
                'should_bet': True,
                'reason': 'Line stable - no conflicting signals',
                'confidence_boost': 0.0,
                'sharp_agreement': True  # Neutral counts as agreement
            }
        
        # Bad case: Sharp money against you
        if not sharp_agrees:
            return {
                'should_bet': False,
                'reason': 'Sharp money on opposite side - AVOID',
                'confidence_boost': -3.0,  # Penalty
                'sharp_agreement': False
            }
        
        # Check CLV
        if projected_clv < min_clv:
            return {
                'should_bet': False,
                'reason': f'Projected CLV too low ({projected_clv:.1f} < {min_clv})',
                'confidence_boost': 0.0,
                'sharp_agreement': sharp_agrees
            }
        
        return {
            'should_bet': True,
            'reason': 'Acceptable line movement',
            'confidence_boost': 0.0,
            'sharp_agreement': sharp_agrees
        }


# Example usage:
movement = LineMovement(
    opening_line=220.0,
    current_line=218.5,
    opening_time=datetime(2024, 1, 14, 9, 0),
    current_time=datetime(2024, 1, 14, 18, 0),
    public_betting_pct=72.0  # 72% on OVER
)

# Analyze
print(f"Movement: {movement.movement} points {movement.movement_direction}")
print(f"RLM: {movement.is_reverse_line_movement}")
print(f"Sharp money: {movement.sharp_money_indicator}")

# Check if should bet UNDER
your_pick = 'UNDER'
analysis = LineMovementTracker.should_bet_based_on_movement(movement, your_pick)

if analysis['should_bet']:
    print(f"✅ BET {your_pick}")
    print(f"   Reason: {analysis['reason']}")
    print(f"   Confidence boost: {analysis['confidence_boost']:+.1f} points")
else:
    print(f"❌ SKIP {your_pick}")
    print(f"   Reason: {analysis['reason']}")
```

---

## 📊 DATABASE OPTIMIZATION

### **Current Issues:**

1. **N+1 Query Pattern** in dashboard
2. **No database indexes** on key columns
3. **No query result caching**
4. **No connection pooling** optimization

### **Fixes:**

#### **1. Add Database Indexes**

```sql
-- Critical indexes for performance
CREATE INDEX idx_game_date_league_qualified 
ON game(date, league, is_qualified) 
WHERE is_qualified = true;

CREATE INDEX idx_game_date_league_spread 
ON game(date, league, spread_is_qualified) 
WHERE spread_is_qualified = true;

CREATE INDEX idx_pick_date_result 
ON pick(date, result) 
WHERE result IN ('W', 'L', 'P');

CREATE INDEX idx_game_teams_league 
ON game(away_team, home_team, league);

-- Composite index for dashboard query
CREATE INDEX idx_game_dashboard 
ON game(date, league, is_qualified) 
INCLUDE (away_team, home_team, line, edge, direction, true_edge);
```

#### **2. Use Eager Loading**

```python
# BAD (N+1 queries):
games = Game.query.filter_by(date=today).all()
for game in games:
    picks = Pick.query.filter_by(game_id=game.id).all()  # N more queries!

# GOOD (2 queries):
games = Game.query.filter_by(date=today)\
    .options(db.selectinload(Game.picks))\
    .all()
for game in games:
    picks = game.picks  # Already loaded!
```

#### **3. Add Query Result Caching**

```python
from functools import lru_cache
from datetime import date

@lru_cache(maxsize=128)
def get_games_for_date(target_date: date, league: str):
    """Cache query results for repeated calls."""
    return Game.query.filter_by(
        date=target_date,
        league=league
    ).all()
```

---

## 🧪 TESTING FRAMEWORK

### **Current**: No tests (0% coverage) ❌

### **Professional**: 80%+ coverage ✅

**Create**: `tests/test_edge_calculator.py`

```python
import pytest
from services.edge_calculator import EdgeCalculator

class TestEdgeCalculator:
    """Test suite for edge calculations."""
    
    def test_calculate_raw_edge_basic(self):
        """Test basic edge calculation."""
        calc = EdgeCalculator()
        edge = calc.calculate_raw_edge(225.0, 217.5)
        assert edge == 7.5
    
    def test_calculate_raw_edge_symmetric(self):
        """Test edge is always positive."""
        calc = EdgeCalculator()
        edge1 = calc.calculate_raw_edge(220.0, 215.0)
        edge2 = calc.calculate_raw_edge(215.0, 220.0)
        assert edge1 == edge2 == 5.0
    
    def test_qualifies_nba_threshold(self):
        """Test NBA qualification threshold."""
        calc = EdgeCalculator()
        assert calc.qualifies_raw(8.0, 'NBA') == True   # Exactly 8
        assert calc.qualifies_raw(7.9, 'NBA') == False  # Just under
        assert calc.qualifies_raw(10.0, 'NBA') == True  # Well over
    
    def test_qualifies_nhl_threshold(self):
        """Test NHL has different threshold."""
        calc = EdgeCalculator()
        assert calc.qualifies_raw(0.3, 'NHL') == True   # NHL needs 0.3
        assert calc.qualifies_raw(0.2, 'NHL') == False
    
    def test_calculate_direction(self):
        """Test direction calculation."""
        calc = EdgeCalculator()
        assert calc.calculate_direction(225.0, 220.0) == 'OVER'
        assert calc.calculate_direction(215.0, 220.0) == 'UNDER'
        assert calc.calculate_direction(220.0, 220.0) is None
    
    @pytest.mark.parametrize("projected,line,expected_edge", [
        (225.0, 217.5, 7.5),
        (210.0, 220.0, 10.0),
        (215.5, 215.5, 0.0),
        (180.3, 180.0, 0.3),
    ])
    def test_calculate_raw_edge_parametrized(self, projected, line, expected_edge):
        """Test multiple edge scenarios."""
        calc = EdgeCalculator()
        edge = calc.calculate_raw_edge(projected, line)
        assert edge == expected_edge
```

**Run tests**:
```bash
pytest tests/ -v --cov=services --cov-report=html
```

---

## 📈 PERFORMANCE BENCHMARKS

### **Expected Improvements After Refactoring:**

| Operation | Before | After | Improvement |
|-----------|--------|-------|-------------|
| Dashboard load | 2000ms | 50ms | 40x faster |
| Odds fetch | 30s | 12s | 2.5x faster |
| Historical query | 500ms | 20ms | 25x faster |
| Pick qualification | 50ms | 5ms | 10x faster |
| Code changes/week | 5 | 20 | 4x faster dev |

---

**Continue to Part 3 for:**
- Advanced betting strategies
- Machine learning integration
- Deployment architecture
- Monitoring & alerts
- Bankroll management

---

**End of Part 2**
