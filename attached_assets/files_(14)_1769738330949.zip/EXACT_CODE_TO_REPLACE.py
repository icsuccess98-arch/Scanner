# =============================================================================
# REPLACE THIS SECTION IN sports_app.py (lines 2175-2211)
# =============================================================================
# 
# FIND THIS CODE:
#                 # SPREAD RLM: Check if line moved opposite to public betting
#                 try:
#                     if spread_open_line and spread_current_line:
#                         open_spread = float(str(spread_open_line).replace('+', ''))
#                         current_spread = float(str(spread_current_line).replace('+', ''))
#                         spread_movement = current_spread - open_spread
#                         
#                         # Public on AWAY (negative spread means away favored)
#                         # If public bets away but spread gets LESS negative (moves toward home) = RLM
#                         if away_bet_pct >= 60 and spread_movement > 0.5:
#                             spread_rlm_detected = True
#                             spread_rlm_sharp_side = home_team
#                         # Public on HOME but spread gets MORE negative (moves toward away) = RLM
#                         elif home_bet_pct >= 60 and spread_movement < -0.5:
#                             spread_rlm_detected = True
#                             spread_rlm_sharp_side = away_team
#                 except:
#                     pass
#                 
#                 # TOTALS RLM: Check if line moved opposite to over/under betting
#                 try:
#                     if total_open_line and total_current_line:
#                         open_total = float(str(total_open_line).replace('O', '').replace('U', ''))
#                         current_str = str(total_current_line).replace('O', '').replace('U', '')
#                         current_total = float(current_str)
#                         total_movement = current_total - open_total
#                         
#                         # Public on OVER but total DROPS = RLM (sharp on Under)
#                         if over_bet_pct >= 60 and total_movement < -0.5:
#                             totals_rlm_detected = True
#                             totals_rlm_sharp_side = 'Under'
#                         # Public on UNDER but total RISES = RLM (sharp on Over)
#                         elif under_bet_pct >= 60 and total_movement > 0.5:
#                             totals_rlm_detected = True
#                             totals_rlm_sharp_side = 'Over'
#                 except:
#                     pass
#
# =============================================================================
# REPLACE WITH THIS CODE:
# =============================================================================

                # === CORRECTED RLM DETECTION ===
                # RLM = Line moves OPPOSITE direction of public money
                
                spread_rlm_detected = False
                spread_rlm_sharp_side = None
                totals_rlm_detected = False
                totals_rlm_sharp_side = None
                
                # SPREAD RLM: Detect reverse line movement for spreads
                try:
                    if spread_open_line and spread_current_line:
                        # Parse spread values
                        open_spread_str = str(spread_open_line).replace(away_team, '').replace(home_team, '').replace('+', '').strip()
                        current_spread_str = str(spread_current_line).replace(away_team, '').replace(home_team, '').replace('+', '').strip()
                        
                        open_spread = float(open_spread_str)
                        current_spread = float(current_spread_str)
                        spread_movement = current_spread - open_spread
                        movement_abs = abs(spread_movement)
                        
                        # Need at least 0.5 point movement
                        if movement_abs >= 0.5:
                            # Determine which side public is on (use money % as more meaningful)
                            if away_money_pct >= 55:
                                public_side = 'away'
                                public_pct = away_money_pct
                            elif home_money_pct >= 55:
                                public_side = 'home'
                                public_pct = home_money_pct
                            else:
                                public_side = 'balanced'
                                public_pct = 50
                            
                            # Determine direction line moved
                            # Positive movement = line moved toward home
                            # Negative movement = line moved toward away
                            if spread_movement > 0:
                                line_moved_toward = 'home'
                            else:
                                line_moved_toward = 'away'
                            
                            # RLM: Public on one side, line moves to OTHER side
                            if public_side == 'away' and line_moved_toward == 'home':
                                # Public on away, line moved toward home → RLM
                                spread_rlm_detected = True
                                spread_rlm_sharp_side = home_team
                            elif public_side == 'home' and line_moved_toward == 'away':
                                # Public on home, line moved toward away → RLM
                                spread_rlm_detected = True
                                spread_rlm_sharp_side = away_team
                except Exception as e:
                    logger.warning(f"Error detecting spread RLM: {e}")
                
                # TOTALS RLM: Detect reverse line movement for totals
                try:
                    if total_open_line and total_current_line:
                        # Parse total values
                        open_total_str = str(total_open_line).replace('O', '').replace('U', '').replace('o', '').replace('u', '').strip()
                        current_total_str = str(total_current_line).replace('O', '').replace('U', '').replace('o', '').replace('u', '').strip()
                        
                        open_total = float(open_total_str)
                        current_total = float(current_total_str)
                        total_movement = current_total - open_total
                        movement_abs = abs(total_movement)
                        
                        # Need at least 0.5 point movement
                        if movement_abs >= 0.5:
                            # Determine which side public is on
                            if over_money_pct >= 55:
                                public_side = 'over'
                                public_pct = over_money_pct
                            elif under_money_pct >= 55:
                                public_side = 'under'
                                public_pct = under_money_pct
                            else:
                                public_side = 'balanced'
                                public_pct = 50
                            
                            # RLM for totals:
                            # Public on Over → total should go UP (harder for Over)
                            # If total goes DOWN → RLM (sharp on Over)
                            # 
                            # Public on Under → total should go DOWN (harder for Under)
                            # If total goes UP → RLM (sharp on Under)
                            
                            if public_side == 'over' and total_movement < 0:
                                # Public on Over, total dropped → RLM
                                totals_rlm_detected = True
                                totals_rlm_sharp_side = 'Over'
                            elif public_side == 'under' and total_movement > 0:
                                # Public on Under, total rose → RLM
                                totals_rlm_detected = True
                                totals_rlm_sharp_side = 'Under'
                except Exception as e:
                    logger.warning(f"Error detecting totals RLM: {e}")

# =============================================================================
# THAT'S IT! The rest of your code stays the same.
# =============================================================================
