# =============================================================================
# CORRECTED RLM DETECTION FOR BETTING ACTION DISPLAY
# =============================================================================
# 
# YOUR ISSUE: Bucks @ Wizards
# - Opening: Bucks -3
# - Current (closing): Bucks -1.5  (line moved 1.5 points toward Wizards)
# - Public: 60% tickets on Bucks, 68% money on Bucks
# - CORRECT RLM: Sharp money on WIZARDS (line moved toward them despite public on Bucks)
#
# =============================================================================

def detect_rlm_corrected(
    away_team: str,
    home_team: str,
    spread_open_line: str,      # "Bucks -3" or "-3"
    spread_current_line: str,   # "Bucks -1.5" or "-1.5"
    away_bet_pct: float,        # 60
    home_bet_pct: float,        # 40
    away_money_pct: float,      # 68
    home_money_pct: float       # 32
) -> dict:
    """
    CORRECT RLM detection logic.
    
    Returns:
        {
            'rlm_detected': bool,
            'rlm_favor': str,  # Team name that sharp money is on
            'explanation': str,
            'line_moved_toward': str,
            'public_on': str
        }
    """
    
    # Parse spread lines (handle formats like "Bucks -3", "-3", etc.)
    try:
        # Extract numeric value from spread
        open_spread_str = str(spread_open_line).replace(away_team, '').replace(home_team, '').strip()
        current_spread_str = str(spread_current_line).replace(away_team, '').replace(home_team, '').strip()
        
        open_spread = float(open_spread_str)
        current_spread = float(current_spread_str)
        
    except (ValueError, AttributeError):
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Unable to parse spread lines',
            'line_moved_toward': 'Unknown',
            'public_on': 'Unknown'
        }
    
    # Calculate movement
    movement = current_spread - open_spread
    movement_abs = abs(movement)
    
    # Need at least 0.5 point movement
    if movement_abs < 0.5:
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Line stable (no significant movement)',
            'line_moved_toward': 'Stable',
            'public_on': away_team if away_bet_pct > home_bet_pct else home_team
        }
    
    # Determine which side public is on (use money % as it's more meaningful)
    # Use 55% threshold to account for balanced action
    if away_money_pct >= 55:
        public_side = 'away'
        public_team = away_team
        public_pct = away_money_pct
    elif home_money_pct >= 55:
        public_side = 'home'
        public_team = home_team
        public_pct = home_money_pct
    else:
        # Action is balanced, no clear RLM
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Balanced action (no clear public side)',
            'line_moved_toward': 'Balanced',
            'public_on': 'Balanced'
        }
    
    # Determine which side the line moved toward
    # Negative spread = away favored, positive = home favored
    # If spread becomes LESS negative → moved toward home
    # If spread becomes MORE negative → moved toward away
    
    if movement > 0:
        # Line moved in positive direction
        # Examples: -3 to -1.5 (less negative, toward home)
        #           +3 to +5 (more positive, toward away as underdog)
        line_moved_toward = 'home'
        sharp_team = home_team
    else:
        # Line moved in negative direction
        # Examples: -3 to -5 (more negative, toward away)
        #           +3 to +1 (less positive, toward home as underdog)
        line_moved_toward = 'away'
        sharp_team = away_team
    
    # RLM DETECTION: Did line move OPPOSITE to public?
    # If public is on away, line should move toward away (more negative)
    # If line moved toward home instead → RLM
    
    if public_side == 'away' and line_moved_toward == 'home':
        # Public on away, but line moved toward home
        rlm_detected = True
        rlm_favor = home_team
        explanation = (
            f"RLM: {public_pct:.0f}% of money on {public_team}, "
            f"but line moved {movement_abs:.1f} points toward {sharp_team}. "
            f"Sharp money on {sharp_team}."
        )
    
    elif public_side == 'home' and line_moved_toward == 'away':
        # Public on home, but line moved toward away
        rlm_detected = True
        rlm_favor = away_team
        explanation = (
            f"RLM: {public_pct:.0f}% of money on {public_team}, "
            f"but line moved {movement_abs:.1f} points toward {sharp_team}. "
            f"Sharp money on {sharp_team}."
        )
    
    else:
        # Line moved WITH public (normal movement)
        rlm_detected = False
        rlm_favor = 'None'
        explanation = (
            f"Line moved WITH public: {public_pct:.0f}% on {public_team}, "
            f"line moved {movement_abs:.1f} points toward {sharp_team}."
        )
    
    return {
        'rlm_detected': rlm_detected,
        'rlm_favor': rlm_favor,
        'explanation': explanation,
        'line_moved_toward': sharp_team,
        'public_on': public_team,
        'movement': movement,
        'movement_abs': movement_abs
    }


def detect_totals_rlm_corrected(
    total_open_line: float,      # 225.5
    total_current_line: float,   # 223.5
    over_bet_pct: float,         # 22
    under_bet_pct: float,        # 78
    over_money_pct: float,       # 22
    under_money_pct: float       # 78
) -> dict:
    """
    CORRECT RLM detection for totals.
    
    Returns:
        {
            'rlm_detected': bool,
            'rlm_favor': str,  # 'Over' or 'Under'
            'explanation': str
        }
    """
    
    try:
        open_total = float(total_open_line)
        current_total = float(total_current_line)
    except (ValueError, TypeError):
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Unable to parse total lines'
        }
    
    # Calculate movement
    movement = current_total - open_total
    movement_abs = abs(movement)
    
    # Need at least 0.5 point movement
    if movement_abs < 0.5:
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Total stable (no significant movement)'
        }
    
    # Determine which side public is on (use money %)
    if over_money_pct >= 55:
        public_side = 'over'
        public_pct = over_money_pct
    elif under_money_pct >= 55:
        public_side = 'under'
        public_pct = under_money_pct
    else:
        return {
            'rlm_detected': False,
            'rlm_favor': 'None',
            'explanation': 'Balanced action on totals'
        }
    
    # RLM DETECTION for totals:
    # If public on Over, total should go UP (harder for Over)
    # If total goes DOWN instead → RLM (sharp on Over)
    #
    # If public on Under, total should go DOWN (harder for Under)
    # If total goes UP instead → RLM (sharp on Under)
    
    if public_side == 'over' and movement < 0:
        # Public on Over, total dropped → RLM
        rlm_detected = True
        rlm_favor = 'Over'
        explanation = (
            f"RLM: {public_pct:.0f}% on Over, "
            f"but total dropped {movement_abs:.1f} points (easier for Over). "
            f"Sharp money on Over."
        )
    
    elif public_side == 'under' and movement > 0:
        # Public on Under, total rose → RLM
        rlm_detected = True
        rlm_favor = 'Under'
        explanation = (
            f"RLM: {public_pct:.0f}% on Under, "
            f"but total rose {movement_abs:.1f} points (easier for Under). "
            f"Sharp money on Under."
        )
    
    else:
        # Total moved with public (normal)
        rlm_detected = False
        rlm_favor = 'None'
        if public_side == 'over':
            explanation = f"Total moved WITH public (harder for Over)"
        else:
            explanation = f"Total moved WITH public (harder for Under)"
    
    return {
        'rlm_detected': rlm_detected,
        'rlm_favor': rlm_favor,
        'explanation': explanation,
        'movement': movement,
        'movement_abs': movement_abs
    }


# =============================================================================
# TEST WITH YOUR ACTUAL DATA
# =============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("TESTING WITH YOUR BUCKS @ WIZARDS GAME")
    print("=" * 80)
    
    # Your actual game data
    result = detect_rlm_corrected(
        away_team="Bucks",
        home_team="Wizards",
        spread_open_line="Bucks -3",      # Opening
        spread_current_line="Bucks -1.5",  # Closing (you said it moved to -1.5)
        away_bet_pct=60,
        home_bet_pct=40,
        away_money_pct=68,
        home_money_pct=32
    )
    
    print("\nSPREAD RLM DETECTION:")
    print(f"RLM Detected: {result['rlm_detected']}")
    print(f"RLM Favor: {result['rlm_favor']}")
    print(f"Explanation: {result['explanation']}")
    print(f"Line moved toward: {result['line_moved_toward']}")
    print(f"Public on: {result['public_on']}")
    print(f"Movement: {result['movement']:.1f} points")
    
    print("\n" + "=" * 80)
    print("EXPECTED RESULT:")
    print("RLM Detected: True")
    print("RLM Favor: Wizards")
    print("Explanation: 68% of money on Bucks, but line moved 1.5 points toward Wizards")
    print("=" * 80)
    
    # Test totals
    print("\n" + "=" * 80)
    print("TESTING TOTALS (Opening 225.5 → Closing 223.5)")
    print("=" * 80)
    
    totals_result = detect_totals_rlm_corrected(
        total_open_line=225.5,
        total_current_line=223.5,
        over_bet_pct=22,
        under_bet_pct=78,
        over_money_pct=22,
        under_money_pct=78
    )
    
    print("\nTOTALS RLM DETECTION:")
    print(f"RLM Detected: {totals_result['rlm_detected']}")
    print(f"RLM Favor: {totals_result['rlm_favor']}")
    print(f"Explanation: {totals_result['explanation']}")
    print(f"Movement: {totals_result['movement']:.1f} points")
    
    print("\n" + "=" * 80)
    print("EXPECTED RESULT:")
    print("RLM Detected: False")
    print("RLM Favor: None")
    print("Explanation: Line moved WITH public (78% on Under, total dropped 2 points)")
    print("=" * 80)
